/* ==========================================================================
   Aetheria Library — Universal Service Worker
   Enables 100% offline functionality across all pages and windows.
   ========================================================================== */

const CACHE_NAME = 'aetheria-cache-v4';

const STATIC_ASSETS = [
    './',
    'index.html',
    'login.html',
    'signup.html',
    'forgot.html',
    'home.html',
    'admin.html',
    'admin_login.html',
    'style.css',
    'enhancements.css',
    'admin.css',
    'auth-common.js',
    'login.js',
    'signup.js',
    'forgot.js',
    'app.js',
    'features.js',
    'admin.js',
    'admin_login.js'
];

// Install Event: Precaches core application shell
self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => {
            return cache.addAll(STATIC_ASSETS).catch((err) => {
                console.warn('[ServiceWorker] Some pre-cached assets failed to cache:', err);
            });
        }).then(() => self.skipWaiting())
    );
});

// Activate Event: Remove outdated caches and take immediate control
self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then((keys) => {
            return Promise.all(
                keys.filter(key => key !== CACHE_NAME).map(key => {
                    console.log('[ServiceWorker] Removing older cache:', key);
                    return caches.delete(key);
                })
            );
        }).then(() => self.clients.claim())
    );
});

// Fetch Event: Offline-first with cache fallback
self.addEventListener('fetch', (event) => {
    const request = event.request;

    // Only handle GET requests with cache
    if (request.method !== 'GET') {
        return;
    }

    // 2. Navigation / HTML pages: Network-first with cache fallback
    if (request.mode === 'navigate' || request.destination === 'document') {
        event.respondWith(
            fetch(request)
                .then((networkResponse) => {
                    if (networkResponse && networkResponse.status === 200) {
                        const copy = networkResponse.clone();
                        caches.open(CACHE_NAME).then(cache => cache.put(request, copy));
                    }
                    return networkResponse;
                })
                .catch(() => {
                    return caches.match(request).then((cachedResponse) => {
                        if (cachedResponse) return cachedResponse;
                        // Default fallback to login or index
                        return caches.match('login.html');
                    });
                })
        );
        return;
    }

    // 3. Static assets (CSS, JS, Fonts, Images): Cache-first with stale-while-revalidate
    event.respondWith(
        caches.match(request).then((cachedResponse) => {
            const fetchPromise = fetch(request).then((networkResponse) => {
                if (networkResponse && networkResponse.status === 200) {
                    const copy = networkResponse.clone();
                    caches.open(CACHE_NAME).then(cache => cache.put(request, copy));
                }
                return networkResponse;
            }).catch(() => {
                // If offline and request fails
                if (request.destination === 'image') {
                    // Transparent placeholder SVG
                    return new Response('<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40"><circle cx="20" cy="20" r="18" fill="#cc6640"/></svg>', {
                        headers: { 'Content-Type': 'image/svg+xml' }
                    });
                }
            });

            return cachedResponse || fetchPromise;
        })
    );
});
