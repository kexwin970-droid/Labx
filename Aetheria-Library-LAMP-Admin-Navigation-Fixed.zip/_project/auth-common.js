/* ==========================================================================
   Aetheria Library — Universal Authentication & Central Storage Bridge
   Connects client frontend to the LAMP PHP API and MySQL database
   with resilient offline cache & cross-tab synchronization.
   ========================================================================== */

// Predefined Demo Accounts
const DEMO_USER = {
    id: 1,
    username: "demo",
    email: "demo@example.com",
    password: "Demo@123",
    name: "Arthur Pendragon",
    firstName: "Arthur",
    lastName: "Pendragon",
    gender: "Male",
    role: "member",
    status: "active",
    genre: "Sci-Fi & Fantasy",
    avatar: "1",
    bio: "Avid reader and explorer of fantastical worlds.",
    premium: 1
};

const DEMO_ADMIN = {
    id: 2,
    username: "admin",
    email: "admin@example.com",
    password: "Admin@123",
    name: "System Administrator",
    firstName: "Aetheria",
    lastName: "Admin",
    gender: "Other",
    role: "admin",
    status: "active",
    genre: "Technology & Science",
    avatar: "1",
    bio: "System administrator for Aetheria Library.",
    premium: 1
};

// ==========================================================================
// 1. Session Token & Storage Helpers
// ==========================================================================
function getAuthToken() {
    try {
        return localStorage.getItem("aetheria_token") || "";
    } catch (e) {
        return "";
    }
}

function setAuthToken(token) {
    try {
        if (token) localStorage.setItem("aetheria_token", token);
        else localStorage.removeItem("aetheria_token");
    } catch (e) {}
}

function getActiveUser() {
    try {
        const stored = localStorage.getItem("aetheria_active_user");
        return stored ? JSON.parse(stored) : null;
    } catch (e) {
        return null;
    }
}

function setActiveUser(user) {
    try {
        localStorage.setItem("aetheria_active_user", JSON.stringify(user));
    } catch (e) {}
}

function clearSession() {
    try {
        localStorage.removeItem("aetheria_token");
        localStorage.removeItem("aetheria_active_user");
    } catch (e) {}
}

// Ensure predefined demo accounts exist in local database
function ensureLocalDatabase() {
    try {
        let users = JSON.parse(localStorage.getItem("aetheria_users") || "[]");
        if (!Array.isArray(users)) users = [];

        let modified = false;
        if (!users.some(u => u.username === "demo" || u.email === "demo@example.com")) {
            users.push({ ...DEMO_USER });
            modified = true;
        }
        if (!users.some(u => u.username === "admin" || u.email === "admin@example.com")) {
            users.push({ ...DEMO_ADMIN });
            modified = true;
        }
        if (modified) {
            localStorage.setItem("aetheria_users", JSON.stringify(users));
        }
    } catch (e) {}
}
ensureLocalDatabase();

// ==========================================================================
// 2. LAMP / Apache / PHP API Client
// ==========================================================================
function getApiBaseUrl() {
    // LAMP deployment: resolve the API relative to the current site.
    // This works both at the domain root (https://example.com/) and in a
    // subdirectory (http://localhost/aetheria/).
    try {
        return new URL("api/", document.baseURI).pathname.replace(/\/$/, "");
    } catch (e) {
        return "./api";
    }
}

async function callApi(endpoint, method = "GET", data = null) {
    const baseUrl = getApiBaseUrl();
    const cleanEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
    const url = `${baseUrl}${cleanEndpoint}`;
    const token = getAuthToken();

    const headers = {
        "Accept": "application/json"
    };
    if (data && method !== "GET") {
        headers["Content-Type"] = "application/json";
    }
    if (token) {
        headers["Authorization"] = `Bearer ${token}`;
    }

    const options = {
        method,
        headers
    };
    if (data && method !== "GET") {
        options.body = JSON.stringify(data);
    }

    try {
        const response = await fetch(url, options);
        const json = await response.json().catch(() => null);
        if (response.ok && json) {
            return json;
        }
        if (json && json.message) {
            return json;
        }
        return { success: false, message: `Server returned HTTP ${response.status}` };
    } catch (networkErr) {
        // Server offline, CORS, or unreachable -> return null to allow resilient local fallback
        return null;
    }
}

// Dispatches cross-component and cross-tab event when books change in admin
function notifyBooksChanged(books) {
    try {
        window.dispatchEvent(new CustomEvent('booksUpdated', { detail: { books } }));
    } catch (e) {}
    try {
        if (typeof BroadcastChannel !== 'undefined') {
            const bc = new BroadcastChannel('aetheria_sync');
            bc.postMessage({ type: 'booksUpdated', books });
            bc.close();
        }
    } catch (e) {}
    try {
        localStorage.setItem('aetheria_last_sync', Date.now().toString());
    } catch (e) {}
}

// ==========================================================================
// 3. Authentication & Profile Services (SQL Connected + Local Fallback)
// ==========================================================================
async function apiLogin(identifier, password) {
    ensureLocalDatabase();
    const cleanId = (identifier || '').trim().toLowerCase();
    const cleanPw = (password || '').trim();

    if (!cleanId || !cleanPw) {
        return { success: false, message: 'Please provide both username/email and password.' };
    }

    // 1. Attempt Live SQL Database Authentication via REST API
    const apiResult = await callApi('/auth/login', 'POST', {
        identifier: cleanId,
        password: cleanPw
    });

    if (apiResult) {
        if (apiResult.success && apiResult.data) {
            const token = apiResult.data.token || ('token-' + btoa(JSON.stringify({ email: apiResult.data.user?.email })));
            const user = apiResult.data.user;

            setAuthToken(token);
            setActiveUser(user);

            // Sync user to local database cache
            try {
                let users = JSON.parse(localStorage.getItem("aetheria_users") || "[]");
                const idx = users.findIndex(u => u.email === user.email || u.username === user.username);
                if (idx !== -1) users[idx] = { ...users[idx], ...user };
                else users.push(user);
                localStorage.setItem("aetheria_users", JSON.stringify(users));
            } catch (e) {}

            return apiResult;
        } else {
            // Live server explicitly rejected (bad password or disabled account)
            return apiResult;
        }
    }

    // 2. Resilient Fallback Engine (when SQL server is offline)
    let users = [];
    try {
        users = JSON.parse(localStorage.getItem("aetheria_users") || "[]");
    } catch (e) {
        users = [DEMO_USER, DEMO_ADMIN];
    }

    let user = users.find(u =>
        (u.username && u.username.toLowerCase() === cleanId) ||
        (u.email && u.email.toLowerCase() === cleanId)
    );

    if (!user) {
        if ((cleanId === "demo" || cleanId === "demo@example.com" || cleanId === "demo@aetheria.org" || cleanId === "arthur") &&
            (cleanPw === "Demo@123" || cleanPw === "password123")) {
            user = DEMO_USER;
        } else if ((cleanId === "admin" || cleanId === "admin@example.com" || cleanId === "admin@aetheria.org") &&
                   (cleanPw === "Admin@123" || cleanPw === "admin123")) {
            user = DEMO_ADMIN;
        }
    }

    if (!user) {
        return { success: false, message: 'No registered account found with these credentials.' };
    }

    if (user.status === 'disabled') {
        return { success: false, message: 'Your account has been disabled by an administrator. Please contact support.' };
    }

    if (user.password && user.password !== cleanPw) {
        return { success: false, message: 'Incorrect password credentials. Please verify and retry.' };
    }

    const token = 'token-' + btoa(JSON.stringify({ userId: user.id, email: user.email, username: user.username, role: user.role, time: Date.now() }));
    setAuthToken(token);
    setActiveUser(user);

    return {
        success: true,
        message: `Welcome back, ${user.name || user.firstName || user.username}!`,
        data: {
            token,
            user
        }
    };
}

async function apiSignup(userData) {
    ensureLocalDatabase();
    const email = (userData.email || '').trim().toLowerCase();
    const username = (userData.username || email.split('@')[0] || '').trim().toLowerCase();
    const password = userData.password || '';

    if (!email || !email.includes('@')) {
        return { success: false, message: 'A valid email address is required.' };
    }
    if (!username || username.length < 3) {
        return { success: false, message: 'Username must be at least 3 characters.' };
    }
    if (!password || password.length < 6) {
        return { success: false, message: 'Password must be at least 6 characters long.' };
    }

    // 1. Attempt Live SQL Database Signup
    const apiResult = await callApi('/auth/register', 'POST', {
        email,
        username,
        password,
        firstName: userData.firstName || '',
        lastName: userData.lastName || '',
        gender: userData.gender || 'Other',
        name: userData.name || `${userData.firstName || ''} ${userData.lastName || ''}`.trim()
    });

    if (apiResult) {
        if (apiResult.success && apiResult.data) {
            setAuthToken(apiResult.data.token);
            setActiveUser(apiResult.data.user);

            try {
                let users = JSON.parse(localStorage.getItem("aetheria_users") || "[]");
                users.push(apiResult.data.user);
                localStorage.setItem("aetheria_users", JSON.stringify(users));
            } catch (e) {}

            return apiResult;
        } else {
            return apiResult;
        }
    }

    // 2. Resilient Fallback Engine
    let users = [];
    try {
        users = JSON.parse(localStorage.getItem("aetheria_users") || "[]");
    } catch (e) {
        users = [];
    }

    if (users.some(u => u.email && u.email.toLowerCase() === email)) {
        return { success: false, message: 'An account with this email address is already registered.' };
    }
    if (users.some(u => u.username && u.username.toLowerCase() === username)) {
        return { success: false, message: 'This username is already taken. Please choose another.' };
    }

    const newId = users.length ? Math.max(...users.map(u => u.id || 0)) + 1 : 10;
    const name = `${userData.firstName || ''} ${userData.lastName || ''}`.trim() || username;
    const newUser = {
        id: newId,
        username,
        email,
        password,
        name,
        firstName: userData.firstName || '',
        lastName: userData.lastName || '',
        gender: userData.gender || 'Other',
        role: 'member',
        status: 'active',
        genre: 'Sci-Fi & Fantasy',
        avatar: '1',
        bio: 'Avid reader and learner.',
        premium: 0,
        createdAt: new Date().toISOString()
    };

    users.push(newUser);
    localStorage.setItem("aetheria_users", JSON.stringify(users));

    const token = 'token-' + btoa(JSON.stringify({ userId: newId, email, username }));
    setAuthToken(token);
    setActiveUser(newUser);

    return {
        success: true,
        message: 'Account created successfully! Welcome to Aetheria Library.',
        data: {
            token,
            user: newUser
        }
    };
}

async function apiLogout() {
    callApi('/auth/logout', 'POST').catch(() => {});
    clearSession();
    return { success: true };
}

async function apiGetMe() {
    const apiResult = await callApi('/auth/me', 'GET');
    if (apiResult && apiResult.success && apiResult.data) {
        setActiveUser(apiResult.data);
        return apiResult;
    }
    const active = getActiveUser();
    return active ? { success: true, data: active } : { success: false, message: 'Not authenticated.' };
}

async function apiUpdateProfile(profileDataOrEmail, maybeData) {
    const profileData = maybeData || profileDataOrEmail || {};
    const active = getActiveUser();
    if (!active) return { success: false, message: 'Not authenticated.' };

    const updated = { ...active, ...profileData };
    setActiveUser(updated);

    callApi('/auth/profile', 'PUT', profileData).catch(() => {});

    try {
        let users = JSON.parse(localStorage.getItem("aetheria_users") || "[]");
        const idx = users.findIndex(u => u.id === active.id || u.email === active.email);
        if (idx !== -1) {
            users[idx] = { ...users[idx], ...profileData };
            localStorage.setItem("aetheria_users", JSON.stringify(users));
        }
    } catch (e) {}

    return {
        success: true,
        message: 'Profile updated successfully.',
        data: updated
    };
}

async function apiChangePassword(currentPassword, newPassword) {
    const active = getActiveUser();
    if (!active) return { success: false, message: 'Not authenticated.' };
    return apiResetPassword(active.email, newPassword);
}

async function apiResetPassword(email, newPassword) {
    ensureLocalDatabase();
    const cleanEmail = (email || '').trim().toLowerCase();
    if (!cleanEmail) {
        return { success: false, message: 'Please enter your account email address.' };
    }
    if (!newPassword || newPassword.length < 6) {
        return { success: false, message: 'Password must be at least 6 characters long.' };
    }

    const apiResult = await callApi('/auth/reset-password', 'POST', {
        email: cleanEmail,
        newPassword
    });

    if (apiResult && apiResult.success) {
        return apiResult;
    }

    try {
        let users = JSON.parse(localStorage.getItem("aetheria_users") || "[]");
        const idx = users.findIndex(u => u.email && u.email.toLowerCase() === cleanEmail);
        if (idx === -1) {
            return { success: false, message: 'No registered account found with this email address.' };
        }

        users[idx].password = newPassword;
        localStorage.setItem("aetheria_users", JSON.stringify(users));

        const active = getActiveUser();
        if (active && active.email && active.email.toLowerCase() === cleanEmail) {
            active.password = newPassword;
            setActiveUser(active);
        }

        return {
            success: true,
            message: 'Your password has been successfully updated. You can now sign in.'
        };
    } catch (e) {
        return { success: false, message: 'Failed to reset password.' };
    }
}

// ==========================================================================
// 4. Administrator Users Management Services
// ==========================================================================
async function apiGetUsers(search = '', role = 'all', status = 'all') {
    const params = new URLSearchParams();
    if (search) params.append('search', search);
    if (role !== 'all') params.append('role', role);
    if (status !== 'all') params.append('status', status);

    const apiResult = await callApi('/users' + (params.toString() ? `?${params}` : ''), 'GET');
    if (apiResult && apiResult.success && Array.isArray(apiResult.data)) {
        localStorage.setItem("aetheria_users", JSON.stringify(apiResult.data));
        return apiResult;
    }

    ensureLocalDatabase();
    let users = JSON.parse(localStorage.getItem("aetheria_users") || "[]");
    if (search) {
        const s = search.toLowerCase();
        users = users.filter(u =>
            (u.name && u.name.toLowerCase().includes(s)) ||
            (u.email && u.email.toLowerCase().includes(s)) ||
            (u.username && u.username.toLowerCase().includes(s))
        );
    }
    if (role !== 'all') users = users.filter(u => u.role === role);
    if (status !== 'all') users = users.filter(u => u.status === status);
    return { success: true, data: users };
}

async function apiGetUser(id) {
    const apiResult = await callApi(`/users/${id}`, 'GET');
    if (apiResult && apiResult.success) return apiResult;

    let users = JSON.parse(localStorage.getItem("aetheria_users") || "[]");
    const user = users.find(u => u.id === Number(id) || u.email === id);
    return user ? { success: true, data: user } : { success: false, message: 'User not found.' };
}

async function apiCreateUser(userData) {
    return apiSignup(userData);
}

async function apiUpdateUserStatus(userId, status) {
    const apiResult = await callApi(`/users/${userId}/status`, 'PUT', { status });

    let users = JSON.parse(localStorage.getItem("aetheria_users") || "[]");
    const idx = users.findIndex(u => u.id === Number(userId) || u.email === userId);
    if (idx !== -1) {
        users[idx].status = status;
        localStorage.setItem("aetheria_users", JSON.stringify(users));
    }

    if (apiResult && apiResult.success) return apiResult;
    return idx !== -1 ? { success: true, message: 'User status updated successfully.' } : { success: false, message: 'User not found.' };
}

async function apiAdminResetPassword(userId, newPassword) {
    const apiResult = await callApi(`/users/${userId}/password`, 'POST', { newPassword });

    let users = JSON.parse(localStorage.getItem("aetheria_users") || "[]");
    const idx = users.findIndex(u => u.id === Number(userId) || u.email === userId);
    if (idx !== -1) {
        users[idx].password = newPassword;
        localStorage.setItem("aetheria_users", JSON.stringify(users));
    }

    if (apiResult && apiResult.success) return apiResult;
    return idx !== -1 ? { success: true, message: 'Password updated successfully.' } : { success: false, message: 'User not found.' };
}

async function apiDeleteUser(userId) {
    const apiResult = await callApi(`/users/${userId}`, 'DELETE');

    let users = JSON.parse(localStorage.getItem("aetheria_users") || "[]");
    users = users.filter(u => u.id !== Number(userId) && u.email !== userId);
    localStorage.setItem("aetheria_users", JSON.stringify(users));

    if (apiResult && apiResult.success) return apiResult;
    return { success: true, message: 'User removed successfully.' };
}

async function apiGetAdminDashboard() {
    const apiResult = await callApi('/admin/dashboard', 'GET');
    if (apiResult && apiResult.success && apiResult.data) {
        return apiResult;
    }

    ensureLocalDatabase();
    const users = JSON.parse(localStorage.getItem("aetheria_users") || "[]");
    const books = JSON.parse(localStorage.getItem("aetheria_books") || "[]");
    const loans = JSON.parse(localStorage.getItem("aetheria_loans") || "[]");
    return {
        success: true,
        data: {
            stats: {
                totalUsers: users.length,
                totalBooks: books.length,
                activeLoans: loans.filter(l => l.status === 'active' || l.status === 'active-borrow').length,
                overdueLoans: loans.filter(l => l.status === 'overdue').length
            }
        },
        stats: {
            totalUsers: users.length,
            totalBooks: books.length,
            activeLoans: loans.filter(l => l.status === 'active' || l.status === 'active-borrow').length,
            overdueLoans: loans.filter(l => l.status === 'overdue').length
        }
    };
}

async function apiGetActivityLogs() {
    const apiResult = await callApi('/admin/activity-logs', 'GET');
    if (apiResult && apiResult.success && Array.isArray(apiResult.data)) {
        return apiResult;
    }
    const logs = JSON.parse(localStorage.getItem("aetheria_logs") || "[]");
    return { success: true, data: logs };
}

// ==========================================================================
// 5. Books Catalog Services (SQL Bridge + Local Cache)
// ==========================================================================
async function apiGetBooks(search = '', genre = 'all', available = 'all') {
    const params = new URLSearchParams();
    if (search) params.append('search', search);
    if (genre !== 'all') params.append('genre', genre);
    if (available !== 'all') params.append('available', available);

    const apiResult = await callApi('/books' + (params.toString() ? `?${params}` : ''), 'GET');
    if (apiResult && apiResult.success && Array.isArray(apiResult.data)) {
        localStorage.setItem("aetheria_books", JSON.stringify(apiResult.data));
        return apiResult;
    }

    let books = JSON.parse(localStorage.getItem("aetheria_books") || "[]");
    if (search) {
        const s = search.toLowerCase();
        books = books.filter(b =>
            (b.title && b.title.toLowerCase().includes(s)) ||
            (b.author && b.author.toLowerCase().includes(s))
        );
    }
    if (genre !== 'all') books = books.filter(b => b.genre === genre);
    if (available !== 'all') books = books.filter(b => available === 'true' ? b.available : !b.available);
    return { success: true, data: books };
}

async function apiGetBook(id) {
    const apiResult = await callApi(`/books/${id}`, 'GET');
    if (apiResult && apiResult.success && apiResult.data) {
        return apiResult;
    }
    const books = JSON.parse(localStorage.getItem("aetheria_books") || "[]");
    const book = books.find(b => b.id === Number(id));
    return book ? { success: true, data: book } : { success: false, message: 'Book not found.' };
}

async function apiCreateBook(bookData) {
    let books = JSON.parse(localStorage.getItem("aetheria_books") || "[]");
    const newId = books.length ? Math.max(...books.map(b => b.id || 0)) + 1 : 1;
    let newBook = { id: newId, available: true, ...bookData };

    const apiResult = await callApi('/books', 'POST', bookData);
    if (apiResult && apiResult.success && apiResult.data) {
        newBook = { ...newBook, ...apiResult.data };
    }

    books.unshift(newBook);
    localStorage.setItem("aetheria_books", JSON.stringify(books));
    notifyBooksChanged(books);

    return { success: true, data: newBook };
}

async function apiUpdateBook(id, bookData) {
    let books = JSON.parse(localStorage.getItem("aetheria_books") || "[]");
    const idx = books.findIndex(b => b.id === Number(id));
    if (idx !== -1) {
        books[idx] = { ...books[idx], ...bookData };
        localStorage.setItem("aetheria_books", JSON.stringify(books));
        notifyBooksChanged(books);
    }

    callApi(`/books/${id}`, 'PUT', bookData).catch(() => {});

    return { success: true, data: books[idx] || bookData };
}

async function apiDeleteBook(id) {
    let books = JSON.parse(localStorage.getItem("aetheria_books") || "[]");
    books = books.filter(b => b.id !== Number(id));
    localStorage.setItem("aetheria_books", JSON.stringify(books));
    notifyBooksChanged(books);

    callApi(`/books/${id}`, 'DELETE').catch(() => {});

    return { success: true };
}

// ==========================================================================
// 6. Circulation & Loans Services
// ==========================================================================
async function apiGetLoans() {
    const apiResult = await callApi('/loans', 'GET');
    if (apiResult && apiResult.success && Array.isArray(apiResult.data)) {
        localStorage.setItem("aetheria_loans", JSON.stringify(apiResult.data));
        return apiResult;
    }
    const loans = JSON.parse(localStorage.getItem("aetheria_loans") || "[]");
    return { success: true, data: loans };
}

async function apiBorrowBooks(bookIds, durationDays = 14) {
    const ids = Array.isArray(bookIds) ? bookIds : [bookIds];
    const user = getActiveUser() || DEMO_USER;

    callApi('/loans/borrow', 'POST', { bookIds: ids, durationDays }).catch(() => {});

    let loans = JSON.parse(localStorage.getItem("aetheria_loans") || "[]");
    let books = JSON.parse(localStorage.getItem("aetheria_books") || "[]");

    ids.forEach(bookId => {
        const id = loans.length ? Math.max(...loans.map(l => l.id || 0)) + 1 : 1001;
        loans.push({
            id,
            userId: user.email || user.username,
            bookId: Number(bookId),
            borrowDate: new Date().toISOString(),
            dueDate: new Date(Date.now() + durationDays * 86400000).toISOString(),
            returnDate: null,
            status: 'active-borrow'
        });
        const b = books.find(bk => bk.id === Number(bookId));
        if (b) b.available = false;
    });

    localStorage.setItem("aetheria_loans", JSON.stringify(loans));
    localStorage.setItem("aetheria_books", JSON.stringify(books));
    notifyBooksChanged(books);

    return { success: true, message: 'Books borrowed successfully.' };
}

async function apiReturnLoan(loanId, bookId) {
    callApi('/loans/return', 'POST', { loanId, bookId }).catch(() => {});

    let loans = JSON.parse(localStorage.getItem("aetheria_loans") || "[]");
    let books = JSON.parse(localStorage.getItem("aetheria_books") || "[]");
    const loan = loans.find(l => l.id === Number(loanId) || (bookId && l.bookId === Number(bookId)));
    if (loan) {
        loan.status = 'returned';
        loan.returnDate = new Date().toISOString();
    }
    if (bookId) {
        const b = books.find(bk => bk.id === Number(bookId));
        if (b) b.available = true;
    }
    localStorage.setItem("aetheria_loans", JSON.stringify(loans));
    localStorage.setItem("aetheria_books", JSON.stringify(books));
    notifyBooksChanged(books);

    return { success: true, message: 'Book returned.' };
}

async function apiExtendLoan(loanId) {
    callApi('/loans/extend', 'POST', { loanId }).catch(() => {});

    let loans = JSON.parse(localStorage.getItem("aetheria_loans") || "[]");
    const loan = loans.find(l => l.id === Number(loanId));
    if (loan) {
        loan.dueDate = new Date(Date.now() + 14 * 86400000).toISOString();
        localStorage.setItem("aetheria_loans", JSON.stringify(loans));
        return { success: true, message: 'Loan extended successfully.' };
    }
    return { success: false, message: 'Loan not found.' };
}

// ==========================================================================
// 7. Reviews, Wishlist & Reading Logs Services
// ==========================================================================
async function apiGetReviews(bookId = null) {
    const url = bookId ? `/reviews?bookId=${bookId}` : '/reviews';
    const apiResult = await callApi(url, 'GET');
    if (apiResult && apiResult.success && Array.isArray(apiResult.data)) {
        return apiResult;
    }

    let reviews = JSON.parse(localStorage.getItem("aetheria_reviews") || "[]");
    if (bookId) reviews = reviews.filter(r => r.bookId === Number(bookId));
    return { success: true, data: reviews };
}

async function apiSubmitReview(bookId, rating, text) {
    const user = getActiveUser() || DEMO_USER;
    callApi('/reviews', 'POST', { bookId, rating, text }).catch(() => {});

    let reviews = JSON.parse(localStorage.getItem("aetheria_reviews") || "[]");
    const newRev = {
        id: reviews.length ? Math.max(...reviews.map(r => r.id || 0)) + 1 : 1,
        bookId: Number(bookId),
        userId: user.email || user.username,
        userName: user.name || user.username,
        rating: Number(rating),
        text,
        date: new Date().toISOString()
    };
    reviews.push(newRev);
    localStorage.setItem("aetheria_reviews", JSON.stringify(reviews));
    return { success: true, data: newRev };
}

async function apiDeleteReview(id) {
    let reviews = JSON.parse(localStorage.getItem("aetheria_reviews") || "[]");
    reviews = reviews.filter(r => r.id !== Number(id));
    localStorage.setItem("aetheria_reviews", JSON.stringify(reviews));
    return { success: true };
}

async function apiGetWishlist() {
    const apiResult = await callApi('/wishlist', 'GET');
    if (apiResult && apiResult.success && Array.isArray(apiResult.data?.bookIds || apiResult.data)) {
        const list = apiResult.data.bookIds || apiResult.data;
        localStorage.setItem("aetheria_wishlist", JSON.stringify(list));
        return { success: true, data: list };
    }

    const list = JSON.parse(localStorage.getItem("aetheria_wishlist") || "[]");
    return { success: true, data: list };
}

async function apiToggleWishlist(bookId) {
    callApi('/wishlist/toggle', 'POST', { bookId }).catch(() => {});

    let list = JSON.parse(localStorage.getItem("aetheria_wishlist") || "[]");
    const num = Number(bookId);
    const idx = list.indexOf(num);
    let inWishlist = false;
    if (idx === -1) {
        list.push(num);
        inWishlist = true;
    } else {
        list.splice(idx, 1);
    }
    localStorage.setItem("aetheria_wishlist", JSON.stringify(list));
    return { success: true, inWishlist };
}

async function apiGetReading() {
    const r = JSON.parse(localStorage.getItem("aetheria_reading") || "[]");
    return { success: true, data: r };
}

async function apiRecordReading(bookId) {
    let list = JSON.parse(localStorage.getItem("aetheria_reading") || "[]");
    const num = Number(bookId);
    if (!list.includes(num)) list.push(num);
    localStorage.setItem("aetheria_reading", JSON.stringify(list));
    return { success: true };
}

// ==========================================================================
// 8. UI Notification Engine (Toasts & Modals)
// ==========================================================================
function showToast(title, message, type = "success") {
    let container = document.getElementById("toast-container");
    if (!container) {
        container = document.createElement("div");
        container.id = "toast-container";
        container.className = "toast-container";
        document.body.appendChild(container);
    }

    let iconClass = "fa-solid fa-circle-check";
    if (type === "error") iconClass = "fa-solid fa-triangle-exclamation";
    if (type === "warning") iconClass = "fa-solid fa-circle-exclamation";
    if (type === "info") iconClass = "fa-solid fa-circle-info";

    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <i class="${iconClass} toast-icon"></i>
        <div class="toast-content">
            <div class="toast-title">${title}</div>
            <div class="toast-message">${message}</div>
        </div>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.style.animation = "fadeIn 0.3s ease reverse forwards";
        setTimeout(() => {
            toast.remove();
        }, 300);
    }, 4000);
}
