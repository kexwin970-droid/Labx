<?php
/* ==========================================================================
   Aetheria Library — LAMP / XAMPP / WAMP Configuration
   Database settings and PDO connection factory for MySQL on localhost.
   ========================================================================== */

// Database Connection Settings
define('DB_HOST', getenv('DB_HOST') ?: '127.0.0.1');
define('DB_PORT', getenv('DB_PORT') ?: '3306');
define('DB_NAME', getenv('DB_NAME') ?: 'aetheria_library');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') !== false && getenv('DB_PASS') !== null ? getenv('DB_PASS') : '');
define('JWT_SECRET', getenv('JWT_SECRET') ?: 'aetheria_production_secret_key_2026_jwt_token_auth');

/**
 * Returns a shared PDO connection instance to MySQL database.
 * If the database does not exist yet, creates it automatically.
 *
 * @return PDO
 */
function getDBConnection() {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => true,
        ];

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Error 1049: Unknown database -> attempt auto-creation
            if ($e->getCode() == 1049 || strpos($e->getMessage(), 'Unknown database') !== false) {
                try {
                    $rootDsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";charset=utf8mb4";
                    $rootPdo = new PDO($rootDsn, DB_USER, DB_PASS, $options);
                    $rootPdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
                } catch (PDOException $ex) {
                    throw new Exception("Could not connect to or initialize database: " . $ex->getMessage());
                }
            } else {
                throw new Exception("Database connection error: " . $e->getMessage());
            }
        }
    }
    return $pdo;
}
