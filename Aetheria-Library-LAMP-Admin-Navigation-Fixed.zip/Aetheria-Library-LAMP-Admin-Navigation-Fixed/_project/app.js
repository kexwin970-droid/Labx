/* ==========================================================================
   Aetheria Library — Premium Application Logic
   ========================================================================== */

// ==========================================================================
// Mock Book Database (If not already initialized in LocalStorage)
// ==========================================================================
const DEFAULT_BOOKS = [
    {
        id: 1,
        title: "Dune",
        author: "Frank Herbert",
        genre: "Sci-Fi & Fantasy",
        description: "Set on the desert planet Arrakis, Dune is the story of the boy Paul Atreides, who would become the mysterious man known as Muad'Dib.",
        rating: 4.9,
        available: true,
        bgGradient: "linear-gradient(135deg, #c27d38, #5e3a15)",
        headerColor: "#f3f4f6"
    },
    {
        id: 2,
        title: "Neuromancer",
        author: "William Gibson",
        genre: "Sci-Fi & Fantasy",
        description: "Case, a low-level computer hacker, is hired by a mysterious employer to pull off the ultimate hack against a powerful artificial intelligence.",
        rating: 4.7,
        available: true,
        bgGradient: "linear-gradient(135deg, #0f172a, #06b6d4)",
        headerColor: "#67e8f9"
    },
    {
        id: 3,
        title: "The Shadow of the Wind",
        author: "Carlos Ruiz Zafón",
        genre: "Mystery & Thriller",
        description: "In the ruins of Barcelona, Daniel Sempere is taken to the Cemetery of Forgotten Books, where he selects a novel that changes the course of his life.",
        rating: 4.8,
        available: true,
        bgGradient: "linear-gradient(135deg, #3730a3, #4338ca)",
        headerColor: "#e0e7ff"
    },
    {
        id: 4,
        title: "Sapiens: A Brief History",
        author: "Yuval Noah Harari",
        genre: "History & Biography",
        description: "Dr Yuval Noah Harari spans the whole of human history, from the very first humans to walk the earth to the radical breakthroughs of the Cognitive revolution.",
        rating: 4.6,
        available: true,
        bgGradient: "linear-gradient(135deg, #78350f, #b45309)",
        headerColor: "#fef3c7"
    },
    {
        id: 5,
        title: "Clean Code",
        author: "Robert C. Martin",
        genre: "Technology & Science",
        description: "Even bad code can function. But if code isn't clean, it can bring a development organization to its knees. This book teaches you how to write software well.",
        rating: 4.8,
        available: true,
        bgGradient: "linear-gradient(135deg, #065f46, #059669)",
        headerColor: "#a7f3d0"
    },
    {
        id: 6,
        title: "The Silent Patient",
        author: "Alex Michaelides",
        genre: "Mystery & Thriller",
        description: "Alicia Berenson's life is seemingly perfect. One evening her husband returns home, and she shoots him five times in the face, and then never speaks another word.",
        rating: 4.5,
        available: true,
        bgGradient: "linear-gradient(135deg, #7f1d1d, #ef4444)",
        headerColor: "#fca5a5"
    },
    {
        id: 7,
        title: "Steve Jobs",
        author: "Walter Isaacson",
        genre: "History & Biography",
        description: "Based on more than forty interviews with Steve Jobs conducted over two years, this is the exclusive, riveting biography of the creative entrepreneur.",
        rating: 4.7,
        available: true,
        bgGradient: "linear-gradient(135deg, #1e293b, #475569)",
        headerColor: "#cbd5e1"
    },
    {
        id: 8,
        title: "Designing Data-Intensive Apps",
        author: "Martin Kleppmann",
        genre: "Technology & Science",
        description: "An in-depth guide through the absolute forest of data systems: databases, caches, stream processors, and the core designs powering modern tech giants.",
        rating: 4.9,
        available: true,
        bgGradient: "linear-gradient(135deg, #0f172a, #4f46e5)",
        headerColor: "#c7d2fe"
    },
    {
        id: 9,
        title: "The Great Gatsby",
        author: "F. Scott Fitzgerald",
        genre: "Fiction",
        description: "A portrait of the Jazz Age in all its decadence and excess, following Jay Gatsby's obsessive pursuit of his former lover, Daisy Buchanan.",
        rating: 4.4,
        available: true,
        bgGradient: "linear-gradient(135deg, #1e1b4b, #db2777)",
        headerColor: "#fbcfe8"
    },
    {
        id: 10,
        title: "Foundation",
        author: "Isaac Asimov",
        genre: "Sci-Fi & Fantasy",
        description: "Hari Seldon foresees the fall of the Galactic Empire and the dark age that will follow. He creates a Foundation to preserve humanity's knowledge.",
        rating: 4.7,
        available: true,
        bgGradient: "linear-gradient(135deg, #172554, #3b82f6)",
        headerColor: "#bfdbfe"
    },
    {
        id: 11,
        title: "Educated",
        author: "Tara Westover",
        genre: "History & Biography",
        description: "An unforgettable memoir about a young girl who, kept out of school in the mountains of Idaho, leaves her survivalist family to earn a PhD from Cambridge.",
        rating: 4.6,
        available: true,
        bgGradient: "linear-gradient(135deg, #14532d, #15803d)",
        headerColor: "#dcfce7"
    },
    {
        id: 12,
        title: "The Hobbit",
        author: "J.R.R. Tolkien",
        genre: "Sci-Fi & Fantasy",
        description: "Bilbo Baggins is a hobbit who enjoys a comfortable, unambitious life. His contentment is disturbed when Gandalf and a company of dwarves arrive.",
        rating: 4.9,
        available: true,
        bgGradient: "linear-gradient(135deg, #1e3a8a, #7e22ce)",
        headerColor: "#e9d5ff"
    },
    {
        id: 13,
        title: "Alice's Adventures in Wonderland by Lewis Carroll",
        author: "Lewis Carroll",
        genre: "Fantazy",
        description: "Down the rabbit hole, Alice enters a whimsical, nonsensical dream world populated by unforgettable characters like the Cheshire Cat, the Mad Hatter, the March Hare, and the Queen of Hearts.",
        rating: 4.8,
        available: true,
        bgGradient: "linear-gradient(135deg, #3b0764, #701a75, #ec4899)",
        headerColor: "#fbcfe8",
        isbn: "978-0141439761",
        pages: 192,
        readUrl: "https://www.gutenberg.org/ebooks/11?utm_source=chatgpt.com"
    },
    {
        id: 14,
        title: "The First Men in the Moon by H. G. Wells",
        author: "H. G. Wells",
        genre: "Technology and science",
        description: "A businessman and an eccentric scientist construct a sphere of gravity-defying substance and embark on a perilous voyage to the Moon, discovering an extraterrestrial civilization beneath its surface.",
        rating: 4.7,
        available: true,
        bgGradient: "linear-gradient(135deg, #09203f, #537895)",
        headerColor: "#e0f2fe",
        isbn: "978-0141441085",
        pages: 240,
        readUrl: "https://www.gutenberg.org/ebooks/1013?utm_source=chatgpt.com"
    },
    {
        id: 43,
        title: "1984",
        author: "George Orwell",
        genre: "Fiction",
        description: "In a totalitarian society ruled by Big Brother, Winston Smith struggles to maintain his sanity and humanity in a world of perpetual surveillance and propaganda.",
        rating: 4.8,
        available: true,
        bgGradient: "linear-gradient(135deg, #1c1917, #78716c)",
        headerColor: "#e7e5e4"
    },
    {
        id: 44,
        title: "To Kill a Mockingbird",
        author: "Harper Lee",
        genre: "Fiction",
        description: "Through the eyes of young Scout Finch, this novel explores racial injustice and moral growth in the Deep South during the 1930s.",
        rating: 4.9,
        available: true,
        bgGradient: "linear-gradient(135deg, #365314, #84cc16)",
        headerColor: "#ecfccb"
    },
    {
        id: 15,
        title: "The Hitchhiker's Guide to the Galaxy",
        author: "Douglas Adams",
        genre: "Sci-Fi & Fantasy",
        description: "Seconds before Earth is demolished for a galactic freeway, Arthur Dent is whisked off the planet by his friend Ford Prefect on a wild journey through space.",
        rating: 4.7,
        available: true,
        bgGradient: "linear-gradient(135deg, #0c4a6e, #38bdf8)",
        headerColor: "#e0f2fe"
    },
    {
        id: 16,
        title: "Brave New World",
        author: "Aldous Huxley",
        genre: "Fiction",
        description: "In a futuristic World State, citizens are engineered and conditioned into an intelligence-based social hierarchy. One man dares to challenge the system.",
        rating: 4.6,
        available: true,
        bgGradient: "linear-gradient(135deg, #4a044e, #c026d3)",
        headerColor: "#fae8ff"
    },
    {
        id: 17,
        title: "The Art of War",
        author: "Sun Tzu",
        genre: "History & Biography",
        description: "An ancient Chinese military treatise that has influenced both Eastern and Western military strategy, business tactics, and legal planning for centuries.",
        rating: 4.5,
        available: true,
        bgGradient: "linear-gradient(135deg, #7f1d1d, #991b1b)",
        headerColor: "#fef2f2"
    },
    {
        id: 18,
        title: "The Pragmatic Programmer",
        author: "David Thomas & Andrew Hunt",
        genre: "Technology & Science",
        description: "From journeyman to master, this book examines the core process of software development and offers practical advice for becoming a better programmer.",
        rating: 4.7,
        available: true,
        bgGradient: "linear-gradient(135deg, #134e4a, #2dd4bf)",
        headerColor: "#ccfbf1"
    },
    {
        id: 19,
        title: "Gone Girl",
        author: "Gillian Flynn",
        genre: "Mystery & Thriller",
        description: "On their fifth wedding anniversary, Amy Dunne disappears. Her husband Nick becomes the prime suspect as dark secrets about their marriage surface.",
        rating: 4.4,
        available: true,
        bgGradient: "linear-gradient(135deg, #450a0a, #dc2626)",
        headerColor: "#fee2e2"
    },
    {
        id: 20,
        title: "A Brief History of Time",
        author: "Stephen Hawking",
        genre: "Technology & Science",
        description: "From the Big Bang to black holes, Hawking explores the fundamental questions about the universe in a way that is accessible to the general reader.",
        rating: 4.8,
        available: true,
        bgGradient: "linear-gradient(135deg, #020617, #1e40af)",
        headerColor: "#bfdbfe"
    },
    {
        id: 21,
        title: "The Alchemist",
        author: "Paulo Coelho",
        genre: "Fiction",
        description: "A young Andalusian shepherd named Santiago travels from Spain to the Egyptian pyramids in search of treasure, discovering the true meaning of life along the way.",
        rating: 4.6,
        available: true,
        bgGradient: "linear-gradient(135deg, #92400e, #f59e0b)",
        headerColor: "#fef3c7"
    },
    {
        id: 22,
        title: "The Girl with the Dragon Tattoo",
        author: "Stieg Larsson",
        genre: "Mystery & Thriller",
        description: "A journalist and a young computer hacker investigate a wealthy family's dark secrets and a decades-old disappearance in this gripping Swedish thriller.",
        rating: 4.5,
        available: true,
        bgGradient: "linear-gradient(135deg, #0f172a, #334155)",
        headerColor: "#e2e8f0"
    },
    {
        id: 23,
        title: "Ender's Game",
        author: "Orson Scott Card",
        genre: "Sci-Fi & Fantasy",
        description: "In a future where Earth has barely survived alien invasions, a brilliant child is recruited to an elite military academy in space to prepare for the final battle.",
        rating: 4.7,
        available: true,
        bgGradient: "linear-gradient(135deg, #1e1b4b, #6366f1)",
        headerColor: "#e0e7ff"
    },
    {
        id: 24,
        title: "Thinking, Fast and Slow",
        author: "Daniel Kahneman",
        genre: "Philosophy & Psychology",
        description: "Nobel laureate Kahneman reveals the two systems that drive the way we think — fast, intuitive thinking and slow, deliberate reasoning — and their profound impact.",
        rating: 4.7,
        available: true,
        bgGradient: "linear-gradient(135deg, #3b0764, #a855f7)",
        headerColor: "#f3e8ff"
    },
    {
        id: 25,
        title: "The Catcher in the Rye",
        author: "J.D. Salinger",
        genre: "Fiction",
        description: "Holden Caulfield narrates his experiences in New York City after being expelled from prep school, grappling with teenage alienation and loss of innocence.",
        rating: 4.3,
        available: true,
        bgGradient: "linear-gradient(135deg, #b91c1c, #fbbf24)",
        headerColor: "#fef9c3"
    },
    {
        id: 26,
        title: "The Martian",
        author: "Andy Weir",
        genre: "Sci-Fi & Fantasy",
        description: "Astronaut Mark Watney is stranded alone on Mars after his crew evacuates. Armed with ingenuity and wit, he must find a way to survive and signal Earth.",
        rating: 4.8,
        available: true,
        bgGradient: "linear-gradient(135deg, #9a3412, #ea580c)",
        headerColor: "#ffedd5"
    },
    {
        id: 27,
        title: "Atomic Habits",
        author: "James Clear",
        genre: "Philosophy & Psychology",
        description: "A proven framework for improving every day through tiny changes in behavior. Learn how small habits compound into remarkable results over time.",
        rating: 4.8,
        available: true,
        bgGradient: "linear-gradient(135deg, #164e63, #06b6d4)",
        headerColor: "#cffafe"
    },
    {
        id: 28,
        title: "Crime and Punishment",
        author: "Fyodor Dostoevsky",
        genre: "Fiction",
        description: "A destitute former student in St. Petersburg commits a murder and must grapple with guilt, paranoia, and the pursuit of redemption in this psychological masterwork.",
        rating: 4.6,
        available: true,
        bgGradient: "linear-gradient(135deg, #27272a, #71717a)",
        headerColor: "#e4e4e7"
    },
    {
        id: 29,
        title: "Cosmos",
        author: "Carl Sagan",
        genre: "Technology & Science",
        description: "A sweeping journey through the universe exploring the evolution of galaxies, stars, life, and civilization, presented with poetic wonder and scientific rigor.",
        rating: 4.9,
        available: true,
        bgGradient: "linear-gradient(135deg, #0f172a, #7c3aed)",
        headerColor: "#ddd6fe"
    },
    {
        id: 30,
        title: "And Then There Were None",
        author: "Agatha Christie",
        genre: "Mystery & Thriller",
        description: "Ten strangers are lured to a remote island and begin to die one by one, each death echoing a line from a nursery rhyme. The world's best-selling mystery novel.",
        rating: 4.7,
        available: true,
        bgGradient: "linear-gradient(135deg, #312e81, #4f46e5)",
        headerColor: "#c7d2fe"
    },
    {
        id: 31,
        title: "The Name of the Wind",
        author: "Patrick Rothfuss",
        genre: "Sci-Fi & Fantasy",
        description: "Kvothe, a legendary figure, recounts his transformation from a young orphan to the most notorious wizard his world has ever seen.",
        rating: 4.8,
        available: true,
        bgGradient: "linear-gradient(135deg, #831843, #e11d48)",
        headerColor: "#ffe4e6"
    },
    {
        id: 32,
        title: "Meditations",
        author: "Marcus Aurelius",
        genre: "Philosophy & Psychology",
        description: "The private journal of the Roman Emperor Marcus Aurelius, offering timeless reflections on Stoic philosophy, self-discipline, and the nature of existence.",
        rating: 4.7,
        available: true,
        bgGradient: "linear-gradient(135deg, #78350f, #d97706)",
        headerColor: "#fef3c7"
    },
    {
        id: 33,
        title: "The Da Vinci Code",
        author: "Dan Brown",
        genre: "Mystery & Thriller",
        description: "Harvard symbologist Robert Langdon is called to the Louvre to examine cryptic clues in Da Vinci's paintings, uncovering a secret society guarding an ancient truth.",
        rating: 4.3,
        available: true,
        bgGradient: "linear-gradient(135deg, #1e3a5f, #3b82f6)",
        headerColor: "#dbeafe"
    },
    {
        id: 34,
        title: "Fahrenheit 451",
        author: "Ray Bradbury",
        genre: "Fiction",
        description: "In a dystopian future where books are banned and firemen burn them, Guy Montag begins to question his role and embarks on a dangerous quest for knowledge.",
        rating: 4.5,
        available: true,
        bgGradient: "linear-gradient(135deg, #c2410c, #fb923c)",
        headerColor: "#fff7ed"
    },
    {
        id: 35,
        title: "Algorithms to Live By",
        author: "Brian Christian & Tom Griffiths",
        genre: "Technology & Science",
        description: "A fascinating exploration of how computer algorithms can be applied to everyday life, from sorting your closet to finding a parking spot to managing your time.",
        rating: 4.5,
        available: true,
        bgGradient: "linear-gradient(135deg, #115e59, #14b8a6)",
        headerColor: "#ccfbf1"
    },
    {
        id: 36,
        title: "The Count of Monte Cristo",
        author: "Alexandre Dumas",
        genre: "Fiction",
        description: "Wrongfully imprisoned, Edmond Dantès escapes and discovers a vast fortune, transforming himself into the Count of Monte Cristo to exact revenge on those who betrayed him.",
        rating: 4.8,
        available: true,
        bgGradient: "linear-gradient(135deg, #1e293b, #ca8a04)",
        headerColor: "#fef9c3"
    },
    {
        id: 37,
        title: "Becoming",
        author: "Michelle Obama",
        genre: "History & Biography",
        description: "The former First Lady chronicles her journey from the South Side of Chicago to the White House, reflecting on her experiences that shaped her and her advocacy work.",
        rating: 4.6,
        available: true,
        bgGradient: "linear-gradient(135deg, #581c87, #a78bfa)",
        headerColor: "#ede9fe"
    },
    {
        id: 38,
        title: "The Shining",
        author: "Stephen King",
        genre: "Mystery & Thriller",
        description: "Jack Torrance takes a winter caretaker position at the isolated Overlook Hotel. As supernatural forces begin to unravel his sanity, his family faces mortal danger.",
        rating: 4.6,
        available: true,
        bgGradient: "linear-gradient(135deg, #18181b, #dc2626)",
        headerColor: "#fca5a5"
    },
    {
        id: 39,
        title: "Man's Search for Meaning",
        author: "Viktor E. Frankl",
        genre: "Philosophy & Psychology",
        description: "A Holocaust survivor and psychiatrist chronicles his experiences in Nazi concentration camps and describes his psychotherapeutic method of finding purpose in life.",
        rating: 4.9,
        available: true,
        bgGradient: "linear-gradient(135deg, #1f2937, #6b7280)",
        headerColor: "#f3f4f6"
    },
    {
        id: 40,
        title: "Hyperion",
        author: "Dan Simmons",
        genre: "Sci-Fi & Fantasy",
        description: "Seven pilgrims set forth on a voyage to the Time Tombs on Hyperion, each sharing a harrowing tale that reveals the secrets of the enigmatic Shrike creature.",
        rating: 4.7,
        available: true,
        bgGradient: "linear-gradient(135deg, #0a0a23, #e879f9)",
        headerColor: "#fae8ff"
    },
    {
        id: 41,
        title: "Pride and Prejudice",
        author: "Jane Austen",
        genre: "Fiction",
        description: "The spirited Elizabeth Bennet navigates issues of manners, morality, and marriage in Georgian-era England, clashing and ultimately falling for the proud Mr. Darcy.",
        rating: 4.7,
        available: true,
        bgGradient: "linear-gradient(135deg, #be185d, #f9a8d4)",
        headerColor: "#fce7f3"
    },
    {
        id: 42,
        title: "The Gene: An Intimate History",
        author: "Siddhartha Mukherjee",
        genre: "Technology & Science",
        description: "A sweeping exploration of the gene — from Mendel's garden experiments to CRISPR — weaving together science, history, and the author's own family story.",
        rating: 4.6,
        available: true,
        bgGradient: "linear-gradient(135deg, #064e3b, #34d399)",
        headerColor: "#d1fae5"
    }
];

const DEFAULT_USERS = [
    {
        email: "demo@example.com",
        password: "Demo@123",
        name: "Arthur Pendragon",
        firstName: "Arthur",
        lastName: "Pendragon",
        gender: "Male",
        genre: "Sci-Fi & Fantasy",
        avatar: "1",
        role: "member",
        status: "active"
    },
    {
        email: "admin@example.com",
        password: "Admin@123",
        name: "System Administrator",
        firstName: "System",
        lastName: "Administrator",
        gender: "Other",
        genre: "Technology & Science",
        avatar: "1",
        role: "admin",
        status: "active"
    }
];

// Quotes of the Day Database
const QUOTES = [
    { text: "A room without books is like a body without a soul.", author: "Marcus Tullius Cicero" },
    { text: "I have always imagined that Paradise will be a kind of library.", author: "Jorge Luis Borges" },
    { text: "Books are a uniquely portable magic.", author: "Stephen King" },
    { text: "Read the best books first, or you may not have a chance to read them at all.", author: "Henry David Thoreau" },
    { text: "The only thing that you absolutely have to know, is the location of the library.", author: "Albert Einstein" }
];

// Cities for location selection
const CITIES = [
    { name: "New York, USA", lat: 40.7128, lng: -74.0060 },
    { name: "London, UK", lat: 51.5074, lng: -0.1278 },
    { name: "Paris, France", lat: 48.8566, lng: 2.3522 },
    { name: "Tokyo, Japan", lat: 35.6762, lng: 139.6503 },
    { name: "Bengaluru, India", lat: 12.9716, lng: 77.5946 },
    { name: "Sydney, Australia", lat: -33.8688, lng: 151.2093 },
    { name: "Toronto, Canada", lat: 43.6532, lng: -79.3832 },
    { name: "Dubai, UAE", lat: 25.2048, lng: 55.2708 }
];

// Mock library branches database
const NEARBY_LIBRARIES = [
    { id: 1, name: "Aetheria Central Branch", address: "120 Library Ave, New York", lat: 40.7308, lng: -73.9973, hours: "9 AM – 9 PM", phone: "+1 212-555-0142" },
    { id: 2, name: "Westminster Reading Hall", address: "45 St. Martin's Lane, London", lat: 51.5115, lng: -0.1278, hours: "10 AM – 8 PM", phone: "+44 20 7946 0321" },
    { id: 3, name: "Seine Literary Sanctuary", address: "8 Rue de Rivoli, Paris", lat: 48.8606, lng: 2.3376, hours: "10 AM – 7 PM", phone: "+33 1 42 60 20 10" },
    { id: 4, name: "Shibuya Knowledge Tower", address: "2-1 Dogenzaka, Tokyo", lat: 35.6595, lng: 139.6986, hours: "9 AM – 10 PM", phone: "+81 3-5466-0111" },
    { id: 5, name: "MG Road Book Pavilion", address: "24 MG Road, Bengaluru", lat: 12.9719, lng: 77.5936, hours: "9 AM – 8 PM", phone: "+91 80 2558 2211" },
    { id: 6, name: "Harbourfront Library", address: "30 Hickson Rd, Sydney", lat: -33.8615, lng: 151.2090, hours: "9 AM – 9 PM", phone: "+61 2 9273 1414" },
    { id: 7, name: "Yorkville Study Archive", address: "110 Bloor St W, Toronto", lat: 43.6690, lng: -79.3925, hours: "10 AM – 8 PM", phone: "+1 416-393-7660" },
    { id: 8, name: "Marina Library Dome", address: "66 Marina Blvd, Dubai", lat: 25.1972, lng: 55.2744, hours: "8 AM – 11 PM", phone: "+971 4 305 1500" },
    { id: 9, name: "Brooklyn Shelf Commons", address: "10 Grand St, New York", lat: 40.7144, lng: -73.9613, hours: "9 AM – 8 PM", phone: "+1 718-555-0190" },
    { id: 10, name: "Camden Page Retreat", address: "22 Camden High St, London", lat: 51.5390, lng: -0.1426, hours: "10 AM – 7 PM", phone: "+44 20 7485 9000" }
];

// Active location reference { lat, lng, label }
let activeLocation = null;

// ==========================================================================
// Application State Controller
// ==========================================================================
let state = {
    books: [],
    users: [],
    activeUser: null,
    cart: [], // Array of book IDs in the active session's cart
    borrowedHistory: [], // Global borrowing logs
    activeCategory: "all",
    searchQuery: "",
    premiumMembership: false
};

// ==========================================================================
// Initialize Application Data
// ==========================================================================
function initDatabase() {
    try {
        const storedBooks = localStorage.getItem("aetheria_books");
        if (storedBooks) {
            let parsed = JSON.parse(storedBooks);
            if (Array.isArray(parsed)) {
                let modified = false;
                parsed = parsed.map(b => {
                    const def = DEFAULT_BOOKS.find(db => db.id === b.id);
                    if (def && (!b.author || typeof b.title === 'number' || b.author === 'undefined' || !b.genre)) {
                        modified = true;
                        return { ...def };
                    }
                    return b;
                });
                // Ensure all default books (including Alice and Wells books) are present in state.books
                DEFAULT_BOOKS.forEach(defBook => {
                    const exists = parsed.some(b => b.id === defBook.id || (b.title && b.title.toLowerCase().trim() === defBook.title.toLowerCase().trim()) || (defBook.readUrl && b.readUrl === defBook.readUrl));
                    if (!exists) {
                        parsed.push({ ...defBook });
                        modified = true;
                    }
                });
                state.books = parsed;
                if (modified) {
                    localStorage.setItem("aetheria_books", JSON.stringify(state.books));
                }
            } else {
                state.books = [...DEFAULT_BOOKS];
            }
        } else {
            state.books = [...DEFAULT_BOOKS];
            localStorage.setItem("aetheria_books", JSON.stringify(DEFAULT_BOOKS));
        }
    } catch (e) {
        state.books = [...DEFAULT_BOOKS];
    }

    try {
        const storedUsers = localStorage.getItem("aetheria_users");
        if (storedUsers) {
            state.users = JSON.parse(storedUsers);
        } else {
            state.users = [...DEFAULT_USERS];
            localStorage.setItem("aetheria_users", JSON.stringify(DEFAULT_USERS));
        }
    } catch (e) {
        state.users = [...DEFAULT_USERS];
    }
    ensureAdminAccount();

    try {
        const storedLoans = localStorage.getItem("aetheria_loans");
        if (storedLoans) {
            state.borrowedHistory = JSON.parse(storedLoans);
            if (Array.isArray(state.borrowedHistory)) {
                state.borrowedHistory = state.borrowedHistory.map(l => {
                    if (l.bookId === 1 || l.bookId === 2 || l.bookId === 3) {
                        return { ...l, status: 'returned' };
                    }
                    return l;
                });
                localStorage.setItem("aetheria_loans", JSON.stringify(state.borrowedHistory));
            }
        } else {
            state.borrowedHistory = [];
            localStorage.setItem("aetheria_loans", JSON.stringify([]));
        }
    } catch (e) {
        state.borrowedHistory = [];
    }
}

// Guarantee predefined administrator accounts exist.
const ADMIN_ACCOUNT = {
    email: "admin@example.com",
    password: "Admin@123",
    name: "System Administrator",
    firstName: "System",
    lastName: "Administrator",
    gender: "Other",
    genre: "Technology & Science",
    avatar: "1",
    role: "admin",
    status: "active"
};

function ensureAdminAccount() {
    const exists = state.users.some(u => u.email === ADMIN_ACCOUNT.email || u.email === "admin@aetheria.org");
    if (!exists) {
        state.users.push({ ...ADMIN_ACCOUNT });
    } else {
        const admin = state.users.find(u => u.email === ADMIN_ACCOUNT.email || u.email === "admin@aetheria.org");
        if (admin) admin.role = "admin";
    }
    try {
        localStorage.setItem("aetheria_users", JSON.stringify(state.users));
    } catch (e) {}
}

function loadUserCartAndSession() {
    state.cart = [];
    updateCartBadge();
}

// ==========================================================================
// Toast Notification Engine
// ==========================================================================
function showToast(title, message, type = "success") {
    const container = document.getElementById("toast-container");
    if (!container) return;

    // Set icon based on notification type
    let iconClass = "fa-solid fa-circle-check";
    if (type === "error") iconClass = "fa-solid fa-triangle-exclamation";
    if (type === "warning") iconClass = "fa-solid fa-circle-exclamation";
    if (type === "info") iconClass = "fa-solid fa-circle-info";

    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <i class="${iconClass} toast-icon"></i>
        <div class="toast-content">
            <div class="toast-title">${title}</div>
            <div class="toast-message">${message}</div>
        </div>
    `;

    container.appendChild(toast);

    // Auto delete elements after animation ends
    setTimeout(() => {
        toast.style.animation = "fadeIn 0.3s ease reverse forwards";
        setTimeout(() => {
            toast.remove();
        }, 300);
    }, 4000);
}

// Password toggler helper
function togglePasswordVisibility(fieldId) {
    const input = document.getElementById(fieldId);
    if (!input) return;
    const wrapper = input.closest(".input-wrapper") || input.parentElement;
    const button = (wrapper ? wrapper.querySelector(".password-toggle") : null) || input.nextElementSibling;
    const icon = button ? button.querySelector("i") : null;
    
    if (input.type === "password") {
        input.type = "text";
        if (icon) {
            icon.classList.remove("fa-eye");
            icon.classList.add("fa-eye-slash");
        }
        if (button) {
            button.setAttribute("aria-label", "Hide password");
            button.setAttribute("title", "Hide password");
        }
    } else {
        input.type = "password";
        if (icon) {
            icon.classList.remove("fa-eye-slash");
            icon.classList.add("fa-eye");
        }
        if (button) {
            button.setAttribute("aria-label", "Show password");
            button.setAttribute("title", "Show password");
        }
    }
}
window.togglePasswordVisibility = togglePasswordVisibility;


// Helper date formatters
function formatDate(dateObjOrString) {
    const d = new Date(dateObjOrString);
    if (isNaN(d.getTime())) return "N/A";
    return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

function addDays(date, days) {
    const result = new Date(date);
    result.setDate(result.getDate() + days);
    return result;
}

// ==========================================================================
// Router & Layout Toggle controller
// ==========================================================================
function switchMainViews() {
    const appSection = document.getElementById("app-section");

    if (state.activeUser) {
        if (appSection) {
            appSection.classList.remove("hidden");
            appSection.classList.add("slide-up");
            setupDashboard();
        }
    } else {
        window.location.href = "login.html";
    }
}

function handleTabSwitch(tabName) {
    // 1. Deactivate all navigation tab buttons and panel sections
    document.querySelectorAll(".tab-btn").forEach(btn => btn.classList.remove("active"));
    document.querySelectorAll(".tab-panel").forEach(panel => panel.classList.add("hidden"));

    // 2. Activate selected tab & panel
    const selectedBtn = document.querySelector(`.tab-btn[data-tab="${tabName}"]`);
    const selectedPanel = document.getElementById(`${tabName}-tab`);

    if (selectedBtn && selectedPanel) {
        selectedBtn.classList.add("active");
        selectedPanel.classList.remove("hidden");
        selectedPanel.classList.add("fade-in");
    }

    // 3. Render content specifically for the active panel
    if (tabName === "browse") {
        renderCatalog();
    } else if (tabName === "cart") {
        renderCart();
    } else if (tabName === "profile") {
        renderPremiumStatus();
        renderProfile();
    } else if (tabName === "nearby") {
        renderNearbyLibraries();
    } else if (tabName === "wishlist") {
        if (typeof renderWishlist === "function") renderWishlist();
    } else if (tabName === "admin") {
        if (typeof renderAdminPanel === "function") renderAdminPanel();
    }
}

// ==========================================================================
// User Session & Logout Controller
// ==========================================================================
function setupLogoutEvent() {
    const logoutBtn = document.getElementById("logout-btn");
    if (logoutBtn) {
        logoutBtn.addEventListener("click", () => {
            showToast("Logged Out", "Successfully signed out of session.", "info");
            state.activeUser = null;
            state.cart = [];
            try {
                localStorage.removeItem("aetheria_active_user");
            } catch (e) {}
            setTimeout(() => {
                window.location.href = "login.html";
            }, 400);
        });
    }
}

// ==========================================================================
// Dashboard initialization and controls
// ==========================================================================
function setupDashboard() {
    if (!state.activeUser) return;

    // 1. Populate navbar user information (elements are optional in the header)
    const avatarImg = document.getElementById("nav-user-avatar");
    const nameSpan = document.getElementById("nav-user-name");

    if (avatarImg) {
        avatarImg.src = getAvatarUrl(state.activeUser.name, getAvatarColor(state.activeUser.avatar));
        avatarImg.onerror = () => { avatarImg.src = generateLocalAvatar(state.activeUser.name); };
    }
    if (nameSpan) {
        if (state.activeUser.role === "admin") {
            nameSpan.innerHTML = `${state.activeUser.name} <span class="admin-console-badge" style="font-size:0.68rem;padding:2px 7px;margin-left:6px;"><i class="fa-solid fa-shield-halved"></i> Admin</span>`;
        } else {
            nameSpan.textContent = state.activeUser.name;
        }
    }

    // Role-based Admin navigation tab visibility
    const adminNavBtn = document.getElementById("admin-nav-tab");
    if (adminNavBtn) {
        if (state.activeUser.role === "admin") {
            adminNavBtn.classList.remove("hidden");
        } else {
            adminNavBtn.classList.add("hidden");
        }
    }

    // 2. Set dynamic greeting in Banner
    const hour = new Date().getHours();
    let greeting = "Welcome back, Bibliophile";
    if (hour < 12) greeting = "Good morning, Bibliophile";
    else if (hour < 18) greeting = "Good afternoon, Bibliophile";
    else greeting = "Good evening, Scholar";
    
    document.getElementById("hero-greeting").textContent = `${greeting}, ${state.activeUser.name.split(' ')[0]}`;

    // 3. Set random quote in Banner
    const randomQuote = QUOTES[Math.floor(Math.random() * QUOTES.length)];
    document.getElementById("hero-quote").innerHTML = `"${randomQuote.text}" &mdash; ${randomQuote.author}`;

    // 4. Update core numbers banner stats
    updateBannerStatistics();

    // 5. Render premium status
    renderPremiumStatus();

    // 6. Default tab
    handleTabSwitch("browse");
}

function isBookOnLoan(book) {
    if (!book) return false;
    if (book.available === false || book.available === 0 || !book.available) return true;
    if (Array.isArray(state.borrowedHistory) && state.borrowedHistory.some(l => (Number(l.bookId) === Number(book.id) || Number(l.book_id) === Number(book.id)) && l.status === 'active-borrow')) {
        return true;
    }
    return false;
}

function updateBannerStatistics() {
    const availableBooks = state.books.filter(b => !isBookOnLoan(b));
    const totalCount = availableBooks.length;
    const availableCount = availableBooks.length;
    
    const countEl = document.getElementById("stat-books-count");
    const availEl = document.getElementById("stat-available-count");
    if (countEl) countEl.textContent = totalCount;
    if (availEl) availEl.textContent = availableCount;
}

function getAvatarColor(avatarIndex) {
    const colors = {
        "1": "b6e3f4",
        "2": "d1c4e9",
        "3": "c8e6c9",
        "4": "ffcc80"
    };
    return colors[avatarIndex] || "b6e3f4";
}

// ==========================================================================
// 1. Catalog shelf filter & search systems
// ==========================================================================
// Decorative full bookshelf showcase (modern multi-tier bookcase)
// ==========================================================================
function renderBookshelfShowcase() {
    const bookcase = document.getElementById("bookcase");
    if (!bookcase) return;

    const availableBooks = state.books.filter(b => !isBookOnLoan(b));
    const booksPool = availableBooks.length ? availableBooks : state.books;
    if (booksPool.length === 0) return;

    const shelfCount = 3;
    const props = ["🪴", "🕰️", "💡", "🌿", "🗿"];
    let html = "";

    for (let s = 0; s < shelfCount; s++) {
        html += `<div class="shelf-row">`;

        const itemsPerShelf = 11;
        for (let i = 0; i < itemsPerShelf; i++) {
            const book = booksPool[(s * itemsPerShelf + i) % booksPool.length];
            const seed = (i * 7 + s * 13);
            const h = 92 + (seed % 5) * 16;
            const w = 22 + (seed % 3) * 5;

            // Occasionally render a horizontal stack of books for realism
            if ((i + s) % 6 === 4) {
                html += `
                    <div class="book-stack" style="--g:${book.bgGradient}" title="${book.title}">
                        <span></span><span></span><span></span>
                    </div>`;
            } else {
                const tilt = (seed % 4 === 0) ? "transform: rotate(-2deg);" : "";
                html += `
                    <div class="book-spine" style="background:${book.bgGradient}; height:${h}px; width:${w}px; ${tilt}" title="${book.title}">
                        <span class="spine-title">${book.title}</span>
                    </div>`;
            }
        }

        // A decorative prop at the end of every other shelf
        if (s % 2 === 0) {
            const prop = props[(s / 2) % props.length];
            html += `<div class="shelf-prop">${prop}</div>`;
        }

        html += `</div>`;
    }

    bookcase.innerHTML = html;
}

// ==========================================================================
function setupCatalogEvents() {
    const searchInput = document.getElementById("catalog-search");
    const clearBtn = document.getElementById("search-clear");
    const categoryPills = document.getElementById("category-pills");

    renderBookshelfShowcase();

    // Live search event
    searchInput.addEventListener("input", (e) => {
        state.searchQuery = e.target.value.trim().toLowerCase();
        
        if (state.searchQuery.length > 0) {
            clearBtn.classList.remove("hidden");
        } else {
            clearBtn.classList.add("hidden");
        }
        renderCatalog();
    });

    // Clear search event
    clearBtn.addEventListener("click", () => {
        searchInput.value = "";
        state.searchQuery = "";
        clearBtn.classList.add("hidden");
        renderCatalog();
    });

    // Category pills filter
    categoryPills.addEventListener("click", (e) => {
        const pill = e.target.closest(".pill");
        if (!pill) return;

        document.querySelectorAll(".category-pills .pill").forEach(p => p.classList.remove("active"));
        pill.classList.add("active");
        
        state.activeCategory = pill.getAttribute("data-category");
        renderCatalog();
    });
}

function renderCatalog() {
    const grid = document.getElementById("books-grid");
    if (!grid) return;

    // Filter books based on search filter & categories, excluding any on-loan books
    const filteredBooks = state.books.filter(book => {
        // Remove loan books from home page
        if (isBookOnLoan(book)) return false;

        const genreLower = (book.genre || "").toLowerCase();
        const catLower = (state.activeCategory || "all").toLowerCase();

        const normalizeGenre = (g) => (g || "").toLowerCase().replace(/&/g, 'and').replace(/\s+/g, ' ').trim();
        const normGenre = normalizeGenre(book.genre);
        const normCat = normalizeGenre(state.activeCategory);

        const matchesCategory = normCat === "all" ||
            genreLower === catLower ||
            normGenre === normCat ||
            (catLower === "fantazy" && (genreLower === "fantazy" || genreLower === "fantasy" || genreLower.includes("fantasy"))) ||
            (catLower.includes("fantasy") && (genreLower === "fantazy" || genreLower.includes("fantasy"))) ||
            (normCat.includes("technology") && normGenre.includes("technology"));
        
        const searchTarget = `${book.title} ${book.author} ${book.genre} ${book.description}`.toLowerCase();
        const matchesSearch = !state.searchQuery || searchTarget.includes(state.searchQuery.toLowerCase());
        
        return matchesCategory && matchesSearch;
    });

    if (filteredBooks.length === 0) {
        grid.innerHTML = `
            <div class="empty-state" style="grid-column: 1 / -1;">
                <i class="fa-solid fa-box-open"></i>
                <h4>No volumes found</h4>
                <p>Try modifying your filters or search keywords to locate the books.</p>
            </div>
        `;
        return;
    }

    grid.innerHTML = filteredBooks.map(book => {
        const inWishlist = (typeof isInWishlist === "function") && isInWishlist(book.id);
        const actionBtnHTML = `
            <div class="book-card-actions">
                <button class="wishlist-toggle ${inWishlist ? 'active' : ''}"
                    onclick="event.stopPropagation(); toggleWishlist(${book.id})"
                    title="${inWishlist ? 'Remove from Wishlist' : 'Add to Wishlist'}">
                    <i class="fa-${inWishlist ? 'solid' : 'regular'} fa-heart"></i>
                </button>
                <button class="btn btn-primary btn-sm"
                    onclick="event.stopPropagation(); startReading(${book.id})" title="Read this book">
                    <i class="fa-solid fa-book-open"></i> Read
                </button>
            </div>
        `;

        const ratingStars = Math.floor(book.rating);
        const starsHTML = '<i class="fa-solid fa-star"></i>'.repeat(ratingStars) + (book.rating % 1 !== 0 ? '<i class="fa-solid fa-star-half-stroke"></i>' : '');

        return `
            <div class="book-card glass-panel fade-in">
                <!-- Cover Area -->
                <div class="book-cover-container clickable" onclick="openBookDetails(${book.id})" title="View details">
                    <div class="book-cover-bg" style="background: ${book.bgGradient};"></div>
                    
                    <!-- Jacket Art -->
                    <div class="book-cover-jacket" style="background: ${book.bgGradient};">
                        <div class="spine-fold"></div>
                        <div class="jacket-header">Aetheria Shelf</div>
                        <div class="jacket-title" style="color: ${book.headerColor || 'white'};">${book.title}</div>
                        <div class="jacket-author">${book.author}</div>
                    </div>

                    <!-- Badge status -->
                    <span class="book-status-badge status-available">
                        Available
                    </span>
                </div>

                <!-- Book details -->
                <div class="book-details">
                    <span class="book-genre">${book.genre}</span>
                    <h4 class="book-title clickable" onclick="openBookDetails(${book.id})">${book.title}</h4>
                    <p class="book-author">By ${book.author}</p>
                    <p class="book-description">${book.description}</p>
                    
                    <div class="book-card-footer">
                        <div class="book-rating">
                            ${starsHTML}
                            <span>${book.rating}</span>
                        </div>
                        ${actionBtnHTML}
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

// Cart actions
function addToCart(bookId) {
    if (!state.activeUser) return;
    
    // Check borrowing limit
    const activeLoansCount = state.borrowedHistory.filter(h => h.userId === state.activeUser.email && h.status === 'active-borrow').length;
    if (activeLoansCount + state.cart.length >= 5) {
        showToast("Cart Overflow", "You cannot exceed a total of 5 concurrent borrowed books.", "warning");
        return;
    }

    if (!state.cart.includes(bookId)) {
        state.cart.push(bookId);
        updateCartBadge();
        renderCatalog();
        showToast("Book Added", "Added to your borrow cart list.", "success");
    }
}

function removeFromCart(bookId) {
    state.cart = state.cart.filter(id => id !== bookId);
    updateCartBadge();
    
    // Refresh whatever tab is open
    const isBrowseActive = document.querySelector(".tab-btn[data-tab='browse']").classList.contains("active");
    if (isBrowseActive) {
        renderCatalog();
    } else {
        renderCart();
    }
    showToast("Book Removed", "Removed from your borrow cart list.", "info");
}

function updateCartBadge() {
    const badge = document.getElementById("cart-badge");
    if (badge) {
        badge.textContent = state.cart.length;
        if (state.cart.length > 0) {
            badge.style.display = "inline-block";
        } else {
            badge.style.display = "none";
        }
    }
}

// ==========================================================================
// 2. Borrow cart & checkout module
// ==========================================================================
function renderCart() {
    const container = document.getElementById("cart-items-container");
    const checkoutBtn = document.getElementById("checkout-btn");
    const totalItemsText = document.getElementById("summary-total-items");
    const dueDateText = document.getElementById("summary-due-date");

    if (state.cart.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fa-solid fa-cart-flatbed-suitcases"></i>
                <h4>Your Cart is Empty</h4>
                <p>Browse our catalog shelves and select volumes to add to your cart list.</p>
                <button class="btn btn-secondary btn-sm" onclick="handleTabSwitch('browse')">Return to Browse</button>
            </div>
        `;
        checkoutBtn.disabled = true;
        totalItemsText.textContent = "0 Books";
        dueDateText.textContent = "N/A";
        return;
    }

    // Load actual book models
    const cartBooks = state.books.filter(b => state.cart.includes(b.id));

    container.innerHTML = cartBooks.map(book => `
        <div class="cart-item-row glass-panel fade-in">
            <div class="cart-item-jacket" style="background: ${book.bgGradient}; border-left: 2px solid rgba(0,0,0,0.3)"></div>
            <div class="cart-item-details">
                <h4>${book.title}</h4>
                <p>By ${book.author} &bull; ${book.genre}</p>
            </div>
            <button class="cart-item-remove" onclick="removeFromCart(${book.id})" title="Remove item">
                <i class="fa-solid fa-trash-can"></i>
            </button>
        </div>
    `).join('');

    // Summary calculation
    checkoutBtn.disabled = false;
    totalItemsText.textContent = `${state.cart.length} ${state.cart.length === 1 ? 'Book' : 'Books'}`;
    
    // Estimate due date (14 days from now)
    const estimateDue = addDays(new Date(), 14);
    dueDateText.textContent = formatDate(estimateDue);
}

function setupCheckoutEvents() {
    const checkoutBtn = document.getElementById("checkout-btn");
    checkoutBtn.addEventListener("click", () => {
        if (state.cart.length === 0) return;

        // Perform borrow actions
        const today = new Date();
        const dueDate = addDays(today, 14);

        state.cart.forEach(bookId => {
            // Find book in catalog and mark unavailable
            const bookIndex = state.books.findIndex(b => b.id === bookId);
            if (bookIndex !== -1) {
                state.books[bookIndex].available = false;
            }

            // Create history record
            const newRecord = {
                id: Date.now() + Math.random(), // Unique record ID
                userId: state.activeUser.email,
                bookId: bookId,
                borrowDate: today.toISOString(),
                dueDate: dueDate.toISOString(),
                returnDate: null,
                status: 'active-borrow'
            };
            state.borrowedHistory.unshift(newRecord);
        });

        try {
            localStorage.setItem("aetheria_loans", JSON.stringify(state.borrowedHistory));
            localStorage.setItem("aetheria_books", JSON.stringify(state.books));
        } catch (e) {}

        // Clear cart for active user
        const borrowedBookIds = [...state.cart];
        state.cart = [];
        updateCartBadge();
        updateBannerStatistics();

        showToast("Borrow Successful", "Your books are checked out! Happy reading.", "success");
        
        // Sync borrow transaction with MySQL database via REST API
        if (typeof apiBorrowBooks === 'function') {
            apiBorrowBooks(borrowedBookIds, 14)
                .catch(e => console.warn("Borrow transaction MySQL sync notice:", e));
        }

        // Transition to profile to see borrowed items
        handleTabSwitch("profile");
    });
}

// ==========================================================================
// 3. Profile details editing and active borrowing lists
// ==========================================================================
// ==========================================================================
// Payment Gateway Module
// ==========================================================================
let paymentState = {
    isProcessing: false,
    cardType: 'unknown'
};

function setupPaymentGateway() {
    const upgradeBtn = document.getElementById("upgrade-to-premium-btn");
    const closeBtn = document.getElementById("close-payment-modal-btn");
    const paymentForm = document.getElementById("payment-form");
    const retryBtn = document.getElementById("payment-retry-btn");
    const doneBtn = document.getElementById("payment-done-btn");
    const cardNumberInput = document.getElementById("card-number");
    const cardExpiryInput = document.getElementById("card-expiry");
    const cardNameInput = document.getElementById("cardholder-name");
    const cardCvvInput = document.getElementById("card-cvv");

    if (upgradeBtn) {
        upgradeBtn.addEventListener("click", () => {
            openPaymentModal();
        });
    }

    if (closeBtn) {
        closeBtn.addEventListener("click", () => {
            closePaymentModal();
        });
    }

    if (paymentForm) {
        paymentForm.addEventListener("submit", (e) => {
            e.preventDefault();
            processPayment();
        });
    }

    if (retryBtn) {
        retryBtn.addEventListener("click", () => {
            resetPaymentForm();
        });
    }

    if (doneBtn) {
        doneBtn.addEventListener("click", () => {
            closePaymentModal();
            handleTabSwitch("profile");
            showToast("Premium Activated", "Enjoy your Aetheria Premium benefits!", "success");
        });
    }

    // Close modal on overlay click or escape key
    const overlay = document.getElementById("payment-modal-overlay");
    if (overlay) {
        overlay.addEventListener("click", (e) => {
            if (e.target === overlay && !paymentState.isProcessing) {
                closePaymentModal();
            }
        });
    }

    document.addEventListener("keydown", (e) => {
        if (e.key === "Escape") {
            const overlay = document.getElementById("payment-modal-overlay");
            if (overlay && !overlay.classList.contains("hidden") && !paymentState.isProcessing) {
                closePaymentModal();
            }
        }
    });

    // Card number formatting and detection
    if (cardNumberInput) {
        cardNumberInput.addEventListener("input", (e) => {
            let value = e.target.value.replace(/\D/g, "");
            value = value.substring(0, 16);
            let formatted = value.replace(/(\d{4})(?=\d)/g, "$1 ");
            e.target.value = formatted;

            const cardType = detectCardType(value);
            paymentState.cardType = cardType;
            updateCardTypeIcon(cardType);
        });

        cardNumberInput.addEventListener("keydown", (e) => {
            if (e.key === "Backspace" && e.target.value.endsWith(" ")) {
                e.preventDefault();
                e.target.value = e.target.value.slice(0, -1);
            }
        });
    }

    // Expiry date formatting
    if (cardExpiryInput) {
        cardExpiryInput.addEventListener("input", (e) => {
            let value = e.target.value.replace(/\D/g, "");
            if (value.length >= 2) {
                value = value.substring(0, 2) + "/" + value.substring(2, 4);
            }
            e.target.value = value;
        });

        cardExpiryInput.addEventListener("keydown", (e) => {
            if (e.key === "Backspace" && e.target.value.endsWith("/")) {
                e.preventDefault();
                e.target.value = e.target.value.slice(0, -1);
            }
        });
    }

    // CVV numeric only
    if (cardCvvInput) {
        cardCvvInput.addEventListener("input", (e) => {
            e.target.value = e.target.value.replace(/\D/g, "").substring(0, 4);
        });
    }
}

function openPaymentModal() {
    const overlay = document.getElementById("payment-modal-overlay");
    if (!overlay) return;

    overlay.classList.remove("hidden");
    overlay.classList.add("fade-in");
    document.body.style.overflow = "hidden";
    resetPaymentForm();
}

function closePaymentModal() {
    const overlay = document.getElementById("payment-modal-overlay");
    if (!overlay) return;

    overlay.classList.add("hidden");
    overlay.classList.remove("fade-in");
    document.body.style.overflow = "";
    paymentState.isProcessing = false;
}

function resetPaymentForm() {
    const form = document.getElementById("payment-form");
    const successView = document.getElementById("payment-success");
    const errorView = document.getElementById("payment-error");

    if (form) {
        form.reset();
        form.classList.remove("hidden");
    }
    if (successView) successView.classList.add("hidden");
    if (errorView) errorView.classList.add("hidden");

    document.querySelectorAll(".field-error").forEach(el => el.textContent = "");
    updateCardTypeIcon("unknown");

    const payBtn = document.getElementById("pay-now-btn");
    if (payBtn) payBtn.disabled = false;
}

function detectCardType(number) {
    const cleanNumber = number.replace(/\s/g, "");
    if (/^4/.test(cleanNumber)) return "visa";
    if (/^5[1-5]/.test(cleanNumber) || /^2[2-7]/.test(cleanNumber)) return "mastercard";
    if (/^3[47]/.test(cleanNumber)) return "amex";
    if (/^6(?:011|5)/.test(cleanNumber)) return "discover";
    return "unknown";
}

function updateCardTypeIcon(cardType) {
    const iconEl = document.getElementById("card-type-icon");
    if (!iconEl) return;

    const iconMap = {
        visa: "fa-brands fa-cc-visa",
        mastercard: "fa-brands fa-cc-mastercard",
        amex: "fa-brands fa-cc-amex",
        discover: "fa-brands fa-cc-discover",
        unknown: "fa-solid fa-credit-card"
    };

    iconEl.innerHTML = `<i class="${iconMap[cardType] || iconMap['unknown']}"></i>`;
}

function validateCardDetails() {
    const name = document.getElementById("cardholder-name").value.trim();
    const number = document.getElementById("card-number").value.replace(/\s/g, "");
    const expiry = document.getElementById("card-expiry").value.trim();
    const cvv = document.getElementById("card-cvv").value.trim();

    let isValid = true;

    // Validate name
    if (name.length < 2) {
        document.getElementById("error-name").textContent = "Please enter your full name.";
        isValid = false;
    } else {
        document.getElementById("error-name").textContent = "";
    }

    // Validate card number (basic 16-digit check)
    if (number.length < 13 || number.length > 19 || !/^\d+$/.test(number)) {
        document.getElementById("error-card").textContent = "Please enter a valid card number.";
        isValid = false;
    } else {
        document.getElementById("error-card").textContent = "";
    }

    // Validate expiry
    const expiryRegex = /^(0[1-9]|1[0-2])\/\d{2}$/;
    if (!expiryRegex.test(expiry)) {
        document.getElementById("error-expiry").textContent = "Use MM/YY format.";
        isValid = false;
    } else {
        const [month, year] = expiry.split("/").map(Number);
        const now = new Date();
        const currentYear = now.getFullYear() % 100;
        const currentMonth = now.getMonth() + 1;
        if (year < currentYear || (year === currentYear && month < currentMonth)) {
            document.getElementById("error-expiry").textContent = "Card has expired.";
            isValid = false;
        } else {
            document.getElementById("error-expiry").textContent = "";
        }
    }

    // Validate CVV
    if (cvv.length < 3 || cvv.length > 4 || !/^\d+$/.test(cvv)) {
        document.getElementById("error-cvv").textContent = "Enter a valid CVV (3-4 digits).";
        isValid = false;
    } else {
        document.getElementById("error-cvv").textContent = "";
    }

    return isValid;
}

function processPayment() {
    if (paymentState.isProcessing) return;

    if (!validateCardDetails()) {
        showToast("Validation Error", "Please correct the highlighted fields.", "error");
        return;
    }

    paymentState.isProcessing = true;
    const payBtn = document.getElementById("pay-now-btn");
    const btnText = document.getElementById("pay-btn-text");
    const btnIcon = document.getElementById("pay-btn-icon");
    const spinner = document.getElementById("pay-spinner");

    payBtn.disabled = true;
    btnText.textContent = "Processing...";
    btnIcon.classList.add("hidden");
    spinner.classList.remove("hidden");

    // Simulate payment processing (2.5 seconds)
    setTimeout(() => {
        const isSuccess = true; // Mock success - in production, this would be an API call

        if (isSuccess) {
            // Activate premium membership
            state.premiumMembership = true;
            state.activeUser.premium = true;

            // Update user in database
            const userIndex = state.users.findIndex(u => u.email === state.activeUser.email);
            if (userIndex !== -1) {
                state.users[userIndex].premium = true;
            }

            // Show success view
            document.getElementById("payment-form").classList.add("hidden");
            document.getElementById("payment-success").classList.remove("hidden");
            document.getElementById("payment-success").classList.add("fade-in");

            // Update profile UI
            renderPremiumStatus();
        } else {
            // Show error view
            document.getElementById("payment-form").classList.add("hidden");
            document.getElementById("payment-error").classList.remove("hidden");
            document.getElementById("payment-error").classList.add("fade-in");
            document.getElementById("payment-error-msg").textContent =
                "Transaction declined. Please check your card details or try a different payment method.";
        }

        // Reset button state
        payBtn.disabled = false;
        btnText.textContent = "Pay ₹799";
        btnIcon.classList.remove("hidden");
        spinner.classList.add("hidden");
        paymentState.isProcessing = false;
    }, 2500);
}

function renderPremiumStatus() {
    const activeLoansEl = document.getElementById("stat-active-loans");
    if (activeLoansEl && state.activeUser) {
        const activeLoans = state.borrowedHistory.filter(h => h.userId === state.activeUser.email && h.status === 'active-borrow').length;
        activeLoansEl.textContent = activeLoans;
    }
}

function setupProfileEvents() {
    const editBtn = document.getElementById("toggle-edit-profile-btn");
    const cancelBtn = document.getElementById("cancel-edit-profile-btn");
    const editForm = document.getElementById("edit-profile-form");

    if (editBtn && editForm) {
        editBtn.addEventListener("click", () => {
            const firstName = state.activeUser.firstName || (state.activeUser.name ? state.activeUser.name.split(' ')[0] : "");
            const lastName = state.activeUser.lastName !== undefined ? state.activeUser.lastName : (state.activeUser.name ? state.activeUser.name.split(' ').slice(1).join(' ') : "");
            const gender = (state.activeUser.gender || "Male").toLowerCase();

            const firstNameInput = document.getElementById("edit-firstname");
            const lastNameInput = document.getElementById("edit-lastname");
            if (firstNameInput) firstNameInput.value = firstName;
            if (lastNameInput) lastNameInput.value = lastName;

            const genderRadios = document.querySelectorAll('input[name="edit-gender"]');
            genderRadios.forEach(r => {
                const isSelected = r.value.toLowerCase() === gender;
                r.checked = isSelected;
                if (isSelected) {
                    r.closest('.radio-option')?.classList.add('selected');
                } else {
                    r.closest('.radio-option')?.classList.remove('selected');
                }
            });

            editForm.classList.remove("hidden");
            editForm.classList.add("scale-up");
            editBtn.classList.add("hidden");
        });
    }

    if (cancelBtn && editForm && editBtn) {
        cancelBtn.addEventListener("click", () => {
            editForm.classList.add("hidden");
            editBtn.classList.remove("hidden");
        });
    }

    // Radio option sync on change inside edit form
    const editGenderRadios = document.querySelectorAll('input[name="edit-gender"]');
    editGenderRadios.forEach(radio => {
        radio.addEventListener('change', () => {
            document.querySelectorAll('#edit-profile-form .radio-option').forEach(opt => opt.classList.remove('selected'));
            if (radio.checked) {
                radio.closest('.radio-option')?.classList.add('selected');
            }
        });
    });

    if (editForm) {
        editForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const firstNameInput = document.getElementById("edit-firstname");
            const lastNameInput = document.getElementById("edit-lastname");
            const genderInput = document.querySelector('input[name="edit-gender"]:checked');

            const firstName = firstNameInput ? firstNameInput.value.trim() : "";
            const lastName = lastNameInput ? lastNameInput.value.trim() : "";
            const gender = genderInput ? genderInput.value : (state.activeUser.gender || "Other");

            if (!firstName) {
                showToast("Validation Error", "Please provide a first name.", "warning");
                return;
            }

            const fullName = `${firstName} ${lastName}`.trim();

            state.activeUser.firstName = firstName;
            state.activeUser.lastName = lastName;
            state.activeUser.name = fullName;
            state.activeUser.gender = gender;

            const userIndex = state.users.findIndex(u => u.email === state.activeUser.email);
            if (userIndex !== -1) {
                state.users[userIndex].firstName = firstName;
                state.users[userIndex].lastName = lastName;
                state.users[userIndex].name = fullName;
                state.users[userIndex].gender = gender;
            }

            try {
                localStorage.setItem("aetheria_active_user", JSON.stringify(state.activeUser));
                localStorage.setItem("aetheria_users", JSON.stringify(state.users));
            } catch (err) {
                console.error("Error saving updated profile:", err);
            }

            // Sync updated profile to MySQL via PHP API
            apiUpdateProfile(state.activeUser.email, {
                firstName,
                lastName,
                gender
            }).catch(err => console.warn("Profile update MySQL sync notice:", err));

            setupDashboard();
            renderProfile();
            editForm.classList.add("hidden");
            if (editBtn) editBtn.classList.remove("hidden");
            showToast("Profile Updated", "Your profile details have been saved.", "success");
        });
    }
}

function renderProfile() {
    if (!state.activeUser) return;

    // 1. Populate Profile Card details
    const profileImg = document.getElementById("profile-avatar-img");
    if (profileImg) {
        profileImg.src = getAvatarUrl(state.activeUser.name, getAvatarColor(state.activeUser.avatar));
        profileImg.onerror = () => { profileImg.src = generateLocalAvatar(state.activeUser.name); };
    }
    document.getElementById("profile-full-name").textContent = state.activeUser.name;
    document.getElementById("profile-email-addr").textContent = state.activeUser.email;

    const genderBadge = document.getElementById("profile-gender-badge");
    if (genderBadge) {
        genderBadge.textContent = state.activeUser.gender || "Male";
    }

    // Calculate borrowing totals
    const allHistory = state.borrowedHistory.filter(h => h.userId === state.activeUser.email);
    const activeLoans = allHistory.filter(h => h.status === 'active-borrow');
    
    document.getElementById("stat-total-borrowed").textContent = allHistory.length;
    document.getElementById("stat-active-loans").textContent = activeLoans.length;

    // 2. Render Active Borrowed Shelf list
    const loansContainer = document.getElementById("active-loans-list");
    if (activeLoans.length === 0) {
        loansContainer.innerHTML = `
            <div class="empty-state" style="padding: 30px;">
                <i class="fa-solid fa-book-open-reader"></i>
                <h4>No Active Books Checked Out</h4>
                <p>Currently borrowed digital editions will appear on this shelf.</p>
                <button class="btn btn-secondary btn-sm" onclick="handleTabSwitch('browse')">Browse Library Shelf</button>
            </div>
        `;
    } else {
        loansContainer.innerHTML = activeLoans.map(loan => {
            const book = state.books.find(b => b.id === loan.bookId);
            if (!book) return '';

            // Calculate return countdown progress bar
            const today = new Date();
            const borrowDate = new Date(loan.borrowDate);
            const dueDate = new Date(loan.dueDate);
            
            const totalDuration = dueDate.getTime() - borrowDate.getTime();
            const elapsed = today.getTime() - borrowDate.getTime();
            
            let percent = Math.min(100, Math.max(0, (elapsed / totalDuration) * 100));
            const totalDaysLeft = Math.ceil((dueDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
            
            let progressColor = "var(--primary)";
            let countLabel = `${totalDaysLeft} Days Remaining`;

            if (totalDaysLeft <= 0) {
                progressColor = "var(--error)";
                percent = 100;
                countLabel = "OVERDUE";
            } else if (totalDaysLeft <= 3) {
                progressColor = "var(--warning)";
            }

            return `
                <div class="borrowed-item-row fade-in">
                    <div class="borrowed-item-jacket" style="background: ${book.bgGradient}; border-left: 2px solid rgba(0,0,0,0.3)"></div>
                    
                    <div class="borrowed-item-info">
                        <h4>${book.title}</h4>
                        <p>By ${book.author}</p>
                    </div>

                    <!-- Progress bar -->
                    <div class="loan-progress-container">
                        <div class="loan-progress-meta">
                            <span style="color: ${progressColor}">${countLabel}</span>
                            <span>Due: ${formatDate(loan.dueDate)}</span>
                        </div>
                        <div class="loan-progress-bar-bg">
                            <div class="loan-progress-bar-fill" style="width: ${percent}%; background: ${progressColor}"></div>
                        </div>
                    </div>

                    <!-- Return button -->
                    <button class="btn btn-secondary btn-sm" onclick="returnBook('${loan.id}')">
                        <i class="fa-solid fa-rotate-left"></i> Return Book
                    </button>
                </div>
            `;
        }).join('');
    }

    // 3. Render Table history logs
    const historyTbody = document.getElementById("history-log-tbody");
    if (allHistory.length === 0) {
        historyTbody.innerHTML = `
            <tr>
                <td colspan="5" style="text-align: center; color: var(--text-muted); padding: 30px;">
                    No borrowing records found.
                </td>
            </tr>
        `;
    } else {
        historyTbody.innerHTML = allHistory.map(record => {
            const book = state.books.find(b => b.id === record.bookId);
            const bookTitle = book ? book.title : "Unknown Title";
            
            let statusBadge = '';
            if (record.status === 'returned') {
                statusBadge = '<span class="history-badge returned">Returned</span>';
            } else {
                // Check if active borrow is overdue
                const isOverdue = new Date() > new Date(record.dueDate);
                if (isOverdue) {
                    statusBadge = '<span class="history-badge overdue">Overdue</span>';
                } else {
                    statusBadge = '<span class="history-badge active-borrow">Checked Out</span>';
                }
            }

            return `
                <tr>
                    <td class="highlight-text">${bookTitle}</td>
                    <td>${formatDate(record.borrowDate)}</td>
                    <td>${formatDate(record.dueDate)}</td>
                    <td>${record.returnDate ? formatDate(record.returnDate) : '—'}</td>
                    <td>${statusBadge}</td>
                </tr>
            `;
        }).join('');
    }
}

function returnBook(loanId) {
    // Find record in history
    const recordIndex = state.borrowedHistory.findIndex(h => h.id.toString() === loanId.toString());
    if (recordIndex === -1) return;

    const record = state.borrowedHistory[recordIndex];
    
    // 1. Mark book as available again
    const bookIndex = state.books.findIndex(b => b.id === record.bookId);
    if (bookIndex !== -1) {
        state.books[bookIndex].available = true;
    }

    // 2. Update record return date & status
    state.borrowedHistory[recordIndex].returnDate = new Date().toISOString();
    state.borrowedHistory[recordIndex].status = 'returned';

    try {
        localStorage.setItem("aetheria_loans", JSON.stringify(state.borrowedHistory));
        localStorage.setItem("aetheria_books", JSON.stringify(state.books));
    } catch (e) {}

    // Sync book return to MySQL via REST API
    if (typeof apiReturnLoan === 'function') {
        apiReturnLoan(loanId, record.bookId)
            .catch(e => console.warn("Return book MySQL sync notice:", e));
    }

    // 3. Update banner statistics
    updateBannerStatistics();
    
    // 4. Refresh display
    renderProfile();
    showToast("Book Returned", "Thank you! The catalog availability has been updated.", "success");
}

// ==========================================================================
// 4. Nearby Libraries & Location Finder
// ==========================================================================
function setupLocationFinder() {
    const citySelect = document.getElementById("city-select");
    const findBtn = document.getElementById("find-libraries-btn");
    const useLocBtn = document.getElementById("use-location-btn");
    if (!citySelect) return;

    // Populate city dropdown
    CITIES.forEach((city, idx) => {
        const opt = document.createElement("option");
        opt.value = idx;
        opt.textContent = city.name;
        citySelect.appendChild(opt);
    });

    // Find by selected city
    findBtn.addEventListener("click", () => {
        const idx = citySelect.value;
        if (idx === "") {
            showToast("No City Selected", "Please choose a city or use your current location.", "warning");
            return;
        }
        const city = CITIES[Number(idx)];
        activeLocation = { lat: city.lat, lng: city.lng, label: city.name };
        setLocationStatus(`Showing libraries nearest to <strong>${city.name}</strong>.`);
        renderNearbyLibraries();
    });

    // Use browser geolocation
    useLocBtn.addEventListener("click", () => {
        if (!navigator.geolocation) {
            showToast("Unsupported", "Geolocation is not supported by your browser.", "error");
            return;
        }
        setLocationStatus('<i class="fa-solid fa-spinner fa-spin"></i> Detecting your location...');
        navigator.geolocation.getCurrentPosition(
            (pos) => {
                activeLocation = {
                    lat: pos.coords.latitude,
                    lng: pos.coords.longitude,
                    label: "Your Current Location"
                };
                setLocationStatus("Showing libraries nearest to <strong>your current location</strong>.");
                renderNearbyLibraries();
                showToast("Location Found", "We found libraries near you.", "success");
            },
            (err) => {
                setLocationStatus("");
                showToast("Location Error", err.message || "Could not retrieve your location.", "error");
            }
        );
    });
}

function setLocationStatus(html) {
    const el = document.getElementById("location-status");
    if (el) el.innerHTML = html;
}

// Haversine distance in kilometers
function haversineKm(lat1, lng1, lat2, lng2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
        Math.sin(dLng / 2) * Math.sin(dLng / 2);
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function formatDistance(km) {
    if (km < 1) return `${Math.round(km * 1000)} m away`;
    return `${km.toFixed(1)} km away`;
}

function renderNearbyLibraries() {
    const results = document.getElementById("libraries-results");
    if (!results) return;

    if (!activeLocation) {
        results.innerHTML = `
            <div class="empty-state">
                <i class="fa-solid fa-location-dot"></i>
                <h4>No Location Selected</h4>
                <p>Choose a city or allow location access to discover Aetheria libraries near you.</p>
            </div>
        `;
        return;
    }

    const ranked = NEARBY_LIBRARIES.map(lib => ({
        ...lib,
        distance: haversineKm(activeLocation.lat, activeLocation.lng, lib.lat, lib.lng)
    })).sort((a, b) => a.distance - b.distance);

    results.innerHTML = ranked.map((lib, i) => {
        const mapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${lib.lat},${lib.lng}`;
        const nearestBadge = i === 0
            ? `<span class="lib-closest-badge">Closest</span>` : "";
        return `
            <div class="library-card glass-panel fade-in">
                <div class="library-dot">${i + 1}</div>
                <div class="library-info">
                    <h4>${lib.name} ${nearestBadge}</h4>
                    <p class="library-address"><i class="fa-solid fa-map-pin"></i> ${lib.address}</p>
                    <div class="library-meta">
                        <span><i class="fa-solid fa-clock"></i> ${lib.hours}</span>
                        <span><i class="fa-solid fa-phone"></i> ${lib.phone}</span>
                    </div>
                </div>
                <div class="library-actions">
                    <span class="library-distance">${formatDistance(lib.distance)}</span>
                    <a class="btn btn-secondary btn-sm" href="${mapsUrl}" target="_blank" rel="noopener">
                        <i class="fa-solid fa-diamond-turn-right"></i> Directions
                    </a>
                </div>
            </div>
        `;
    }).join('');
}

// ==========================================================================
// Theme Toggler Controller
// ==========================================================================
function setupThemeToggler() {
    const toggleBtn = document.getElementById("theme-toggle");
    if (!toggleBtn) return;
    const moonIcon = toggleBtn.querySelector(".moon-icon");
    const sunIcon = toggleBtn.querySelector(".sun-icon");

    // Default to dark theme
    updateThemeIcons("dark");

    toggleBtn.addEventListener("click", () => {
        const currentTheme = document.documentElement.getAttribute("data-theme");
        const nextTheme = currentTheme === "dark" ? "light" : "dark";
        
        document.documentElement.setAttribute("data-theme", nextTheme);
        updateThemeIcons(nextTheme);
        showToast("Theme Updated", `Switched to ${nextTheme === 'dark' ? 'Dark Mode' : 'Light Mode'}.`, "info");
    });

    function updateThemeIcons(theme) {
        if (theme === "dark") {
            moonIcon.classList.remove("hidden");
            sunIcon.classList.add("hidden");
        } else {
            moonIcon.classList.add("hidden");
            sunIcon.classList.remove("hidden");
        }
    }
}

document.addEventListener("DOMContentLoaded", () => {
    // 1. Setup in-memory database
    initDatabase();

    // 2. Retrieve active session user
    try {
        const activeUser = localStorage.getItem("aetheria_active_user");
        if (activeUser) {
            state.activeUser = JSON.parse(activeUser);
        } else {
            state.activeUser = state.users[0];
        }
    } catch (e) {
        state.activeUser = state.users[0];
    }
    loadUserCartAndSession();

    // 3. Setup theme settings
    setupThemeToggler();

    // 4. Bind navigation tab listeners
    document.querySelectorAll(".tab-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            const tab = btn.getAttribute("data-tab");
            handleTabSwitch(tab);
        });
    });

    // 5. Register event modules
    setupLogoutEvent();
    setupCatalogEvents();
    setupCheckoutEvents();
    setupProfileEvents();
    setupLocationFinder();
    setupPaymentGateway();
    setupLiveSyncEvents();

    // 6. Initial view rendering
    switchMainViews();

    // 7. Sync live catalog from SQL backend
    syncBooksFromServer();
});

// ==========================================================================
// Live Synchronization Bridge (Admin Panel & SQL Database <-> Home Page)
// ==========================================================================
function refreshCatalogUI() {
    updateBannerStatistics();
    if (typeof renderBookshelfShowcase === 'function') renderBookshelfShowcase();
    const isBrowseActive = !document.getElementById("browse-tab")?.classList.contains("hidden");
    if (isBrowseActive && typeof renderCatalog === 'function') {
        renderCatalog();
    }
}

async function syncBooksFromServer() {
    try {
        if (typeof apiGetBooks === 'function') {
            const res = await apiGetBooks();
            if (res && res.success && Array.isArray(res.data) && res.data.length > 0) {
                state.books = res.data;
                localStorage.setItem("aetheria_books", JSON.stringify(res.data));
                refreshCatalogUI();
            }
        }
    } catch (e) {
        console.warn("Async book sync notice:", e);
    }
}

function setupLiveSyncEvents() {
    // 1. Same-window custom event from auth-common.js / admin actions
    window.addEventListener('booksUpdated', (e) => {
        if (e.detail && Array.isArray(e.detail.books)) {
            state.books = e.detail.books;
        } else {
            const stored = localStorage.getItem("aetheria_books");
            if (stored) state.books = JSON.parse(stored);
        }
        refreshCatalogUI();
    });

    // 2. Cross-tab BroadcastChannel for real-time instant propagation
    if (typeof BroadcastChannel !== 'undefined') {
        try {
            const bc = new BroadcastChannel('aetheria_sync');
            bc.onmessage = (event) => {
                if (event.data && event.data.type === 'booksUpdated') {
                    if (Array.isArray(event.data.books)) {
                        state.books = event.data.books;
                    } else {
                        const stored = localStorage.getItem("aetheria_books");
                        if (stored) state.books = JSON.parse(stored);
                    }
                    refreshCatalogUI();
                }
            };
        } catch (e) {}
    }

    // 3. Storage event listener for cross-tab cache changes
    window.addEventListener('storage', (e) => {
        if (e.key === 'aetheria_books' || e.key === 'aetheria_last_sync') {
            try {
                const stored = localStorage.getItem("aetheria_books");
                if (stored) {
                    state.books = JSON.parse(stored);
                    refreshCatalogUI();
                }
            } catch (err) {}
        } else if (e.key === 'aetheria_loans') {
            try {
                state.borrowedHistory = JSON.parse(e.newValue || '[]');
                refreshCatalogUI();
            } catch (err) {}
        }
    });
}
