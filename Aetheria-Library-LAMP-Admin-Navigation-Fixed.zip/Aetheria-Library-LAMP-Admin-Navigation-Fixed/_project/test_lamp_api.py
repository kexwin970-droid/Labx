import urllib.request
import urllib.parse
import json
import sys

BASE = "http://127.0.0.1:8000"

def request(path, method="GET", data=None, token=None):
    url = f"{BASE}{path}"
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    body = json.dumps(data).encode("utf-8") if data else None
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req) as response:
            return response.status, json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        err_body = e.read().decode("utf-8")
        try:
            return e.code, json.loads(err_body)
        except:
            return e.code, {"raw": err_body}
    except Exception as ex:
        return 0, {"error": str(ex)}

def test_static(path):
    url = f"{BASE}{path}"
    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req) as resp:
            return resp.status, len(resp.read())
    except Exception as e:
        return 0, str(e)

print("==================================================")
print("Aetheria Library LAMP Architecture End-to-End Test")
print("==================================================")

# 1. Test Static Files
print("\n--- Testing Web Server Static Routing ---")
for f in ["/", "/index.html", "/login.html", "/admin_login.html", "/home.html", "/signup.html", "/forgot.html", "/style.css", "/app.js", "/auth-common.js", "/features.js"]:
    status, size = test_static(f)
    print(f"File {f:20} -> Status {status} (Bytes: {size})")

# 2. Test Catalog
print("\n--- Testing Books Catalog (REST & Direct) ---")
status, res = request("/api/books")
print(f"GET /api/books -> Status {status}, Count: {len(res.get('data', [])) if isinstance(res.get('data'), list) else 'N/A'}")

status, res = request("/api/books.php")
print(f"GET /api/books.php -> Status {status}, Count: {len(res.get('data', [])) if isinstance(res.get('data'), list) else 'N/A'}")

# 3. Test Member Login
print("\n--- Testing Authentication Endpoints ---")
status, res = request("/api/auth/login", method="POST", data={"identifier": "demo@example.com", "password": "Demo@123"})
print(f"POST /api/auth/login (Member) -> Status {status}, Success: {res.get('success')}, User: {res.get('data', {}).get('user', {}).get('name')}")
member_token = res.get("data", {}).get("token")

# 4. Test Admin Login
status, res = request("/api/auth/login", method="POST", data={"identifier": "admin@example.com", "password": "Admin@123"})
print(f"POST /api/auth/login (Admin)  -> Status {status}, Success: {res.get('success')}, Role: {res.get('data', {}).get('user', {}).get('role')}")
admin_token = res.get("data", {}).get("token")

# 5. Test Invalid Login
status, res = request("/api/auth/login", method="POST", data={"identifier": "admin@example.com", "password": "WrongPassword"})
print(f"POST /api/auth/login (Invalid)-> Status {status}, Message: {res.get('message')}")

# 6. Test Auth Me
status, res = request("/api/auth/me", token=member_token)
print(f"GET /api/auth/me (Member)    -> Status {status}, User: {res.get('data', {}).get('username')}")

# 7. Test Admin Dashboard with Admin vs Member
print("\n--- Testing Admin Endpoints & Security ---")
status, res = request("/api/admin/dashboard", token=admin_token)
print(f"GET /api/admin/dashboard (Admin)  -> Status {status}, Success: {res.get('success')}")
if status == 200:
    stats = res.get("data", {}).get("stats", {})
    print(f"   Stats: Books={stats.get('totalBooks')}, Users={stats.get('totalUsers')}, DB={stats.get('database')}")

status, res = request("/api/admin/dashboard", token=member_token)
print(f"GET /api/admin/dashboard (Member) -> Status {status} (Expected 403 Forbidden)")

# 8. Test Users Directory
status, res = request("/api/users", token=admin_token)
print(f"GET /api/users (Admin)            -> Status {status}, Total users: {len(res.get('data', [])) if isinstance(res.get('data'), list) else 'N/A'}")

# 9. Test Loans Circulation
print("\n--- Testing Book Loans / Circulation ---")
status, res = request("/api/loans/borrow", method="POST", data={"bookIds": [1], "durationDays": 14}, token=member_token)
print(f"POST /api/loans/borrow (Book 1)   -> Status {status}, Success: {res.get('success')}")
loan_id = None
if status in [200, 201] and res.get("data"):
    loan_id = res["data"][0].get("id")

status, res = request("/api/loans", token=member_token)
print(f"GET /api/loans (Member)           -> Status {status}, Loans count: {len(res.get('data', [])) if isinstance(res.get('data'), list) else 'N/A'}")

if loan_id:
    status, res = request("/api/loans/return", method="POST", data={"loanId": loan_id}, token=member_token)
    print(f"POST /api/loans/return (Loan {loan_id}) -> Status {status}, Message: {res.get('message')}")

# 10. Test Wishlist
print("\n--- Testing Wishlist API ---")
status, res = request("/api/wishlist/toggle", method="POST", data={"bookId": 2}, token=member_token)
print(f"POST /api/wishlist/toggle (Book 2)-> Status {status}, inWishlist: {res.get('data', {}).get('inWishlist')}")

status, res = request("/api/wishlist", token=member_token)
print(f"GET /api/wishlist                 -> Status {status}, Book IDs: {res.get('data', {}).get('bookIds')}")

# 11. Test Reviews
print("\n--- Testing Reviews API ---")
status, res = request("/api/reviews", method="POST", data={"bookId": 2, "rating": 5, "text": "Brilliant cyberpunk masterpiece!"}, token=member_token)
print(f"POST /api/reviews (Book 2)        -> Status {status}, Success: {res.get('success')}")

status, res = request("/api/reviews?bookId=2", token=member_token)
print(f"GET /api/reviews?bookId=2         -> Status {status}, Reviews count: {len(res.get('data', [])) if isinstance(res.get('data'), list) else 'N/A'}")

# 12. Test Registration
print("\n--- Testing User Registration & Password Reset ---")
test_email = "scholar_test@example.com"
status, res = request("/api/auth/register", method="POST", data={
    "email": test_email,
    "username": "scholartest",
    "password": "Password@123",
    "name": "Scholar Test",
    "gender": "Female"
})
print(f"POST /api/auth/register           -> Status {status}, Message: {res.get('message')}")

status, res = request("/api/auth/reset-password", method="POST", data={
    "email": test_email,
    "newPassword": "NewPassword@456"
})
print(f"POST /api/auth/reset-password      -> Status {status}, Message: {res.get('message')}")

# Login with new password
status, res = request("/api/auth/login", method="POST", data={"identifier": test_email, "password": "NewPassword@456"})
print(f"POST /api/auth/login (New User)   -> Status {status}, Success: {res.get('success')}")

print("\n==================================================")
print("All Backend API & LAMP Tests Finished Successfully!")
print("==================================================")
