/* ==========================================================================
   Aetheria Library — Sign-Up Controller
   Registers users client-side via LocalStorage.
   ========================================================================== */

document.addEventListener("DOMContentLoaded", () => {
    // If user is already logged in, redirect to appropriate home
    const currentUser = getActiveUser();
    if (currentUser) {
        window.location.href = "home.html";
        return;
    }

    // Radio button active styling sync
    const genderRadios = document.querySelectorAll('input[name="signup-gender"]');
    genderRadios.forEach(radio => {
        radio.addEventListener("change", () => {
            document.querySelectorAll(".radio-option").forEach(opt => opt.classList.remove("selected"));
            if (radio.checked) {
                radio.closest(".radio-option")?.classList.add("selected");
            }
        });
    });

    // Signup Form Handler
    const signupForm = document.getElementById("signup-form");
    if (!signupForm) return;

    signupForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const firstNameInput = document.getElementById("signup-firstname");
        const lastNameInput = document.getElementById("signup-lastname");
        const usernameInput = document.getElementById("signup-username");
        const emailInput = document.getElementById("signup-email");
        const genderInput = document.querySelector('input[name="signup-gender"]:checked');
        const passwordInput = document.getElementById("signup-password");
        const confirmPasswordInput = document.getElementById("signup-confirm-password");

        const firstName = firstNameInput ? firstNameInput.value.trim() : "";
        const lastName = lastNameInput ? lastNameInput.value.trim() : "";
        const email = emailInput ? emailInput.value.trim().toLowerCase() : "";
        const username = usernameInput ? usernameInput.value.trim().toLowerCase() : email.split('@')[0];
        const gender = genderInput ? genderInput.value : "Other";
        const password = passwordInput ? passwordInput.value : "";
        const confirmPassword = confirmPasswordInput ? confirmPasswordInput.value : "";

        if (!firstName) {
            showToast("Validation Error", "Please enter your first name.", "warning");
            return;
        }

        if (password !== confirmPassword) {
            showToast("Password Mismatch", "Passwords do not match. Please verify and retry.", "error");
            return;
        }

        if (password.length < 6) {
            showToast("Weak Password", "Password must be at least 6 characters long.", "error");
            return;
        }

        const submitBtn = signupForm.querySelector("button[type='submit']");
        const originalText = submitBtn ? submitBtn.innerHTML : "Create Account";
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Creating Account...`;
        }

        const newUserPayload = {
            username,
            firstName,
            lastName,
            email,
            gender,
            password
        };

        try {
            // Register account client-side
            const apiRes = await apiSignup(newUserPayload);

            if (apiRes && apiRes.success) {
                try {
                    sessionStorage.setItem("aetheria_registered_identifier", email || username);
                } catch (err) {}
                showToast("Account Created", apiRes.message || "Account created successfully! Redirecting to login...", "success");

                setTimeout(() => {
                    window.location.href = "login.html";
                }, 800);
                return;
            }

            // Display error message
            const errorMsg = (apiRes && apiRes.message) ? apiRes.message : "Registration failed. Please try again.";
            showToast("Registration Error", errorMsg, "error");
        } catch (err) {
            showToast("Error", "Could not complete account registration.", "error");
        } finally {
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
            }
        }
    });
});
