<?php
/* ==========================================================================
   Aetheria Library — Development Web Server Router (LAMP Compatible)
   Faithfully executes Apache mod_rewrite & mod_headers rules from .htaccess.
   Usage: php -S 127.0.0.1:8000 router.php
   ========================================================================== */

$rawUri = $_SERVER['REQUEST_URI'];
$uri = parse_url($rawUri, PHP_URL_PATH);
$queryString = parse_url($rawUri, PHP_URL_QUERY);

// Parse query parameters into $_GET
if ($queryString) {
    parse_str($queryString, $queryParams);
    $_GET = array_merge($_GET, $queryParams);
}

// Global CORS headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

// Handle OPTIONS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Default root redirection or index
if ($uri === '/' || $uri === '') {
    include __DIR__ . '/index.html';
    return true;
}

$file = __DIR__ . $uri;

// If file exists on filesystem
if (file_exists($file) && !is_dir($file)) {
    // If it's a PHP file, execute it
    if (pathinfo($file, PATHINFO_EXTENSION) === 'php') {
        require $file;
        return true;
    }
    // Static asset (HTML, CSS, JS, SVG, etc.) -> let PHP serve directly
    return false;
}

// Normalise URI for .htaccess routing
$path = ltrim($uri, '/');
$apiPath = preg_replace('#^api/#', '', $path);

// 1. Auth routes
if (preg_match('#^auth/login/?$#', $apiPath)) {
    $_GET['action'] = 'login';
    require __DIR__ . '/api/auth.php';
    exit();
}
if (preg_match('#^auth/(register|signup)/?$#', $apiPath)) {
    $_GET['action'] = 'register';
    require __DIR__ . '/api/auth.php';
    exit();
}
if (preg_match('#^auth/me/?$#', $apiPath)) {
    $_GET['action'] = 'me';
    require __DIR__ . '/api/auth.php';
    exit();
}
if (preg_match('#^auth/logout/?$#', $apiPath)) {
    $_GET['action'] = 'logout';
    require __DIR__ . '/api/auth.php';
    exit();
}
if (preg_match('#^auth/profile/?$#', $apiPath)) {
    $_GET['action'] = 'profile';
    require __DIR__ . '/api/auth.php';
    exit();
}
if (preg_match('#^auth/reset-password/?$#', $apiPath)) {
    $_GET['action'] = 'reset_password';
    require __DIR__ . '/api/auth.php';
    exit();
}

// 2. Books routes
if (preg_match('#^books/([0-9]+)/?$#', $apiPath, $matches)) {
    $_GET['id'] = $matches[1];
    require __DIR__ . '/api/books.php';
    exit();
}
if (preg_match('#^books/?$#', $apiPath)) {
    require __DIR__ . '/api/books.php';
    exit();
}

// 3. Admin routes
if (preg_match('#^admin/dashboard/?$#', $apiPath)) {
    $_GET['action'] = 'dashboard';
    require __DIR__ . '/api/admin.php';
    exit();
}
if (preg_match('#^admin/activity-logs/?$#', $apiPath)) {
    $_GET['action'] = 'logs';
    require __DIR__ . '/api/admin.php';
    exit();
}
if (preg_match('#^users/([0-9]+)/status/?$#', $apiPath, $matches)) {
    $_GET['action'] = 'user_status';
    $_GET['id'] = $matches[1];
    require __DIR__ . '/api/admin.php';
    exit();
}
if (preg_match('#^users/([0-9]+)/password/?$#', $apiPath, $matches)) {
    $_GET['action'] = 'reset_password';
    $_GET['id'] = $matches[1];
    require __DIR__ . '/api/admin.php';
    exit();
}
if (preg_match('#^users/([0-9]+)/?$#', $apiPath, $matches)) {
    $_GET['action'] = 'delete_user';
    $_GET['id'] = $matches[1];
    require __DIR__ . '/api/admin.php';
    exit();
}
if (preg_match('#^users/?$#', $apiPath)) {
    $_GET['action'] = 'users';
    require __DIR__ . '/api/admin.php';
    exit();
}

// 4. Loans routes
if (preg_match('#^loans/borrow/?$#', $apiPath)) {
    $_GET['action'] = 'borrow';
    require __DIR__ . '/api/loans.php';
    exit();
}
if (preg_match('#^loans/return/?$#', $apiPath)) {
    $_GET['action'] = 'return';
    require __DIR__ . '/api/loans.php';
    exit();
}
if (preg_match('#^loans/extend/?$#', $apiPath)) {
    $_GET['action'] = 'extend';
    require __DIR__ . '/api/loans.php';
    exit();
}
if (preg_match('#^loans/?$#', $apiPath)) {
    require __DIR__ . '/api/loans.php';
    exit();
}

// 5. Reviews routes
if (preg_match('#^reviews/?$#', $apiPath)) {
    require __DIR__ . '/api/reviews.php';
    exit();
}

// 6. Wishlist routes
if (preg_match('#^wishlist/toggle/?$#', $apiPath)) {
    $_GET['action'] = 'toggle';
    require __DIR__ . '/api/wishlist.php';
    exit();
}
if (preg_match('#^wishlist/?$#', $apiPath)) {
    require __DIR__ . '/api/wishlist.php';
    exit();
}

// Fallback: 404 Not Found
http_response_code(404);
header('Content-Type: application/json');
echo json_encode(['success' => false, 'message' => "Route not found: {$uri}"]);
