/* ==========================================================================
   Aetheria Library — Login Controller
   Authenticates users client-side via LocalStorage.
   ========================================================================== */

document.addEventListener("DOMContentLoaded", () => {
    // If user is already logged in, redirect to home
    const currentUser = getActiveUser();
    if (currentUser) {
        window.location.href = "home.html";
        return;
    }

    const emailInput = document.getElementById("login-email");
    const passwordInput = document.getElementById("login-password");
    const loginForm = document.getElementById("login-form");

    // Auto-fill recently registered identifier if redirected from signup
    try {
        const recentlyRegistered = sessionStorage.getItem("aetheria_registered_identifier");
        if (recentlyRegistered && emailInput) {
            emailInput.value = recentlyRegistered;
            sessionStorage.removeItem("aetheria_registered_identifier");
            if (passwordInput) passwordInput.focus();
        }
    } catch (e) {}

    // 1. Predefined Demo Credential Helper Button
    const btnDemoUser = document.getElementById("btn-demo-user");

    if (btnDemoUser && emailInput && passwordInput) {
        btnDemoUser.addEventListener("click", () => {
            emailInput.value = DEMO_USER.username;
            passwordInput.value = DEMO_USER.password;
            showToast("Demo Member Selected", "Credentials auto-filled for demo user.", "info");
        });
    }

    // 2. Form Submission Handler
    if (!loginForm) return;

    loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const identifier = emailInput.value.trim();
        const password = passwordInput.value;

        if (!identifier || !password) {
            showToast("Missing Fields", "Please enter both username/email and password.", "warning");
            return;
        }

        // Show loading state
        const submitBtn = loginForm.querySelector("button[type='submit']");
        const originalText = submitBtn ? submitBtn.innerHTML : "Sign In";
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Authenticating...`;
        }

        try {
            // Client-side authentication
            const apiRes = await apiLogin(identifier, password);

            if (apiRes && apiRes.success && apiRes.data && apiRes.data.user) {
                const user = apiRes.data.user;
                // Administrator accounts redirect directly to the library home
                if (user.role === "admin") {
                    showToast("Administrator Access", `Welcome back, ${user.name || "Administrator"}!`, "success");
                    setTimeout(() => {
                        window.location.href = "home.html";
                    }, 400);
                    return;
                }

                showToast("Access Granted", apiRes.message || `Welcome back, ${user.name || user.firstName}!`, "success");

                setTimeout(() => {
                    window.location.href = "home.html";
                }, 400);
                return;
            }

            // Display error message
            const errorMsg = (apiRes && apiRes.message) ? apiRes.message : "Authentication failed. Please verify credentials.";
            showToast("Login Failed", errorMsg, "error");
        } catch (err) {
            showToast("Error", "Authentication error occurred.", "error");
        } finally {
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
            }
        }
    });
});
