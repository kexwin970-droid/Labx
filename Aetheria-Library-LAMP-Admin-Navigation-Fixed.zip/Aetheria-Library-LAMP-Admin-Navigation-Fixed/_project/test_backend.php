<?php
// Test login for admin
$_SERVER['REQUEST_METHOD'] = 'POST';
$_GET['action'] = 'login';
$_SERVER['REMOTE_ADDR'] = '127.0.0.1';
$_SERVER['HTTP_USER_AGENT'] = 'PHP CLI Test';

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/api/db.php';

// Directly test DB connection
try {
    $pdo = getDBConnection();
    echo "DB Connection SUCCESS\n";
    
    // Check users
    $stmt = $pdo->query("SELECT email, username, role, status FROM users");
    $users = $stmt->fetchAll();
    echo "Users in DB:\n";
    print_r($users);
    
    // Check password verify
    $stmt = $pdo->prepare("SELECT password_hash FROM users WHERE email = 'admin@example.com'");
    $stmt->execute();
    $hash = $stmt->fetchColumn();
    echo "Hash: $hash\n";
    echo "Verify Admin@123: " . (password_verify('Admin@123', $hash) ? 'TRUE' : 'FALSE') . "\n";
    
} catch (Exception $e) {
    echo "DB ERROR: " . $e->getMessage() . "\n";
}
