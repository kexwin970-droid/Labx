<?php
/* ==========================================================================
   Aetheria Library — Books Catalog API Endpoint (LAMP / PHP)
   Operations: GET (list books), POST (add book), PUT (update book), DELETE (remove book)
   Directly manages MySQL books table.
   ========================================================================== */

require_once __DIR__ . '/db.php';

$pdo = getSafeDBConnection();
$method = $_SERVER['REQUEST_METHOD'];
$body = getRequestBody();

// Support query parameter ?id=... or REST path
$bookId = isset($_GET['id']) ? (int)$_GET['id'] : null;

switch ($method) {
    // -------------------------------------------------------------------------
    // 1. GET Books (Catalog list or single book)
    // -------------------------------------------------------------------------
    case 'GET':
        if ($bookId) {
            $stmt = $pdo->prepare("SELECT * FROM books WHERE id = :id LIMIT 1");
            $stmt->execute([':id' => $bookId]);
            $book = $stmt->fetch();
            if (!$book) {
                sendJsonResponse(false, 'Book not found in library catalog.', null, 404);
            }
            $book['available'] = (bool)$book['available'];
            $book['rating'] = (float)$book['rating'];
            $book['pages'] = (int)$book['pages'];
            $book['bgGradient'] = $book['bg_gradient'];
            $book['headerColor'] = $book['header_color'];
            $book['readUrl'] = $book['read_url'] ?? '';
            sendJsonResponse(true, 'Book retrieved.', $book);
        }

        $search = trim($_GET['search'] ?? '');
        $genre = trim($_GET['genre'] ?? 'all');
        $available = trim($_GET['available'] ?? 'all');

        $sql = "SELECT * FROM books WHERE 1=1";
        $params = [];

        if ($genre !== 'all' && !empty($genre)) {
            $sql .= " AND genre = :genre";
            $params[':genre'] = $genre;
        }

        if ($available === 'true' || $available === '1') {
            $sql .= " AND available = 1";
        } elseif ($available === 'false' || $available === '0') {
            $sql .= " AND available = 0";
        }

        if (!empty($search)) {
            $sql .= " AND (title LIKE :s1 OR author LIKE :s2 OR description LIKE :s3)";
            $params[':s1'] = "%{$search}%";
            $params[':s2'] = "%{$search}%";
            $params[':s3'] = "%{$search}%";
        }

        $sql .= " ORDER BY id ASC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $books = $stmt->fetchAll();

        // Format data types for frontend
        foreach ($books as &$b) {
            $b['id'] = (int)$b['id'];
            $b['available'] = (bool)$b['available'];
            $b['rating'] = (float)$b['rating'];
            $b['pages'] = (int)$b['pages'];
            $b['bgGradient'] = $b['bg_gradient'];
            $b['headerColor'] = $b['header_color'];
            $b['readUrl'] = $b['read_url'] ?? '';
        }

        sendJsonResponse(true, 'Books catalog retrieved.', $books);
        break;

    // -------------------------------------------------------------------------
    // 2. POST Book (Admin adds new book to MySQL)
    // -------------------------------------------------------------------------
    case 'POST':
        $user = getAuthenticatedUser(true);
        if ($user['role'] !== 'admin') {
            sendJsonResponse(false, 'Administrator privileges required.', null, 403);
        }

        $title = trim($body['title'] ?? '');
        $author = trim($body['author'] ?? '');
        $genre = trim($body['genre'] ?? 'Fiction');
        $description = trim($body['description'] ?? '');
        $rating = (float)($body['rating'] ?? 4.5);
        $available = isset($body['available']) ? ($body['available'] ? 1 : 0) : 1;
        $gradient = $body['bgGradient'] ?? $body['gradient'] ?? 'linear-gradient(135deg, #0f172a, #06b6d4)';
        $headerColor = $body['headerColor'] ?? '#f3f4f6';
        $isbn = $body['isbn'] ?? '';
        $pages = (int)($body['pages'] ?? 300);
        $readUrl = $body['readUrl'] ?? $body['read_url'] ?? '';

        if (empty($title) || empty($author)) {
            sendJsonResponse(false, 'Book title and author are required.', null, 400);
        }

        $stmt = $pdo->prepare("
            INSERT INTO books (title, author, genre, description, rating, available, bg_gradient, header_color, isbn, pages, read_url)
            VALUES (:title, :author, :genre, :desc, :rating, :avail, :grad, :head, :isbn, :pages, :read_url)
        ");
        $stmt->execute([
            ':title' => $title,
            ':author' => $author,
            ':genre' => $genre,
            ':desc' => $description,
            ':rating' => $rating,
            ':avail' => $available,
            ':grad' => $gradient,
            ':head' => $headerColor,
            ':isbn' => $isbn,
            ':pages' => $pages,
            ':read_url' => $readUrl
        ]);

        $newId = (int)$pdo->lastInsertId();
        logActivity($user['email'], 'BOOK_CREATED', "Admin added book to catalog: \"{$title}\" by {$author}");

        $createdBook = [
            'id' => $newId,
            'title' => $title,
            'author' => $author,
            'genre' => $genre,
            'description' => $description,
            'rating' => $rating,
            'available' => (bool)$available,
            'bgGradient' => $gradient,
            'headerColor' => $headerColor,
            'isbn' => $isbn,
            'pages' => $pages,
            'readUrl' => $readUrl
        ];

        sendJsonResponse(true, "Book \"{$title}\" added to library collection.", $createdBook, 201);
        break;

    // -------------------------------------------------------------------------
    // 3. PUT Book (Admin updates book in MySQL)
    // -------------------------------------------------------------------------
    case 'PUT':
        $user = getAuthenticatedUser(true);
        if ($user['role'] !== 'admin') {
            sendJsonResponse(false, 'Administrator privileges required.', null, 403);
        }

        $id = $bookId ?: (int)($body['id'] ?? 0);
        if (!$id) {
            sendJsonResponse(false, 'Book ID required for update.', null, 400);
        }

        // Check if book exists
        $chk = $pdo->prepare("SELECT * FROM books WHERE id = :id LIMIT 1");
        $chk->execute([':id' => $id]);
        $existing = $chk->fetch();
        if (!$existing) {
            sendJsonResponse(false, 'Book not found in database.', null, 404);
        }

        $title = isset($body['title']) ? trim($body['title']) : $existing['title'];
        $author = isset($body['author']) ? trim($body['author']) : $existing['author'];
        $genre = isset($body['genre']) ? trim($body['genre']) : $existing['genre'];
        $description = isset($body['description']) ? trim($body['description']) : $existing['description'];
        $rating = isset($body['rating']) ? (float)$body['rating'] : (float)$existing['rating'];
        $available = isset($body['available']) ? ($body['available'] ? 1 : 0) : (int)$existing['available'];
        $gradient = $body['bgGradient'] ?? $body['gradient'] ?? $existing['bg_gradient'];
        $readUrl = isset($body['readUrl']) ? trim($body['readUrl']) : (isset($body['read_url']) ? trim($body['read_url']) : ($existing['read_url'] ?? ''));

        $upStmt = $pdo->prepare("
            UPDATE books
            SET title = :title, author = :author, genre = :genre, description = :desc,
                rating = :rating, available = :avail, bg_gradient = :grad, read_url = :read_url, updated_at = NOW()
            WHERE id = :id
        ");
        $upStmt->execute([
            ':title' => $title,
            ':author' => $author,
            ':genre' => $genre,
            ':desc' => $description,
            ':rating' => $rating,
            ':avail' => $available,
            ':grad' => $gradient,
            ':read_url' => $readUrl,
            ':id' => $id
        ]);

        logActivity($user['email'], 'BOOK_UPDATED', "Admin updated book #{$id}: \"{$title}\"");

        sendJsonResponse(true, "Changes to \"{$title}\" have been saved.", [
            'id' => $id,
            'title' => $title,
            'author' => $author,
            'genre' => $genre,
            'available' => (bool)$available
        ]);
        break;

    // -------------------------------------------------------------------------
    // 4. DELETE Book (Admin deletes book from MySQL)
    // -------------------------------------------------------------------------
    case 'DELETE':
        $user = getAuthenticatedUser(true);
        if ($user['role'] !== 'admin') {
            sendJsonResponse(false, 'Administrator privileges required.', null, 403);
        }

        $id = $bookId ?: (int)($body['id'] ?? 0);
        if (!$id) {
            sendJsonResponse(false, 'Book ID required for deletion.', null, 400);
        }

        $stmt = $pdo->prepare("SELECT title FROM books WHERE id = :id LIMIT 1");
        $stmt->execute([':id' => $id]);
        $existing = $stmt->fetch();
        if (!$existing) {
            sendJsonResponse(false, 'Book not found in database.', null, 404);
        }

        $delStmt = $pdo->prepare("DELETE FROM books WHERE id = :id");
        $delStmt->execute([':id' => $id]);

        logActivity($user['email'], 'BOOK_DELETED', "Admin deleted book #{$id} (\"{$existing['title']}\") from catalog.");

        sendJsonResponse(true, "\"{$existing['title']}\" was removed from the catalog.");
        break;

    default:
        sendJsonResponse(false, "Method {$method} not allowed.", null, 405);
}
