<?php
/* ==========================================================================
   Aetheria Library — Admin Console & Oversight API Endpoint (LAMP / PHP)
   Operations: dashboard stats, users directory, user status, password reset,
   user deletion, and audit activity logs.
   Directly manages MySQL tables: users, user_profiles, sessions, activity_logs.
   ========================================================================== */

require_once __DIR__ . '/db.php';

$pdo = getSafeDBConnection();
$adminUser = getAuthenticatedUser(true);

if ($adminUser['role'] !== 'admin') {
    sendJsonResponse(false, 'Administrator privileges required.', null, 403);
}

$method = $_SERVER['REQUEST_METHOD'];
$body = getRequestBody();
$action = $_GET['action'] ?? $body['action'] ?? '';

// Auto-detect action if not given
if (empty($action)) {
    if ($method === 'GET') {
        $action = isset($_GET['logs']) ? 'logs' : (isset($_GET['users']) ? 'users' : 'dashboard');
    } elseif ($method === 'PUT') {
        $action = 'user_status';
    } elseif ($method === 'DELETE') {
        $action = 'delete_user';
    }
}

switch ($action) {
    // -------------------------------------------------------------------------
    // 1. Dashboard Statistics
    // -------------------------------------------------------------------------
    case 'dashboard':
    case 'stats':
        $totalUsers = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
        $activeUsers = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE status = 'active'")->fetchColumn();
        $disabledUsers = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE status = 'disabled'")->fetchColumn();
        $totalBooks = (int)$pdo->query("SELECT COUNT(*) FROM books")->fetchColumn();
        $availableBooks = (int)$pdo->query("SELECT COUNT(*) FROM books WHERE available = 1")->fetchColumn();
        $activeLoans = (int)$pdo->query("SELECT COUNT(*) FROM loans WHERE status = 'active-borrow'")->fetchColumn();
        $overdueLoans = (int)$pdo->query("SELECT COUNT(*) FROM loans WHERE status = 'active-borrow' AND due_date < NOW()")->fetchColumn();
        $totalReviews = (int)$pdo->query("SELECT COUNT(*) FROM reviews")->fetchColumn();

        // Recent users
        $recentUsersStmt = $pdo->query("
            SELECT u.id, u.username, u.email, u.role, u.status, u.last_login, u.created_at,
                   p.first_name, p.last_name, p.display_name, p.avatar
            FROM users u
            LEFT JOIN user_profiles p ON u.email = p.user_email
            ORDER BY u.created_at DESC
            LIMIT 5
        ");
        $recentUsers = $recentUsersStmt->fetchAll();

        // Recent activity
        $recentLogsStmt = $pdo->query("
            SELECT a.*, u.username
            FROM activity_logs a
            LEFT JOIN users u ON a.user_email = u.email
            ORDER BY a.created_at DESC
            LIMIT 10
        ");
        $recentLogs = $recentLogsStmt->fetchAll();

        $stats = [
            'totalUsers' => $totalUsers,
            'activeUsers' => $activeUsers,
            'disabledUsers' => $disabledUsers,
            'totalBooks' => $totalBooks,
            'availableBooks' => $availableBooks,
            'activeLoans' => $activeLoans,
            'overdueLoans' => $overdueLoans,
            'totalReviews' => $totalReviews,
            'recentUsers' => $recentUsers,
            'recentActivity' => $recentLogs,
            'database' => [
                'type' => 'MySQL (LAMP)',
                'name' => DB_NAME,
                'user' => DB_USER
            ]
        ];

        sendJsonResponse(true, 'Dashboard metrics calculated.', [
            'stats' => $stats
        ]);
        break;

    // -------------------------------------------------------------------------
    // 2. Members Directory List
    // -------------------------------------------------------------------------
    case 'users':
        $search = trim($_GET['search'] ?? '');
        $role = trim($_GET['role'] ?? 'all');
        $status = trim($_GET['status'] ?? 'all');

        $sql = "
            SELECT u.id, u.username, u.email, u.role, u.status, u.last_login, u.created_at,
                   p.first_name, p.last_name, p.display_name, p.gender, p.preferred_genre, p.avatar, p.phone, p.bio
            FROM users u
            LEFT JOIN user_profiles p ON u.email = p.user_email
            WHERE 1=1
        ";
        $params = [];

        if ($role !== 'all' && !empty($role)) {
            $sql .= " AND u.role = :role";
            $params[':role'] = $role;
        }

        if ($status !== 'all' && !empty($status)) {
            $sql .= " AND u.status = :status";
            $params[':status'] = $status;
        }

        if (!empty($search)) {
            $sql .= " AND (u.username LIKE :s1 OR u.email LIKE :s2 OR p.display_name LIKE :s3 OR p.first_name LIKE :s4 OR p.last_name LIKE :s5)";
            $params[':s1'] = "%{$search}%";
            $params[':s2'] = "%{$search}%";
            $params[':s3'] = "%{$search}%";
            $params[':s4'] = "%{$search}%";
            $params[':s5'] = "%{$search}%";
        }

        $sql .= " ORDER BY u.created_at DESC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $users = $stmt->fetchAll();

        foreach ($users as &$u) {
            $u['id'] = (int)$u['id'];
            $u['name'] = $u['display_name'] ?: trim(($u['first_name'] ?? '') . ' ' . ($u['last_name'] ?? '')) ?: $u['username'];
        }

        sendJsonResponse(true, 'Members directory retrieved.', $users);
        break;

    // -------------------------------------------------------------------------
    // 3. Update User Status (Enable / Disable)
    // -------------------------------------------------------------------------
    case 'user_status':
    case 'status':
        $target = trim($body['userId'] ?? $body['email'] ?? $_GET['id'] ?? '');
        $newStatus = trim($body['status'] ?? '');

        if (empty($target) || !in_array($newStatus, ['active', 'disabled'])) {
            sendJsonResponse(false, 'Valid user identifier and status ("active" or "disabled") required.', null, 400);
        }

        $chkStmt = $pdo->prepare("SELECT email, username, id FROM users WHERE id = :target_id OR email = :target_email LIMIT 1");
        $chkStmt->execute([':target_id' => $target, ':target_email' => $target]);
        $targetUser = $chkStmt->fetch();

        if (!$targetUser) {
            sendJsonResponse(false, 'User not found in database.', null, 404);
        }

        if ($targetUser['email'] === $adminUser['email']) {
            sendJsonResponse(false, 'You cannot disable your own administrator account.', null, 400);
        }

        $upStmt = $pdo->prepare("UPDATE users SET status = :status, updated_at = NOW() WHERE email = :email");
        $upStmt->execute([':status' => $newStatus, ':email' => $targetUser['email']]);

        // If disabling, terminate all active sessions immediately
        if ($newStatus === 'disabled') {
            $delSess = $pdo->prepare("DELETE FROM sessions WHERE user_email = :email");
            $delSess->execute([':email' => $targetUser['email']]);
        }

        logActivity($adminUser['email'], 'USER_STATUS_CHANGE', "Admin {$newStatus} account: {$targetUser['username']} ({$targetUser['email']})");

        sendJsonResponse(true, "User account status changed to {$newStatus}.", [
            'email' => $targetUser['email'],
            'status' => $newStatus
        ]);
        break;

    // -------------------------------------------------------------------------
    // 4. Admin Reset User Password
    // -------------------------------------------------------------------------
    case 'reset_password':
        $target = trim($body['userId'] ?? $body['email'] ?? '');
        $newPassword = trim($body['newPassword'] ?? $body['password'] ?? '');

        if (empty($target) || strlen($newPassword) < 6) {
            sendJsonResponse(false, 'Password must be at least 6 characters long.', null, 400);
        }

        $chkStmt = $pdo->prepare("SELECT email, username FROM users WHERE id = :target_id OR email = :target_email LIMIT 1");
        $chkStmt->execute([':target_id' => $target, ':target_email' => $target]);
        $targetUser = $chkStmt->fetch();

        if (!$targetUser) {
            sendJsonResponse(false, 'User not found in database.', null, 404);
        }

        $newHash = password_hash($newPassword, PASSWORD_BCRYPT);
        $upStmt = $pdo->prepare("UPDATE users SET password_hash = :hash, updated_at = NOW() WHERE email = :email");
        $upStmt->execute([':hash' => $newHash, ':email' => $targetUser['email']]);

        // Revoke active sessions
        $delSess = $pdo->prepare("DELETE FROM sessions WHERE user_email = :email");
        $delSess->execute([':email' => $targetUser['email']]);

        logActivity($adminUser['email'], 'ADMIN_PASSWORD_RESET', "Admin reset password for user: {$targetUser['username']} ({$targetUser['email']})");

        sendJsonResponse(true, "Password updated successfully for {$targetUser['email']}.");
        break;

    // -------------------------------------------------------------------------
    // 5. Delete User Account
    // -------------------------------------------------------------------------
    case 'delete_user':
    case 'user':
        $target = trim($body['userId'] ?? $body['email'] ?? $_GET['id'] ?? '');

        if (empty($target)) {
            sendJsonResponse(false, 'User identifier required for deletion.', null, 400);
        }

        $chkStmt = $pdo->prepare("SELECT email, username, id FROM users WHERE id = :target_id OR email = :target_email LIMIT 1");
        $chkStmt->execute([':target_id' => $target, ':target_email' => $target]);
        $targetUser = $chkStmt->fetch();

        if (!$targetUser) {
            sendJsonResponse(false, 'User not found in database.', null, 404);
        }

        if ($targetUser['email'] === 'admin@example.com' || $targetUser['email'] === $adminUser['email']) {
            sendJsonResponse(false, 'The primary administrator account cannot be deleted.', null, 400);
        }

        // Delete from users table (cascading deletes profiles, sessions, etc.)
        $delStmt = $pdo->prepare("DELETE FROM users WHERE email = :email");
        $delStmt->execute([':email' => $targetUser['email']]);

        logActivity($adminUser['email'], 'USER_DELETED', "Admin deleted user account: {$targetUser['username']} ({$targetUser['email']})");

        sendJsonResponse(true, "Account {$targetUser['email']} was deleted successfully.");
        break;

    // -------------------------------------------------------------------------
    // 6. Audit & Activity Logs
    // -------------------------------------------------------------------------
    case 'logs':
    case 'activity_logs':
        $search = trim($_GET['search'] ?? '');
        $limit = min((int)($_GET['limit'] ?? 50), 100);

        $sql = "
            SELECT a.*, u.username
            FROM activity_logs a
            LEFT JOIN users u ON a.user_email = u.email
            WHERE 1=1
        ";
        $params = [];

        if (!empty($search)) {
            $sql .= " AND (a.description LIKE :s1 OR a.action LIKE :s2 OR a.user_email LIKE :s3)";
            $params[':s1'] = "%{$search}%";
            $params[':s2'] = "%{$search}%";
            $params[':s3'] = "%{$search}%";
        }

        $sql .= " ORDER BY a.created_at DESC LIMIT {$limit}";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $logs = $stmt->fetchAll();

        sendJsonResponse(true, 'Activity logs retrieved.', $logs);
        break;

    default:
        sendJsonResponse(false, "Unknown admin action: {$action}", null, 400);
}
