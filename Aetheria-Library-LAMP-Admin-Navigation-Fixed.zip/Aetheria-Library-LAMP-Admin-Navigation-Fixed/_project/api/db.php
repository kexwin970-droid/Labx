<?php
/* ==========================================================================
   Aetheria Library — Central API Controller Helper (LAMP / PHP)
   Handles CORS headers, JSON request body parsing, standard JSON responses,
   token session verification, and audit logging.
   ========================================================================== */

require_once __DIR__ . '/../config.php';

// 1. CORS & Response Headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=UTF-8');

// Immediate return for OPTIONS preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

/**
 * Returns parsed JSON request payload as associative array
 *
 * @return array
 */
function getRequestBody() {
    $raw = file_get_contents('php://input');
    if (empty($raw)) {
        return $_POST ?: [];
    }
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

/**
 * Sends a structured JSON response and terminates execution
 *
 * @param bool $success
 * @param string $message
 * @param mixed $data
 * @param int $statusCode
 */
function sendJsonResponse($success, $message, $data = null, $statusCode = 200) {
    http_response_code($statusCode);
    $payload = [
        'success' => $success,
        'message' => $message
    ];
    if ($data !== null) {
        $payload['data'] = $data;
    }
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit();
}

/**
 * Returns shared PDO connection with graceful JSON error handling
 *
 * @return PDO
 */
function getSafeDBConnection() {
    try {
        return getDBConnection();
    } catch (Throwable $e) {
        sendJsonResponse(false, 'Database connection error: ' . $e->getMessage(), null, 503);
    }
}

/**
 * Retrieves Bearer token from HTTP Authorization header
 *
 * @return string|null
 */
function getBearerToken() {
    $headers = null;
    if (isset($_SERVER['Authorization'])) {
        $headers = trim($_SERVER['Authorization']);
    } elseif (isset($_SERVER['HTTP_AUTHORIZATION'])) {
        $headers = trim($_SERVER['HTTP_AUTHORIZATION']);
    } elseif (function_exists('apache_request_headers')) {
        $requestHeaders = apache_request_headers();
        $requestHeaders = array_combine(array_map('ucwords', array_keys($requestHeaders)), array_values($requestHeaders));
        if (isset($requestHeaders['Authorization'])) {
            $headers = trim($requestHeaders['Authorization']);
        }
    }

    if (!empty($headers) && preg_match('/Bearer\s(\S+)/', $headers, $matches)) {
        return $matches[1];
    }
    return $_GET['token'] ?? null;
}

/**
 * Retrieves active authenticated user using session token
 *
 * @param bool $required If true, exits with 401 if unauthenticated
 * @return array|null
 */
function getAuthenticatedUser($required = true) {
    $token = getBearerToken();
    if (empty($token)) {
        if ($required) {
            sendJsonResponse(false, 'Authentication token required. Please sign in.', null, 401);
        }
        return null;
    }

    try {
        $pdo = getDBConnection();
        // Check active session in sessions table
        $stmt = $pdo->prepare("
            SELECT s.user_email, u.id, u.username, u.email, u.role, u.status,
                   p.first_name, p.last_name, p.display_name, p.gender, p.preferred_genre, p.avatar
            FROM sessions s
            JOIN users u ON s.user_email = u.email
            LEFT JOIN user_profiles p ON u.email = p.user_email
            WHERE s.token = :token AND s.expires_at > NOW()
            LIMIT 1
        ");
        $stmt->execute([':token' => $token]);
        $user = $stmt->fetch();

        if (!$user) {
            // Also check base64 mock tokens for client flexibility
            if (strpos($token, 'token-') === 0) {
                $raw = substr($token, 6);
                $json = base64_decode($raw);
                $info = json_decode($json, true);
                if ($info && !empty($info['username'])) {
                    $uStmt = $pdo->prepare("
                        SELECT u.id, u.username, u.email, u.role, u.status,
                               p.first_name, p.last_name, p.display_name, p.gender, p.preferred_genre, p.avatar
                        FROM users u
                        LEFT JOIN user_profiles p ON u.email = p.user_email
                        WHERE u.username = :uname1 OR u.email = :uname2
                        LIMIT 1
                    ");
                    $uStmt->execute([':uname1' => $info['username'], ':uname2' => $info['username']]);
                    $user = $uStmt->fetch();
                }
            }
        }

        if (!$user) {
            if ($required) {
                sendJsonResponse(false, 'Invalid or expired session. Please sign in again.', null, 401);
            }
            return null;
        }

        if ($user['status'] === 'disabled') {
            sendJsonResponse(false, 'Your account has been disabled by an administrator. Please contact support.', null, 403);
        }

        return $user;
    } catch (Exception $e) {
        if ($required) {
            sendJsonResponse(false, 'Authentication error: ' . $e->getMessage(), null, 500);
        }
        return null;
    }
}

/**
 * Records user activity into SQL activity_logs table
 *
 * @param string|null $userEmail
 * @param string $action
 * @param string $description
 */
function logActivity($userEmail, $action, $description) {
    try {
        $pdo = getDBConnection();
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $agent = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255);
        $stmt = $pdo->prepare("
            INSERT INTO activity_logs (user_email, action, description, ip_address, user_agent)
            VALUES (:email, :action, :desc, :ip, :agent)
        ");
        $stmt->execute([
            ':email' => $userEmail,
            ':action' => $action,
            ':desc' => $description,
            ':ip' => $ip,
            ':agent' => $agent
        ]);
    } catch (Exception $e) {
        // Silently capture logging issues
    }
}
