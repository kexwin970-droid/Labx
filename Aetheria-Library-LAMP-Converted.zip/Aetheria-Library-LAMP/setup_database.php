<?php
/* ==========================================================================
   Aetheria Library — 1-Click Database Setup Runner (LAMP / XAMPP / WAMP)
   Initializes MySQL schema, creates tables, sets email as PRIMARY KEY,
   and seeds predefined demo accounts & book collection.
   Access via browser: http://localhost/setup_database.php or http://localhost/api/setup_database.php
   ========================================================================== */

require_once __DIR__ . '/config.php';

$isCli = (php_sapi_name() === 'cli');
$results = [];
$errors = [];

try {
    // 1. Connect to MySQL server (without selecting DB first)
    $rootDsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";charset=utf8mb4";
    $rootPdo = new PDO($rootDsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);

    // 2. Ensure database exists
    $rootPdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $results[] = "Database `" . DB_NAME . "` verified successfully.";

    // 3. Connect to the database
    $pdo = getDBConnection();

    // 4. Read database.sql schema file
    $sqlFile = __DIR__ . '/database.sql';
    if (!file_exists($sqlFile)) {
        throw new Exception("Schema file database.sql not found at " . $sqlFile);
    }

    $sqlContent = file_get_contents($sqlFile);

    // Disable foreign keys during table drops/creates
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 0;");

    // Execute queries from database.sql
    // Split by semicolons that are not inside strings
    $queries = explode(";\n", $sqlContent);
    $executedCount = 0;
    foreach ($queries as $rawQuery) {
        $q = trim($rawQuery);
        // Strip comment-only lines
        $lines = array_filter(explode("\n", $q), function($line) {
            $trimmed = trim($line);
            return !empty($trimmed) && strpos($trimmed, '--') !== 0;
        });
        $cleanQuery = trim(implode("\n", $lines));

        if (!empty($cleanQuery)) {
            try {
                $pdo->exec($cleanQuery);
                $executedCount++;
            } catch (PDOException $qe) {
                // Ignore harmless notice errors
                if (strpos($qe->getMessage(), 'already exists') === false) {
                    $errors[] = "Notice on statement: " . substr($cleanQuery, 0, 60) . "... (" . $qe->getMessage() . ")";
                }
            }
        }
    }

    $pdo->exec("SET FOREIGN_KEY_CHECKS = 1;");
    $results[] = "Executed {$executedCount} schema instructions from database.sql.";

    // 5. Verify tables created
    $tablesStmt = $pdo->query("SHOW TABLES");
    $tables = $tablesStmt->fetchAll(PDO::FETCH_COLUMN);
    $results[] = "Active tables in `" . DB_NAME . "`: " . implode(", ", $tables);

    // 6. Verify PRIMARY KEY on users is email
    $pkStmt = $pdo->query("SHOW KEYS FROM users WHERE Key_name = 'PRIMARY'");
    $pkRow = $pkStmt->fetch();
    if ($pkRow && strtolower($pkRow['Column_name']) === 'email') {
        $results[] = "Verified users table PRIMARY KEY: `email`";
    } else {
        $results[] = "Note: users table primary key column is: " . ($pkRow['Column_name'] ?? 'none');
    }

    // 7. Verify Seed Users Count
    $usersCount = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $booksCount = $pdo->query("SELECT COUNT(*) FROM books")->fetchColumn();
    $results[] = "Registered Accounts: {$usersCount} | Catalog Books: {$booksCount}";

} catch (Exception $e) {
    $errors[] = $e->getMessage();
}

if ($isCli) {
    echo "========================================================\n";
    echo "Aetheria Library Database Setup Runner (CLI)\n";
    echo "========================================================\n";
    foreach ($results as $res) {
        echo " [OK] " . $res . "\n";
    }
    if (!empty($errors)) {
        echo "\nErrors / Warnings:\n";
        foreach ($errors as $err) {
            echo " [!] " . $err . "\n";
        }
    }
    echo "========================================================\n";
    exit(empty($errors) ? 0 : 1);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Setup — Aetheria Library</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&family=Cinzel:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --bg-color: #0b0f19;
            --card-bg: rgba(17, 24, 39, 0.85);
            --border-color: rgba(255, 255, 255, 0.1);
            --primary: #6366f1;
            --primary-glow: rgba(99, 102, 241, 0.3);
            --success: #10b981;
            --warning: #f59e0b;
            --text-main: #f9fafb;
            --text-muted: #9ca3af;
        }
        body {
            font-family: 'Outfit', sans-serif;
            background-color: var(--bg-color);
            background-image: 
                radial-gradient(at 0% 0%, rgba(99, 102, 241, 0.15) 0px, transparent 50%),
                radial-gradient(at 100% 100%, rgba(168, 85, 247, 0.15) 0px, transparent 50%);
            color: var(--text-main);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
            padding: 24px;
            box-sizing: border-box;
        }
        .setup-card {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.6);
            backdrop-filter: blur(16px);
            max-width: 680px;
            width: 100%;
            padding: 40px;
            box-sizing: border-box;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo-icon {
            font-size: 3rem;
            color: var(--primary);
            margin-bottom: 15px;
            filter: drop-shadow(0 0 15px var(--primary-glow));
        }
        h1 {
            font-family: 'Cinzel', serif;
            font-size: 2rem;
            margin: 0 0 8px 0;
            letter-spacing: 1px;
        }
        .subtitle {
            color: var(--text-muted);
            font-size: 0.95rem;
        }
        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(16, 185, 129, 0.15);
            border: 1px solid rgba(16, 185, 129, 0.3);
            color: var(--success);
            padding: 6px 16px;
            border-radius: 9999px;
            font-size: 0.85rem;
            font-weight: 600;
            margin-top: 10px;
        }
        .status-badge.error {
            background: rgba(239, 68, 68, 0.15);
            border-color: rgba(239, 68, 68, 0.3);
            color: #ef4444;
        }
        .log-box {
            background: rgba(0, 0, 0, 0.4);
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 12px;
            padding: 20px;
            margin: 25px 0;
            font-family: monospace;
            font-size: 0.85rem;
            max-height: 240px;
            overflow-y: auto;
        }
        .log-item {
            margin-bottom: 8px;
            display: flex;
            align-items: flex-start;
            gap: 10px;
        }
        .log-item i {
            margin-top: 3px;
        }
        .log-item.ok { color: #a7f3d0; }
        .log-item.err { color: #fca5a5; }
        .grid-links {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 12px;
            margin-top: 25px;
        }
        .btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 12px 18px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            transition: all 0.2s ease;
        }
        .btn-primary {
            background: var(--primary);
            color: white;
            box-shadow: 0 4px 14px var(--primary-glow);
        }
        .btn-primary:hover {
            background: #4f46e5;
            transform: translateY(-2px);
        }
        .btn-secondary {
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.12);
            color: var(--text-main);
        }
        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.12);
            transform: translateY(-2px);
        }
        .credentials-box {
            background: rgba(99, 102, 241, 0.08);
            border: 1px solid rgba(99, 102, 241, 0.2);
            border-radius: 12px;
            padding: 16px;
            margin: 20px 0;
            font-size: 0.88rem;
        }
        .credentials-box h4 {
            margin: 0 0 8px 0;
            color: #a5b4fc;
        }
        .cred-row {
            display: flex;
            justify-content: space-between;
            padding: 4px 0;
            border-bottom: 1px dashed rgba(255,255,255,0.06);
        }
        .cred-row:last-child { border-bottom: none; }
    </style>
</head>
<body>
    <div class="setup-card">
        <div class="header">
            <div class="logo-icon"><i class="fa-solid fa-database"></i></div>
            <h1>Aetheria Library</h1>
            <div class="subtitle">LAMP / MySQL Database Initializer</div>
            <?php if (empty($errors)): ?>
                <div class="status-badge"><i class="fa-solid fa-circle-check"></i> SQL Database Ready & Connected</div>
            <?php else: ?>
                <div class="status-badge error"><i class="fa-solid fa-triangle-exclamation"></i> Setup Finished with Notices</div>
            <?php endif; ?>
        </div>

        <div class="credentials-box">
            <h4><i class="fa-solid fa-key"></i> Predefined Seed Accounts in SQL</h4>
            <div class="cred-row">
                <span>Member Account:</span>
                <strong>demo@example.com / Demo@123</strong>
            </div>
            <div class="cred-row">
                <span>Admin Account:</span>
                <strong>admin@example.com / Admin@123</strong>
            </div>
            <div class="cred-row">
                <span>Primary Key:</span>
                <span style="color:#a7f3d0;"><strong>email (VARCHAR 191)</strong></span>
            </div>
        </div>

        <div class="log-box">
            <?php foreach ($results as $res): ?>
                <div class="log-item ok"><i class="fa-solid fa-check"></i> <span><?= htmlspecialchars($res) ?></span></div>
            <?php endforeach; ?>
            <?php foreach ($errors as $err): ?>
                <div class="log-item err"><i class="fa-solid fa-triangle-exclamation"></i> <span><?= htmlspecialchars($err) ?></span></div>
            <?php endforeach; ?>
        </div>

        <div class="grid-links">
            <a href="home.html" class="btn btn-primary"><i class="fa-solid fa-house"></i> Enter Library</a>
            <a href="login.html" class="btn btn-secondary"><i class="fa-solid fa-right-to-bracket"></i> Member Login</a>
            <a href="admin.html" class="btn btn-secondary"><i class="fa-solid fa-shield-halved"></i> Admin Console</a>
        </div>
    </div>
</body>
</html>
