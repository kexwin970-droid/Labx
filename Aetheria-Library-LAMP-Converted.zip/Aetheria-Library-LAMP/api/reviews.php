<?php
/* ==========================================================================
   Aetheria Library — Book Reviews & Feedback API Endpoint (LAMP / PHP)
   Directly manages MySQL reviews table.
   ========================================================================== */

require_once __DIR__ . '/db.php';

$pdo = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];
$body = getRequestBody();

if ($method === 'GET') {
    $bookId = isset($_GET['bookId']) ? (int)$_GET['bookId'] : 0;
    $sql = "
        SELECT r.*, u.username, u.email as user_email, p.display_name as user_name, b.title as book_title
        FROM reviews r
        JOIN books b ON r.book_id = b.id
        JOIN users u ON r.user_email = u.email
        LEFT JOIN user_profiles p ON u.email = p.user_email
        WHERE 1=1
    ";
    $params = [];
    if ($bookId) {
        $sql .= " AND r.book_id = :bid";
        $params[':bid'] = $bookId;
    }
    $sql .= " ORDER BY r.created_at DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $reviews = $stmt->fetchAll();

    foreach ($reviews as &$r) {
        $r['id'] = (int)$r['id'];
        $r['bookId'] = (int)$r['book_id'];
        $r['userId'] = $r['user_email'];
        $r['userName'] = $r['user_name'] ?: $r['username'];
        $r['rating'] = (int)$r['rating'];
        $r['text'] = $r['review_text'];
        $r['date'] = $r['created_at'];
    }

    sendJsonResponse(true, 'Reviews retrieved.', $reviews);
}

if ($method === 'POST') {
    $user = getAuthenticatedUser(true);
    $bookId = (int)($body['bookId'] ?? 0);
    $rating = (int)($body['rating'] ?? 5);
    $text = trim($body['text'] ?? $body['reviewText'] ?? '');

    if (!$bookId || $rating < 1 || $rating > 5) {
        sendJsonResponse(false, 'Valid book ID and rating between 1 and 5 required.', null, 400);
    }

    $ins = $pdo->prepare("
        INSERT INTO reviews (user_email, book_id, rating, review_text)
        VALUES (:email, :bid, :rate, :text)
    ");
    $ins->execute([
        ':email' => $user['email'],
        ':bid' => $bookId,
        ':rate' => $rating,
        ':text' => $text
    ]);
    $newId = (int)$pdo->lastInsertId();

    logActivity($user['email'], 'REVIEW_SUBMITTED', "User submitted {$rating}-star review for book #{$bookId}");

    sendJsonResponse(true, 'Review submitted successfully.', [
        'id' => $newId,
        'bookId' => $bookId,
        'userId' => $user['email'],
        'userName' => $user['display_name'] ?: $user['username'],
        'rating' => $rating,
        'text' => $text,
        'date' => date('Y-m-d H:i:s')
    ], 201);
}

sendJsonResponse(false, "Method {$method} not allowed.", null, 405);
