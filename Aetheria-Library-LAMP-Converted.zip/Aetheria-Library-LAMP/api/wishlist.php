<?php
/* ==========================================================================
   Aetheria Library — Wishlist API Endpoint (LAMP / PHP)
   Directly manages MySQL wishlists table.
   ========================================================================== */

require_once __DIR__ . '/db.php';

$pdo = getDBConnection();
$user = getAuthenticatedUser(true);
$method = $_SERVER['REQUEST_METHOD'];
$body = getRequestBody();

if ($method === 'GET') {
    $stmt = $pdo->prepare("
        SELECT w.book_id, b.title, b.author, b.genre, b.rating, b.available, b.bg_gradient, b.description
        FROM wishlists w
        JOIN books b ON w.book_id = b.id
        WHERE w.user_email = :email
        ORDER BY w.created_at DESC
    ");
    $stmt->execute([':email' => $user['email']]);
    $rows = $stmt->fetchAll();

    $bookIds = array_map(function($r) { return (int)$r['book_id']; }, $rows);

    sendJsonResponse(true, 'Wishlist retrieved.', [
        'items' => $rows,
        'bookIds' => $bookIds
    ]);
}

if ($method === 'POST') {
    $bookId = (int)($body['bookId'] ?? 0);
    if (!$bookId) {
        sendJsonResponse(false, 'Valid book ID required.', null, 400);
    }

    $chk = $pdo->prepare("SELECT id FROM wishlists WHERE user_email = :email AND book_id = :bid LIMIT 1");
    $chk->execute([':email' => $user['email'], ':bid' => $bookId]);
    $exists = $chk->fetch();

    $inWishlist = false;
    if ($exists) {
        $del = $pdo->prepare("DELETE FROM wishlists WHERE user_email = :email AND book_id = :bid");
        $del->execute([':email' => $user['email'], ':bid' => $bookId]);
        $inWishlist = false;
    } else {
        $ins = $pdo->prepare("INSERT INTO wishlists (user_email, book_id) VALUES (:email, :bid)");
        $ins->execute([':email' => $user['email'], ':bid' => $bookId]);
        $inWishlist = true;
    }

    sendJsonResponse(true, $inWishlist ? 'Saved to wishlist.' : 'Removed from wishlist.', [
        'inWishlist' => $inWishlist
    ]);
}

sendJsonResponse(false, "Method {$method} not allowed.", null, 405);
