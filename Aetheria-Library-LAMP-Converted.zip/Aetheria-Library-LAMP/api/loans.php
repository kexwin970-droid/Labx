<?php
/* ==========================================================================
   Aetheria Library — Circulation & Loans API Endpoint (LAMP / PHP)
   Operations: list loans, borrow books, return loan, extend loan
   Directly manages MySQL tables: loans, books, activity_logs
   ========================================================================== */

require_once __DIR__ . '/db.php';

$pdo = getDBConnection();
$user = getAuthenticatedUser(true);

$method = $_SERVER['REQUEST_METHOD'];
$body = getRequestBody();
$action = $_GET['action'] ?? $body['action'] ?? '';

switch ($method) {
    // -------------------------------------------------------------------------
    // 1. GET Loans (All for admin, personal for member)
    // -------------------------------------------------------------------------
    case 'GET':
        $isAdmin = ($user['role'] === 'admin');
        $status = trim($_GET['status'] ?? 'all');
        $search = trim($_GET['search'] ?? '');

        $sql = "
            SELECT l.*, b.title as book_title, b.author as book_author, b.genre as book_genre, b.bg_gradient,
                   u.username, u.email as user_email, p.display_name as user_name
            FROM loans l
            JOIN books b ON l.book_id = b.id
            JOIN users u ON l.user_email = u.email
            LEFT JOIN user_profiles p ON u.email = p.user_email
            WHERE 1=1
        ";
        $params = [];

        if (!$isAdmin) {
            $sql .= " AND l.user_email = :email";
            $params[':email'] = $user['email'];
        }

        if ($status !== 'all' && !empty($status)) {
            $sql .= " AND l.status = :status";
            $params[':status'] = $status;
        }

        if (!empty($search)) {
            $sql .= " AND (b.title LIKE :s1 OR u.username LIKE :s2 OR l.user_email LIKE :s3)";
            $params[':s1'] = "%{$search}%";
            $params[':s2'] = "%{$search}%";
            $params[':s3'] = "%{$search}%";
        }

        $sql .= " ORDER BY l.borrow_date DESC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $loans = $stmt->fetchAll();

        foreach ($loans as &$l) {
            $l['id'] = (int)$l['id'];
            $l['bookId'] = (int)$l['book_id'];
            $l['userId'] = $l['user_email'];
            $l['borrowDate'] = $l['borrow_date'];
            $l['dueDate'] = $l['due_date'];
            $l['returnDate'] = $l['return_date'];
        }

        sendJsonResponse(true, 'Loans retrieved.', $loans);
        break;

    // -------------------------------------------------------------------------
    // 2. POST (Borrow / Return / Extend)
    // -------------------------------------------------------------------------
    case 'POST':
        if ($action === 'borrow' || empty($action) && isset($body['bookIds'])) {
            $rawIds = $body['bookIds'] ?? [];
            $bookIds = is_array($rawIds) ? $rawIds : [$rawIds];
            $durationDays = (int)($body['durationDays'] ?? 14);

            if (empty($bookIds)) {
                sendJsonResponse(false, 'No book IDs provided for borrowing.', null, 400);
            }

            $borrowDate = date('Y-m-d H:i:s');
            $dueDate = date('Y-m-d H:i:s', time() + ($durationDays * 86400));
            $created = [];

            foreach ($bookIds as $bId) {
                $id = (int)$bId;
                if (!$id) continue;

                // Check book existence
                $bStmt = $pdo->prepare("SELECT title, available FROM books WHERE id = :id LIMIT 1");
                $bStmt->execute([':id' => $id]);
                $bk = $bStmt->fetch();
                if (!$bk) continue;

                // Insert into loans table
                $ins = $pdo->prepare("
                    INSERT INTO loans (user_email, book_id, borrow_date, due_date, status)
                    VALUES (:email, :bid, :bdate, :ddate, 'active-borrow')
                ");
                $ins->execute([
                    ':email' => $user['email'],
                    ':bid' => $id,
                    ':bdate' => $borrowDate,
                    ':ddate' => $dueDate
                ]);
                $loanId = (int)$pdo->lastInsertId();

                // Mark book as unavailable in books table
                $up = $pdo->prepare("UPDATE books SET available = 0, updated_at = NOW() WHERE id = :id");
                $up->execute([':id' => $id]);

                $created[] = [
                    'id' => $loanId,
                    'bookId' => $id,
                    'title' => $bk['title'],
                    'dueDate' => $dueDate
                ];

                logActivity($user['email'], 'BOOK_BORROWED', "User checked out \"{$bk['title']}\" (due " . substr($dueDate, 0, 10) . ")");
            }

            sendJsonResponse(true, "Successfully checked out " . count($created) . " title(s).", $created, 201);
        }

        if ($action === 'return') {
            $loanId = (int)($body['loanId'] ?? 0);
            $bookId = (int)($body['bookId'] ?? 0);

            $sql = "SELECT * FROM loans WHERE 1=1";
            $p = [];
            if ($loanId) {
                $sql .= " AND id = :lid";
                $p[':lid'] = $loanId;
            } elseif ($bookId) {
                $sql .= " AND book_id = :bid AND status = 'active-borrow'";
                $p[':bid'] = $bookId;
            }

            if ($user['role'] !== 'admin') {
                $sql .= " AND user_email = :email";
                $p[':email'] = $user['email'];
            }

            $stmt = $pdo->prepare($sql);
            $stmt->execute($p);
            $loan = $stmt->fetch();

            if (!$loan) {
                sendJsonResponse(false, 'Active loan record not found.', null, 404);
            }

            $retDate = date('Y-m-d H:i:s');
            $upLoan = $pdo->prepare("UPDATE loans SET status = 'returned', return_date = :rdate WHERE id = :lid");
            $upLoan->execute([':rdate' => $retDate, ':lid' => $loan['id']]);

            // Mark book available in books table
            $upBook = $pdo->prepare("UPDATE books SET available = 1, updated_at = NOW() WHERE id = :bid");
            $upBook->execute([':bid' => $loan['book_id']]);

            logActivity($user['email'], 'BOOK_RETURNED', "User returned book #{$loan['book_id']}");

            sendJsonResponse(true, 'Book returned successfully.');
        }

        if ($action === 'extend') {
            $loanId = (int)($body['loanId'] ?? 0);
            $stmt = $pdo->prepare("SELECT * FROM loans WHERE id = :id AND status = 'active-borrow' LIMIT 1");
            $stmt->execute([':id' => $loanId]);
            $loan = $stmt->fetch();

            if (!$loan) {
                sendJsonResponse(false, 'Active loan not found.', null, 404);
            }

            $newDue = date('Y-m-d H:i:s', strtotime($loan['due_date']) + (14 * 86400));
            $up = $pdo->prepare("UPDATE loans SET due_date = :ndue WHERE id = :id");
            $up->execute([':ndue' => $newDue, ':id' => $loanId]);

            logActivity($user['email'], 'LOAN_EXTENDED', "Loan #{$loanId} extended until " . substr($newDue, 0, 10));

            sendJsonResponse(true, 'Loan extended by 14 days.', ['dueDate' => $newDue]);
        }

        sendJsonResponse(false, "Unknown loans POST action: {$action}", null, 400);
        break;

    default:
        sendJsonResponse(false, "Method {$method} not allowed.", null, 405);
}
