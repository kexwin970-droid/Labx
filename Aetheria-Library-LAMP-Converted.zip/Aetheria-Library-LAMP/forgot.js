/* ==========================================================================
   Aetheria Library — Forgot / Password Reset Controller
   Resets password client-side via LocalStorage.
   ========================================================================== */

document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("forgot-form");
    if (!form) return;

    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        const email = document.getElementById("forgot-email").value.trim().toLowerCase();
        const password = document.getElementById("forgot-password").value;
        const confirm = document.getElementById("forgot-confirm").value;

        // 1. Field validation
        if (!email) {
            showToast("Missing Email", "Please enter your account email address.", "error");
            return;
        }

        if (password.length < 6) {
            showToast("Weak Password", "Your new password must be at least 6 characters.", "warning");
            return;
        }

        if (password !== confirm) {
            showToast("Passwords Do Not Match", "Please make sure both password fields are identical.", "error");
            return;
        }

        const submitBtn = form.querySelector("button[type='submit']");
        const originalText = submitBtn ? submitBtn.innerHTML : "Reset Password";
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Updating Password...`;
        }

        try {
            // Client-side password reset
            const apiRes = await apiResetPassword(email, password);

            if (apiRes && apiRes.success) {
                showToast("Password Reset", apiRes.message || "Your password has been successfully updated. Redirecting to login...", "success");

                setTimeout(() => {
                    window.location.href = "login.html";
                }, 800);
                return;
            }

            const errorMsg = (apiRes && apiRes.message) ? apiRes.message : "Failed to reset password. Please check your email.";
            showToast("Reset Failed", errorMsg, "error");
        } catch (err) {
            showToast("Error", "Could not complete password reset.", "error");
        } finally {
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
            }
        }
    });
});
