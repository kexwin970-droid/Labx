/* ==========================================================================
   Aetheria Library — Administrator Login Controller
   Authenticates administrators client-side via LocalStorage.
   ========================================================================== */

document.addEventListener("DOMContentLoaded", () => {
    // 1. Theme sync
    const savedTheme = localStorage.getItem("aetheria_theme") || "dark";
    document.documentElement.setAttribute("data-theme", savedTheme);

    // 2. If already authenticated as an administrator, go straight to admin console
    const activeUser = getActiveUser();
    const token = getAuthToken();
    if (activeUser && activeUser.role === "admin" && token) {
        window.location.href = "admin.html";
        return;
    }

    const loginForm = document.getElementById("admin-login-form");
    const emailInput = document.getElementById("admin-email");
    const passwordInput = document.getElementById("admin-password");
    const autoFillBtn = document.getElementById("fill-demo-btn");

    // 3. Demo auto-fill helper (supports predefined admin@example.com / Admin@123)
    if (autoFillBtn && emailInput && passwordInput) {
        autoFillBtn.addEventListener("click", () => {
            emailInput.value = DEMO_ADMIN.email;
            passwordInput.value = DEMO_ADMIN.password;
            showToast("Demo Admin Credentials", "Credentials auto-filled (admin@example.com).", "info");
        });
    }

    // 4. Form Submission Handler
    if (loginForm) {
        loginForm.addEventListener("submit", async (e) => {
            e.preventDefault();

            const identifier = emailInput.value.trim();
            const password = passwordInput.value;

            if (!identifier || !password) {
                showToast("Missing Fields", "Please enter both admin username/email and password.", "warning");
                return;
            }

            const submitBtn = loginForm.querySelector("button[type='submit']");
            const originalText = submitBtn ? submitBtn.innerHTML : "Authenticate";
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Authenticating...`;
            }

            try {
                // Client-side authentication
                const apiRes = await apiLogin(identifier, password);

                if (apiRes && apiRes.success && apiRes.data && apiRes.data.user) {
                    const user = apiRes.data.user;

                    // Verify administrator role
                    if (user.role !== "admin") {
                        showToast("Access Restricted", "This account lacks administrator privileges.", "warning");
                        return;
                    }

                    showToast("Access Granted", `Welcome, ${user.name || "Administrator"}! Opening Admin Console...`, "success");

                    setTimeout(() => {
                        window.location.href = "admin.html";
                    }, 400);
                    return;
                }

                const errorMsg = (apiRes && apiRes.message) ? apiRes.message : "Administrator authentication failed.";
                showToast("Authentication Failed", errorMsg, "error");
            } catch (err) {
                showToast("Error", "Authentication error occurred.", "error");
            } finally {
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalText;
                }
            }
        });
    }
});
