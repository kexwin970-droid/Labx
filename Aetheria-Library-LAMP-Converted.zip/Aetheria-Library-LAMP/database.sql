-- =============================================================================
-- Aetheria Library — MySQL Relational Database Schema & Initial Data
-- Database: aetheria_library
-- Primary Key: email (for users table)
-- Compatible with LAMP (Linux/Apache/MySQL/PHP), XAMPP, WAMP, and Node.js
-- =============================================================================

CREATE DATABASE IF NOT EXISTS `aetheria_library` 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE `aetheria_library`;

-- Disable foreign key checks for table creation/reset
SET FOREIGN_KEY_CHECKS = 0;

-- -----------------------------------------------------------------------------
-- 1. Table: users (Core authentication entity - PRIMARY KEY: email)
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
    `email` VARCHAR(191) NOT NULL PRIMARY KEY,
    `id` INT AUTO_INCREMENT UNIQUE,
    `username` VARCHAR(50) NOT NULL UNIQUE,
    `password_hash` VARCHAR(255) NOT NULL,
    `role` ENUM('member', 'admin') NOT NULL DEFAULT 'member',
    `status` ENUM('active', 'disabled') NOT NULL DEFAULT 'active',
    `last_login` DATETIME DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_users_username` (`username`),
    INDEX `idx_users_role` (`role`),
    INDEX `idx_users_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 2. Table: user_profiles (Detailed member profile information)
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `user_profiles`;
CREATE TABLE `user_profiles` (
    `user_email` VARCHAR(191) NOT NULL PRIMARY KEY,
    `first_name` VARCHAR(100) DEFAULT '',
    `last_name` VARCHAR(100) DEFAULT '',
    `display_name` VARCHAR(255) DEFAULT '',
    `gender` ENUM('Male', 'Female', 'Other') DEFAULT 'Other',
    `preferred_genre` VARCHAR(100) DEFAULT 'Sci-Fi & Fantasy',
    `avatar` VARCHAR(50) DEFAULT '1',
    `phone` VARCHAR(50) DEFAULT '',
    `bio` TEXT DEFAULT NULL,
    `premium` TINYINT(1) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_profile_user_email`
        FOREIGN KEY (`user_email`) REFERENCES `users` (`email`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 3. Table: sessions (Active authentication sessions & tokens)
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_email` VARCHAR(191) NOT NULL,
    `token` VARCHAR(500) NOT NULL,
    `ip_address` VARCHAR(45) DEFAULT '',
    `user_agent` VARCHAR(255) DEFAULT '',
    `expires_at` DATETIME NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_sessions_token` (`token`(191)),
    INDEX `idx_sessions_user_email` (`user_email`),
    CONSTRAINT `fk_sessions_user_email`
        FOREIGN KEY (`user_email`) REFERENCES `users` (`email`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 4. Table: activity_logs (Audit and user activity tracking)
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `activity_logs`;
CREATE TABLE `activity_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_email` VARCHAR(191) DEFAULT NULL,
    `action` VARCHAR(100) NOT NULL,
    `description` TEXT NOT NULL,
    `ip_address` VARCHAR(45) DEFAULT '',
    `user_agent` VARCHAR(255) DEFAULT '',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_activity_user_email` (`user_email`),
    INDEX `idx_activity_action` (`action`),
    INDEX `idx_activity_created` (`created_at`),
    CONSTRAINT `fk_activity_user_email`
        FOREIGN KEY (`user_email`) REFERENCES `users` (`email`)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 5. Table: books (Library catalog items)
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `books`;
CREATE TABLE `books` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `title` VARCHAR(255) NOT NULL,
    `author` VARCHAR(255) NOT NULL,
    `genre` VARCHAR(100) NOT NULL,
    `description` TEXT,
    `rating` DECIMAL(2,1) DEFAULT 4.5,
    `available` TINYINT(1) DEFAULT 1,
    `bg_gradient` VARCHAR(255) DEFAULT 'linear-gradient(135deg, #0f172a, #06b6d4)',
    `header_color` VARCHAR(50) DEFAULT '#f3f4f6',
    `isbn` VARCHAR(50) DEFAULT '',
    `pages` INT DEFAULT 300,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_books_genre` (`genre`),
    INDEX `idx_books_available` (`available`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 6. Table: loans (Book checkout and circulation history)
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `loans`;
CREATE TABLE `loans` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_email` VARCHAR(191) NOT NULL,
    `book_id` INT NOT NULL,
    `borrow_date` DATETIME NOT NULL,
    `due_date` DATETIME NOT NULL,
    `return_date` DATETIME DEFAULT NULL,
    `status` ENUM('active-borrow', 'returned', 'overdue') DEFAULT 'active-borrow',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_loans_status` (`status`),
    INDEX `idx_loans_user_email` (`user_email`),
    CONSTRAINT `fk_loans_user_email`
        FOREIGN KEY (`user_email`) REFERENCES `users` (`email`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_loans_book`
        FOREIGN KEY (`book_id`) REFERENCES `books` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 7. Table: reviews (Reader reviews & ratings)
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `reviews`;
CREATE TABLE `reviews` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_email` VARCHAR(191) NOT NULL,
    `book_id` INT NOT NULL,
    `rating` INT NOT NULL CHECK (`rating` >= 1 AND `rating` <= 5),
    `review_text` TEXT NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_reviews_book` (`book_id`),
    INDEX `idx_reviews_user_email` (`user_email`),
    CONSTRAINT `fk_reviews_user_email`
        FOREIGN KEY (`user_email`) REFERENCES `users` (`email`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_reviews_book`
        FOREIGN KEY (`book_id`) REFERENCES `books` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 8. Table: wishlists (Personal user reading wishlists)
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `wishlists`;
CREATE TABLE `wishlists` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_email` VARCHAR(191) NOT NULL,
    `book_id` INT NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_user_book_wishlist` (`user_email`, `book_id`),
    CONSTRAINT `fk_wishlist_user_email`
        FOREIGN KEY (`user_email`) REFERENCES `users` (`email`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_wishlist_book`
        FOREIGN KEY (`book_id`) REFERENCES `books` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 9. Table: reading_records (Reader tracking & activity)
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `reading_records`;
CREATE TABLE `reading_records` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_email` VARCHAR(191) NOT NULL,
    `book_id` INT NOT NULL,
    `first_accessed` DATETIME NOT NULL,
    `last_accessed` DATETIME NOT NULL,
    `opens` INT DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_user_book_reading` (`user_email`, `book_id`),
    CONSTRAINT `fk_reading_user_email`
        FOREIGN KEY (`user_email`) REFERENCES `users` (`email`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_reading_book`
        FOREIGN KEY (`book_id`) REFERENCES `books` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;

-- =============================================================================
-- SEED DATA: Predefined Demo Users & Profiles
-- Passwords:
--   • demo@example.com  -> Demo@123  ($2b$10$D.X857X19ey2AQJ6MJBrAOKJ3N/UZfQiZ8HTtU0aLL9K7WbVbvPfy)
--   • admin@example.com -> Admin@123 ($2b$10$KDSyYO4aI5fq8vqFPNl3CON4Yd3F5.lfLizDaksgGy/0wj.gyrf16)
-- =============================================================================

INSERT INTO `users` (`email`, `id`, `username`, `password_hash`, `role`, `status`)
VALUES 
    ('demo@example.com', 1, 'demo', '$2b$10$D.X857X19ey2AQJ6MJBrAOKJ3N/UZfQiZ8HTtU0aLL9K7WbVbvPfy', 'member', 'active'),
    ('admin@example.com', 2, 'admin', '$2b$10$KDSyYO4aI5fq8vqFPNl3CON4Yd3F5.lfLizDaksgGy/0wj.gyrf16', 'admin', 'active')
ON DUPLICATE KEY UPDATE 
    `password_hash` = VALUES(`password_hash`),
    `status` = VALUES(`status`);

INSERT INTO `user_profiles` (`user_email`, `first_name`, `last_name`, `display_name`, `gender`, `preferred_genre`, `avatar`, `premium`)
VALUES 
    ('demo@example.com', 'Arthur', 'Pendragon', 'Arthur Pendragon', 'Male', 'Sci-Fi & Fantasy', '1', 1),
    ('admin@example.com', 'System', 'Administrator', 'System Administrator', 'Other', 'Technology & Science', '1', 1)
ON DUPLICATE KEY UPDATE 
    `display_name` = VALUES(`display_name`);

-- =============================================================================
-- SEED DATA: Library Book Catalog (12 Core Books)
-- =============================================================================

INSERT INTO `books` (`id`, `title`, `author`, `genre`, `description`, `rating`, `available`, `bg_gradient`, `header_color`, `isbn`, `pages`)
VALUES
    (1, 'Dune', 'Frank Herbert', 'Sci-Fi & Fantasy', 'Set on the desert planet Arrakis, Dune is the story of the boy Paul Atreides, who would become the mysterious man known as Muad\'Dib.', 4.9, 1, 'linear-gradient(135deg, #c27d38, #5e3a15)', '#f3f4f6', '978-0441013593', 688),
    (2, 'Neuromancer', 'William Gibson', 'Sci-Fi & Fantasy', 'Case, a low-level computer hacker, is hired by a mysterious employer to pull off the ultimate hack against a powerful artificial intelligence.', 4.7, 1, 'linear-gradient(135deg, #0f172a, #06b6d4)', '#67e8f9', '978-0441569595', 271),
    (3, 'The Shadow of the Wind', 'Carlos Ruiz Zafón', 'Mystery & Thriller', 'In the ruins of Barcelona, Daniel Sempere is taken to the Cemetery of Forgotten Books, where he selects a novel that changes the course of his life.', 4.8, 1, 'linear-gradient(135deg, #3730a3, #4338ca)', '#e0e7ff', '978-0143034902', 487),
    (4, 'Sapiens: A Brief History', 'Yuval Noah Harari', 'History & Biography', 'Dr Yuval Noah Harari spans the whole of human history, from the very first humans to walk the earth to the radical breakthroughs of the Cognitive revolution.', 4.6, 1, 'linear-gradient(135deg, #78350f, #b45309)', '#fef3c7', '978-0062316097', 464),
    (5, 'Clean Code', 'Robert C. Martin', 'Technology & Science', 'Even bad code can function. But if code isn\'t clean, it can bring a development organization to its knees. This book teaches you how to write software well.', 4.8, 1, 'linear-gradient(135deg, #065f46, #059669)', '#d1fae5', '978-0132350884', 464),
    (6, 'Meditations', 'Marcus Aurelius', 'Philosophy & Psychology', 'Private thoughts of the world\'s most powerful man on how to lead a good, meaningful life amid chaos, duty, and mortality.', 4.7, 1, 'linear-gradient(135deg, #1c1917, #78716c)', '#e7e5e4', '978-0140449334', 256),
    (7, 'The Silent Patient', 'Alex Michaelides', 'Mystery & Thriller', 'Alicia Berenson shoots her husband five times and never speaks again. A psychotherapist is determined to uncover why.', 4.5, 1, 'linear-gradient(135deg, #7f1d1d, #ef4444)', '#fca5a5', '978-1250301696', 336),
    (8, 'Steve Jobs', 'Walter Isaacson', 'History & Biography', 'The exclusive biography of the creative entrepreneur whose passion for perfection revolutionized six industries.', 4.7, 1, 'linear-gradient(135deg, #1e293b, #475569)', '#cbd5e1', '978-1451648539', 656),
    (9, 'Designing Data-Intensive Apps', 'Martin Kleppmann', 'Technology & Science', 'An indispensable guide through databases, reliability, scalability, and distributed stream processors.', 4.9, 1, 'linear-gradient(135deg, #0f172a, #4f46e5)', '#c7d2fe', '978-1449373320', 616),
    (10, 'Atomic Habits', 'James Clear', 'Philosophy & Psychology', 'An easy and proven way to build good habits and break bad ones. Transform your daily routines into remarkable results.', 4.9, 1, 'linear-gradient(135deg, #701a75, #ec4899)', '#f5d0fe', '978-0735211292', 320),
    (11, 'The Psychology of Money', 'Morgan Housel', 'Philosophy & Psychology', 'Timeless lessons on wealth, greed, and happiness. Doing well with money isn’t about what you know, it’s about how you behave.', 4.8, 1, 'linear-gradient(135deg, #1e293b, #475569)', '#cbd5e1', '978-0857197689', 256),
    (12, 'Project Hail Mary', 'Andy Weir', 'Sci-Fi & Fantasy', 'Ryland Grace is the sole survivor on a desperate last-chance space mission to save humanity and the planet.', 4.9, 1, 'linear-gradient(135deg, #3730a3, #4338ca)', '#e0e7ff', '978-0593135204', 496)
ON DUPLICATE KEY UPDATE 
    `title` = VALUES(`title`),
    `author` = VALUES(`author`),
    `available` = VALUES(`available`);

-- Record initial setup in activity_logs
INSERT INTO `activity_logs` (`user_email`, `action`, `description`)
VALUES ('admin@example.com', 'DATABASE_INITIALIZATION', 'Aetheria Library database initialized with users, profiles, and 12 books.')
ON DUPLICATE KEY UPDATE `action` = `action`;
