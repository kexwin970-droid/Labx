/* ==========================================================================
   Aetheria Library — Login Controller
   Authenticates users client-side via LocalStorage.
   ========================================================================== */

document.addEventListener("DOMContentLoaded", () => {
    // If user is already logged in, redirect based on role
    const currentUser = getActiveUser();
    if (currentUser) {
        if (currentUser.role === "admin") {
            window.location.href = "admin.html";
        } else {
            window.location.href = "home.html";
        }
        return;
    }

    const emailInput = document.getElementById("login-email");
    const passwordInput = document.getElementById("login-password");
    const loginForm = document.getElementById("login-form");

    // 1. Predefined Demo Credential Helper Button
    const btnDemoUser = document.getElementById("btn-demo-user");

    if (btnDemoUser && emailInput && passwordInput) {
        btnDemoUser.addEventListener("click", () => {
            emailInput.value = DEMO_USER.username;
            passwordInput.value = DEMO_USER.password;
            showToast("Demo Member Selected", "Credentials auto-filled for demo user.", "info");
        });
    }

    // 2. Form Submission Handler
    if (!loginForm) return;

    loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const identifier = emailInput.value.trim();
        const password = passwordInput.value;

        if (!identifier || !password) {
            showToast("Missing Fields", "Please enter both username/email and password.", "warning");
            return;
        }

        // Show loading state
        const submitBtn = loginForm.querySelector("button[type='submit']");
        const originalText = submitBtn ? submitBtn.innerHTML : "Sign In";
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Authenticating...`;
        }

        try {
            // Client-side authentication
            const apiRes = await apiLogin(identifier, password);

            if (apiRes && apiRes.success && apiRes.data && apiRes.data.user) {
                const user = apiRes.data.user;
                showToast("Access Granted", apiRes.message || `Welcome back, ${user.name || user.firstName}!`, "success");

                setTimeout(() => {
                    if (user.role === "admin") {
                        window.location.href = "admin.html";
                    } else {
                        window.location.href = "home.html";
                    }
                }, 400);
                return;
            }

            // Display error message
            const errorMsg = (apiRes && apiRes.message) ? apiRes.message : "Authentication failed. Please verify credentials.";
            showToast("Login Failed", errorMsg, "error");
        } catch (err) {
            showToast("Error", "Authentication error occurred.", "error");
        } finally {
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
            }
        }
    });
});
