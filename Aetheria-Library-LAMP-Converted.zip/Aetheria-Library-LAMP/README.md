# Aetheria Library — Full-Stack Web Application

A complete, functional full-stack web application with modern responsive frontend, Express REST API backend, relational MySQL database persistence, secure user authentication with bcrypt and JWT, audit/activity logging, and a feature-rich Administrator Control Console.

---

## 🔑 Predefined Demo Accounts

The application automatically seeds and maintains predefined demo accounts on initialization. Both accounts use the **exact same authentication system** as all registered members:

| Account Type | Username | Email | Password | Role | Portal |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Demo Member** | `demo` | `demo@example.com` | `Demo@123` | `member` | [Member Login](http://localhost:3000/login.html) |
| **Demo Administrator** | `admin` | `admin@example.com` | `Admin@123` | `admin` | [Admin Console](http://localhost:3000/admin_login.html) |

Both login pages also include **1-Click Auto-Fill Demo buttons** for rapid testing.

---

## 🏗️ System Architecture

```text
                  ┌───────────────────────────────┐
                  │           Frontend            │
                  │  (HTML5 / CSS3 / Vanilla JS)  │
                  │  • login.html / signup.html   │
                  │  • home.html (Bookshelf, UI)  │
                  │  • admin.html (Admin Console) │
                  └───────────────┬───────────────┘
                                  │
                                  │ HTTP / HTTPS (REST API)
                                  │ Bearer JWT Authorization
                                  ▼
                  ┌───────────────────────────────┐
                  │          Backend API          │
                  │   (Node.js / Express Server)  │
                  │  • Token & Role Middleware    │
                  │  • bcrypt Password Hashing    │
                  │  • Input Validation & Audit   │
                  └───────────────┬───────────────┘
                                  │
                                  │ Parameterized SQL Queries
                                  ▼
                  ┌───────────────────────────────┐
                  │       MySQL Database          │
                  │  • users                      │
                  │  • user_profiles              │
                  │  • sessions                   │
                  │  • activity_logs              │
                  │  • books                      │
                  │  • loans                      │
                  │  • reviews                    │
                  │  • wishlists                  │
                  │  • reading_records            │
                  └───────────────────────────────┘
```

> **Single Source of Truth**: MySQL is the central, authoritative data store. Any change made in the frontend or admin panel is sent through the REST API, processed by backend business logic, and updated in the database.

---

## 🗄️ Relational Database Schema (`database.sql`)

The database is organized with primary keys, foreign keys (`ON DELETE CASCADE`), indexes, and unique constraints across 9 tables:

1. **`users`**: Core credentials (`id`, `username`, `email`, `password_hash`, `role`, `status`, `created_at`, `updated_at`).
2. **`user_profiles`**: Personal details (`user_id` FK -> `users.id`, `first_name`, `last_name`, `display_name`, `gender`, `preferred_genre`, `avatar`, `phone`, `bio`, `premium`).
3. **`sessions`**: Server-tracked active tokens (`id`, `user_id` FK, `token`, `ip_address`, `user_agent`, `expires_at`).
4. **`activity_logs`**: System audit trail (`id`, `user_id` FK, `action`, `description`, `ip_address`, `user_agent`, `created_at`).
5. **`books`**: Literary catalog (`id`, `title`, `author`, `genre`, `description`, `rating`, `available`, `bg_gradient`, `header_color`, `isbn`, `pages`).
6. **`loans`**: Circulation checkouts (`id`, `user_id` FK, `book_id` FK -> `books.id`, `borrow_date`, `due_date`, `return_date`, `status`).
7. **`reviews`**: Community reader ratings (`id`, `user_id` FK, `book_id` FK, `rating`, `comment`, `created_at`).
8. **`wishlists`**: User book bookmarks (`id`, `user_id` FK, `book_id` FK, `created_at`).
9. **`reading_records`**: Digital e-reader telemetry (`id`, `user_id` FK, `book_id` FK, `first_accessed`, `last_accessed`, `open_count`).

---

## 📡 REST API Reference

All protected endpoints require `Authorization: Bearer <token>`.

### Authentication & Profile (`/api/auth/*`)
- `POST /api/auth/register` — Create member account, hash password with bcrypt, initialize profile.
- `POST /api/auth/login` — Authenticate username or email, verify bcrypt hash, return JWT token.
- `POST /api/auth/logout` — Invalidate user session and token in database.
- `GET /api/auth/me` — Retrieve authenticated user profile from MySQL.
- `PUT /api/auth/profile` — Update user profile details in MySQL.
- `PUT /api/auth/change-password` — Verify current password and update hashed password.
- `POST /api/auth/reset-password` — Password recovery workflow.

### User Management (`/api/users/*`) *(Admin Role Required)*
- `GET /api/users` — List users with search, role, and status filtering.
- `GET /api/users/:id` — Retrieve single user details and loan history.
- `POST /api/users` — Admin registers a new user directly into MySQL.
- `PUT /api/users/:id` — Update member information.
- `PUT /api/users/:id/status` — Enable/disable account (revokes active sessions if disabled).
- `POST /api/users/:id/password` — Reset user password securely.
- `DELETE /api/users/:id` — Delete user account and cascade associated data.

### Admin Dashboard & Audit Logs (`/api/admin/*`) *(Admin Role Required)*
- `GET /api/admin/dashboard` — Live calculated statistics (total users, active/disabled users, books volume, active/overdue loans, reviews, recent activity).
- `GET /api/admin/activity-logs` — Audit log trail with keyword search and event type filtering.
- `GET /api/admin/health` — System and database connection status.

### Catalog & Circulation (`/api/books/*`, `/api/loans/*`, `/api/reviews/*`)
- `GET /api/books` / `POST /api/books` / `PUT /api/books/:id` / `DELETE /api/books/:id`
- `GET /api/loans` / `POST /api/loans/borrow` / `POST /api/loans/return` / `POST /api/loans/extend`
- `GET /api/reviews` / `POST /api/reviews` / `DELETE /api/reviews/:id`
- `GET /api/wishlist` / `POST /api/wishlist/toggle`
- `GET /api/reading` / `POST /api/reading/record`

---

## ⚙️ Configuration & Local Setup

### 1. Requirements
- Node.js (v18+)
- MySQL Server (optional for external setup; the application automatically switches to its integrated relational engine if MySQL port 3306 is not yet running, ensuring zero downtime).

### 2. Environment Variables (`.env`)
Create a `.env` file based on `.env.example`:

```env
PORT=3000
NODE_ENV=development

DB_HOST=127.0.0.1
DB_PORT=3306
DB_NAME=aetheria_library
DB_USER=root
DB_PASSWORD=your_mysql_password

JWT_SECRET=super_secret_jwt_key_aetheria_library_2026
JWT_EXPIRES_IN=7d
```

### 3. Start the Server
```powershell
node server.js
```
The server will start listening at `http://localhost:3000`.

### 4. Running the Comprehensive Test Suite
```powershell
node test_e2e_fullstack.js
```
This automated test suite validates all 14 criteria:
- Member login & admin login
- Database registration
- bcrypt validation & invalid login rejection
- Profile persistence
- Admin user discovery and status toggles (`active` / `disabled`)
- Disabled account authentication rejection
- Real-time audit and activity logging
- Session token invalidation on logout
- Role-based authorization boundaries
- Anonymous access blocking
- Circulation borrow & return lifecycle
- Live database aggregation of dashboard metrics

---

## 🐘 LAMP (Linux / Apache / MySQL / PHP) Localhost Deployment

The entire system includes native PHP backend APIs and configuration to run under **LAMP**, **XAMPP**, or **WAMP**:

### 1. File Structure for LAMP
```text
/ (Web Root or htdocs/aetheria)
├── config.php             # PDO database connection factory
├── setup_database.php     # 1-click web runner & schema installer
├── database.sql           # MySQL DDL with email as PRIMARY KEY
├── .htaccess              # Apache URL rewriting & CORS rules
├── api/
│   ├── db.php             # Central API helper (CORS, JSON, Bearer token, logs)
│   ├── auth.php           # Native PHP authentication (login, register, me, logout)
│   ├── books.php          # Native PHP book catalog (CRUD on books table)
│   ├── admin.php          # Native PHP admin oversight (stats, users, logs)
│   ├── loans.php          # Native PHP circulation (borrow, return, extend)
│   ├── reviews.php        # Native PHP reader reviews
│   └── wishlist.php       # Native PHP personal bookmarks
└── frontend files (home.html, admin.html, login.html, signup.html, etc.)
```

### 2. Setup Steps on XAMPP / LAMP
1. **Copy Files**: Place the project folder into your Apache document root:
   - **XAMPP (Windows)**: `C:\xampp\htdocs\aetheria`
   - **LAMP (Linux)**: `/var/www/html/aetheria`
2. **Start Apache & MySQL**:
   - In XAMPP Control Panel, start **Apache** and **MySQL**.
3. **1-Click Database Setup**:
   - Open your browser and navigate to:
     `http://localhost/aetheria/setup_database.php` (or `http://localhost/setup_database.php` if placed at root).
   - This script automatically creates the `aetheria_library` database, applies `database.sql`, verifies `email` as `PRIMARY KEY`, and seeds the initial demo accounts and books.
   - Alternatively, import `database.sql` directly into **phpMyAdmin** (`http://localhost/phpmyadmin`).
4. **Access Website on Localhost**:
   - **Catalog & Home**: `http://localhost/aetheria/home.html`
   - **Member Sign In**: `http://localhost/aetheria/login.html`
   - **Member Register**: `http://localhost/aetheria/signup.html`
   - **Admin Console**: `http://localhost/aetheria/admin.html`
   - **Admin Login**: `http://localhost/aetheria/admin_login.html`

---

## 🔄 Admin Panel & Website Real-Time Synchronization

All changes made in the **Admin Console (`admin.html`)** reflect immediately in the **SQL Database** and across the **Website (`home.html`)**:

1. **Adding a Book**:
   - Admin fills in the "Add Book" modal.
   - `apiCreateBook()` executes `POST /api/books` which inserts the record into MySQL `books` table.
   - A `booksUpdated` custom event and `BroadcastChannel` message are dispatched.
   - `home.html` refreshes its catalog grid and multi-tier 3D bookshelf showcase in real-time without requiring a page reload.
2. **Editing a Book**:
   - Admin edits title, genre, rating, or availability.
   - `apiUpdateBook()` executes `PUT /api/books/:id` which updates the MySQL `books` table.
   - Website catalog re-renders instantly to reflect the updated book data.
3. **Deleting a Book**:
   - Admin clicks delete.
   - `apiDeleteBook()` executes `DELETE /api/books/:id` which deletes the book from MySQL.
   - Website catalog immediately removes the volume.
4. **Member Status Management**:
   - Admin toggles a member between **Active** and **Disabled**.
   - `apiUpdateUserStatus()` executes `PUT /api/users/:id/status` which updates `users.status` in MySQL.
   - Disabled members are instantly blocked from signing in (HTTP 403 Account Disabled).
