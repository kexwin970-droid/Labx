# Aetheria Library — LAMP Deployment

This build is for Linux + Apache + MariaDB/MySQL + PHP. It does not require Node.js.

## Requirements
- Apache 2.4+
- PHP 8.x with PDO MySQL
- MariaDB/MySQL
- Apache `mod_rewrite`

## Deploy on Kali/Debian/Ubuntu

```bash
sudo apt update
sudo apt install apache2 mariadb-server php libapache2-mod-php php-mysql php-curl php-mbstring php-json unzip -y
sudo a2enmod rewrite headers
sudo systemctl enable --now apache2 mariadb
```

Copy the project to Apache, for example:

```bash
sudo cp -r Aetheria-Library-LAMP /var/www/html/aetheria
sudo chown -R www-data:www-data /var/www/html/aetheria
```

Enable `.htaccess` overrides in `/etc/apache2/apache2.conf`:

```apache
<Directory /var/www/>
    Options Indexes FollowSymLinks
    AllowOverride All
    Require all granted
</Directory>
```

Then:

```bash
sudo systemctl restart apache2
```

## Database

The included `database.sql` creates `aetheria_library` and its tables/data.

```bash
sudo mysql < /var/www/html/aetheria/database.sql
```

Configure database credentials in the server environment or `config.php` as appropriate for your installation. Do not expose `config.php` or `database.sql` publicly.

## Open the application

```text
http://localhost/aetheria/
```

Admin login:

```text
http://localhost/aetheria/admin_login.html
```

## API smoke tests

```bash
curl -i http://localhost/aetheria/api/books
```

The frontend resolves `/api` relative to the current application directory, so deployment in `/aetheria/` does not accidentally call `/api` at the server root.

## Notes
- The SQL database is the authoritative store for users, credentials, books, loans, reviews, wishlists, and sessions.
- The project contains no Node.js runtime/dependency tree in this LAMP build.
- Change demo/admin passwords before exposing the application to the Internet.
