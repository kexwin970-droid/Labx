# Aetheria Library — LAMP Edition

This package is the cleaned LAMP deployment of Aetheria Library. The Node.js/Express backend and Node dependency tree have been removed.

## Stack
- Linux
- Apache 2
- PHP with PDO MySQL
- MariaDB/MySQL
- HTML/CSS/JavaScript frontend

## Important files
- `config.php` — PHP/MySQL configuration
- `database.sql` — database schema
- `setup_database.php` — database setup helper
- `.htaccess` — Apache API routing
- `api/` — native PHP API controllers

## Deploy on Kali/Debian/Ubuntu

```bash
sudo apt update
sudo apt install apache2 mariadb-server php php-mysql libapache2-mod-php php-curl php-mbstring php-json unzip -y
sudo systemctl enable --now apache2
sudo systemctl enable --now mariadb
```

Copy the project into Apache:

```bash
sudo cp -r _project /var/www/html/aetheria
sudo chown -R www-data:www-data /var/www/html/aetheria
```

Enable Apache modules:

```bash
sudo a2enmod rewrite headers
sudo systemctl restart apache2
```

Create/import the database:

```bash
sudo mysql -e "CREATE DATABASE IF NOT EXISTS aetheria_library CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
sudo mysql aetheria_library < /var/www/html/aetheria/database.sql
```

Then open:

`http://localhost/aetheria/`

## API

The frontend uses same-origin `/api` routes. Apache rewrites these routes to the PHP controllers in `api/`. No Node.js server or npm installation is required.

## Removed from this LAMP package
- `backend/` Node.js/Express source
- `node_modules/`
- `server.js`
- `package.json`
- `package-lock.json`
- `.env` / `.env.example` Node environment files
- Node-based test scripts

Keep the original ZIP as a backup until the LAMP deployment has been fully tested.
