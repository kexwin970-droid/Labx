/* ==========================================================================
   Aetheria Library — Administrator Login Controller (Admin Folder)
   Authenticates administrators with MySQL database backend via PHP.
   ========================================================================== */

document.addEventListener("DOMContentLoaded", () => {
    // 1. Theme sync
    const savedTheme = localStorage.getItem("aetheria_theme") || "dark";
    document.documentElement.setAttribute("data-theme", savedTheme);

    // 2. If already authenticated as an administrator, go straight to admin console
    const activeUser = getActiveUser();
    if (activeUser && activeUser.role === "admin") {
        window.location.href = "../admin.html";
        return;
    }

    const loginForm = document.getElementById("admin-login-form");
    const emailInput = document.getElementById("admin-email");
    const passwordInput = document.getElementById("admin-password");
    const autoFillBtn = document.getElementById("fill-demo-btn");

    // 3. Demo auto-fill helper
    if (autoFillBtn && emailInput && passwordInput) {
        autoFillBtn.addEventListener("click", () => {
            emailInput.value = "admin@aetheria.org";
            passwordInput.value = "admin123";
            showToast("Demo Credentials", "Admin demo credentials auto-filled.", "info");
        });
    }

    // 4. Form Submission Handler
    if (loginForm) {
        loginForm.addEventListener("submit", async (e) => {
            e.preventDefault();

            const email = emailInput.value.trim().toLowerCase();
            const password = passwordInput.value;

            if (!email || !password) {
                showToast("Missing Fields", "Please enter both admin email and password.", "warning");
                return;
            }

            // 1. Attempt authentication against MySQL via PHP API
            const apiRes = await apiLogin(email, password);

            if (apiRes && apiRes.success && apiRes.data && apiRes.data.user) {
                const user = apiRes.data.user;

                if (user.role !== "admin") {
                    showToast("Access Restricted", "This account is a reader account and lacks administrator privileges.", "warning");
                    return;
                }

                setActiveUser(user);
                showToast("Access Granted", `Welcome, ${user.name || "Administrator"}! Opening Admin Console...`, "success");

                setTimeout(() => {
                    window.location.href = "../admin.html";
                }, 600);
                return;
            }

            // Fallback for local testing if server is offline
            if (apiRes && (apiRes.isLocalFile || apiRes.networkError)) {
                const users = getUsers();
                const user = users.find(u => u.email.toLowerCase() === email);

                if (!user) {
                    showToast("Authentication Failed", "No registered account found with this email address.", "error");
                    return;
                }

                if (user.password !== password) {
                    showToast("Authentication Failed", "Incorrect administrator password credentials.", "error");
                    return;
                }

                if (user.role !== "admin") {
                    showToast("Access Restricted", "This account lacks administrator privileges.", "warning");
                    return;
                }

                setActiveUser(user);
                showToast("Access Granted", `Welcome, ${user.name}! Opening Admin Console...`, "success");

                setTimeout(() => {
                    window.location.href = "../admin.html";
                }, 600);
                return;
            }

            const errorMsg = (apiRes && apiRes.error) ? apiRes.error : "Admin authentication failed.";
            showToast("Authentication Failed", errorMsg, "error");
        });
    }
});
