/* ==========================================================================
   Aetheria Library — Sign-Up Page Controller
   Registers users into MySQL database backend via PHP api/auth.php.
   Primary Key: email
   ========================================================================== */

document.addEventListener("DOMContentLoaded", () => {
    // If user is already logged in, redirect to home page
    const currentUser = getActiveUser();
    if (currentUser) {
        window.location.href = "home.html";
        return;
    }

    // Radio button active styling sync
    const genderRadios = document.querySelectorAll('input[name="signup-gender"]');
    genderRadios.forEach(radio => {
        radio.addEventListener("change", () => {
            document.querySelectorAll(".radio-option").forEach(opt => opt.classList.remove("selected"));
            if (radio.checked) {
                radio.closest(".radio-option")?.classList.add("selected");
            }
        });
    });

    // Signup Form Handler
    const signupForm = document.getElementById("signup-form");
    if (!signupForm) return;

    signupForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const firstNameInput = document.getElementById("signup-firstname");
        const lastNameInput = document.getElementById("signup-lastname");
        const emailInput = document.getElementById("signup-email");
        const genderInput = document.querySelector('input[name="signup-gender"]:checked');
        const passwordInput = document.getElementById("signup-password");
        const confirmPasswordInput = document.getElementById("signup-confirm-password");

        const firstName = firstNameInput ? firstNameInput.value.trim() : "";
        const lastName = lastNameInput ? lastNameInput.value.trim() : "";
        const fullName = `${firstName} ${lastName}`.trim();
        const email = emailInput ? emailInput.value.trim().toLowerCase() : "";
        const gender = genderInput ? genderInput.value : "Other";
        const password = passwordInput ? passwordInput.value : "";
        const confirmPassword = confirmPasswordInput ? confirmPasswordInput.value : "";

        if (!firstName) {
            showToast("Validation Error", "Please enter your first name.", "warning");
            return;
        }

        if (password !== confirmPassword) {
            showToast("Password Mismatch", "Passwords do not match. Please verify and retry.", "error");
            return;
        }

        if (password.length < 6) {
            showToast("Weak Password", "Password must be at least 6 characters long.", "error");
            return;
        }

        const newUserPayload = {
            firstName,
            lastName,
            email,
            gender,
            password
        };

        // 1. Attempt registering account directly in MySQL via PHP API
        const apiRes = await apiSignup(newUserPayload);

        if (apiRes && apiRes.success) {
            // Also cache locally for instant access
            const users = getUsers();
            if (!users.some(u => u.email === email)) {
                users.push({
                    name: fullName,
                    firstName,
                    lastName,
                    email,
                    gender,
                    password,
                    role: "member",
                    genre: "Sci-Fi & Fantasy",
                    avatar: "1"
                });
                saveUsers(users);
            }

            showToast("Success", "Account created successfully in MySQL! Redirecting to login...", "success");

            setTimeout(() => {
                window.location.href = "login.html";
            }, 1000);
            return;
        }

        // If MySQL API is unreachable (e.g. running on file:// or server not started), use local storage fallback
        if (apiRes && (apiRes.isLocalFile || apiRes.networkError)) {
            const users = getUsers();
            const emailExists = users.some(u => u.email.toLowerCase() === email);

            if (emailExists) {
                showToast("Registration Failed", "This email address is already registered.", "error");
                return;
            }

            const localUser = {
                name: fullName,
                firstName: firstName,
                lastName: lastName,
                email: email,
                gender: gender,
                password: password,
                role: "member",
                genre: "Sci-Fi & Fantasy",
                avatar: "1"
            };

            users.push(localUser);
            saveUsers(users);

            showToast("Success", "Account created successfully! Redirecting to login...", "success");

            setTimeout(() => {
                window.location.href = "login.html";
            }, 1000);
            return;
        }

        // Display error message returned from MySQL API
        const errorMsg = (apiRes && apiRes.error) ? apiRes.error : "Registration failed. Please try again.";
        showToast("Registration Error", errorMsg, "error");
    });
});
