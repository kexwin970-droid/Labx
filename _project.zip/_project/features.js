/* ==========================================================================
   Aetheria Library — Feature Module
   Wishlist · Book Details · Online Reader · Reviews & Ratings · Admin Panel
   Loads after app.js and reuses its global `state` object.
   All new data is persisted in localStorage.
   ========================================================================== */

/* -------------------- Storage helpers -------------------- */
const LS = {
    reviews: "aetheria_reviews",
    reading: "aetheria_reading",
    wishlistPrefix: "aetheria_wishlist_",
    booksOverride: "aetheria_books" // admin-managed catalog overrides
};

function lsGet(key, fallback) {
    try {
        const raw = localStorage.getItem(key);
        return raw ? JSON.parse(raw) : fallback;
    } catch (e) {
        return fallback;
    }
}
function lsSet(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) {}
}

function currentEmail() {
    return state.activeUser ? state.activeUser.email : "guest";
}
function isAdminUser() {
    return !!(state.activeUser && state.activeUser.role === "admin");
}

function escapeHtml(str) {
    return String(str == null ? "" : str)
        .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

function findBook(id) {
    return state.books.find(b => b.id === Number(id));
}

/* -------------------- Reviews store -------------------- */
function getReviews() { return lsGet(LS.reviews, []); }
function saveReviews(arr) { lsSet(LS.reviews, arr); }
function getBookReviews(bookId) {
    return getReviews().filter(r => Number(r.bookId) === Number(bookId));
}
function getAverageRating(bookId, fallback) {
    const revs = getBookReviews(bookId);
    if (!revs.length) return fallback;
    const sum = revs.reduce((a, r) => a + Number(r.rating), 0);
    return sum / revs.length;
}

/* -------------------- Reading records store -------------------- */
function getReadingRecords() { return lsGet(LS.reading, []); }
function saveReadingRecords(arr) { lsSet(LS.reading, arr); }
function recordReading(bookId) {
    if (!state.activeUser) return;
    const records = getReadingRecords();
    const now = new Date().toISOString();
    const existing = records.find(r =>
        r.userEmail === currentEmail() && Number(r.bookId) === Number(bookId));
    if (existing) {
        existing.lastAccessed = now;
        existing.opens = (existing.opens || 1) + 1;
    } else {
        records.push({
            userEmail: currentEmail(),
            userName: state.activeUser.name,
            bookId: Number(bookId),
            firstAccessed: now,
            lastAccessed: now,
            opens: 1
        });
    }
    saveReadingRecords(records);
}

/* -------------------- Wishlist store -------------------- */
function getWishlist() { return lsGet(LS.wishlistPrefix + currentEmail(), []); }
function saveWishlist(arr) { lsSet(LS.wishlistPrefix + currentEmail(), arr); }
function isInWishlist(bookId) { return getWishlist().includes(Number(bookId)); }

function toggleWishlist(bookId) {
    bookId = Number(bookId);
    let list = getWishlist();
    const book = findBook(bookId);
    if (list.includes(bookId)) {
        list = list.filter(id => id !== bookId);
        saveWishlist(list);
        showToast("Removed", `"${book ? book.title : 'Book'}" removed from your Wishlist.`, "info");
    } else {
        list.push(bookId);
        saveWishlist(list);
        showToast("Wishlisted", `"${book ? book.title : 'Book'}" saved to your Wishlist.`, "success");
    }
    // Refresh whichever views are visible
    if (!document.getElementById("browse-tab").classList.contains("hidden")) renderCatalog();
    if (!document.getElementById("wishlist-tab").classList.contains("hidden")) renderWishlist();
    refreshDetailsWishlistBtn(bookId);
}

/* -------------------- Book card builder (shared) -------------------- */
function bookCardHTML(book, opts) {
    opts = opts || {};
    const inWishlist = isInWishlist(book.id);
    const avg = getAverageRating(book.id, book.rating);
    const ratingStars = Math.floor(avg);
    const starsHTML = '<i class="fa-solid fa-star"></i>'.repeat(ratingStars) +
        (avg % 1 >= 0.5 ? '<i class="fa-solid fa-star-half-stroke"></i>' : '');

    const wishBtn = opts.wishlistPage
        ? `<button class="wishlist-toggle active" onclick="event.stopPropagation(); toggleWishlist(${book.id})" title="Remove from Wishlist">
               <i class="fa-solid fa-heart"></i>
           </button>`
        : `<button class="wishlist-toggle ${inWishlist ? 'active' : ''}" onclick="event.stopPropagation(); toggleWishlist(${book.id})" title="${inWishlist ? 'Remove from Wishlist' : 'Add to Wishlist'}">
               <i class="fa-${inWishlist ? 'solid' : 'regular'} fa-heart"></i>
           </button>`;

    return `
        <div class="book-card glass-panel fade-in">
            <div class="book-cover-container clickable" onclick="openBookDetails(${book.id})" title="View details">
                <div class="book-cover-bg" style="background: ${book.bgGradient};"></div>
                <div class="book-cover-jacket" style="background: ${book.bgGradient};">
                    <div class="spine-fold"></div>
                    <div class="jacket-header">Aetheria Shelf</div>
                    <div class="jacket-title" style="color: ${book.headerColor || 'white'};">${escapeHtml(book.title)}</div>
                    <div class="jacket-author">${escapeHtml(book.author)}</div>
                </div>
            </div>
            <div class="book-details">
                <span class="book-genre">${escapeHtml(book.genre)}</span>
                <h4 class="book-title clickable" onclick="openBookDetails(${book.id})">${escapeHtml(book.title)}</h4>
                <p class="book-author">By ${escapeHtml(book.author)}</p>
                <p class="book-description">${escapeHtml(book.description)}</p>
                <div class="book-card-footer">
                    <div class="book-rating">${starsHTML}<span>${avg.toFixed(1)}</span></div>
                    <div class="book-card-actions">
                        ${wishBtn}
                        <button class="btn btn-primary btn-sm" onclick="event.stopPropagation(); startReading(${book.id})" title="Read this book">
                            <i class="fa-solid fa-book-open"></i> Read
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
}

/* -------------------- Wishlist view -------------------- */
function renderWishlist() {
    const grid = document.getElementById("wishlist-grid");
    if (!grid) return;
    const ids = getWishlist();
    const books = ids.map(findBook).filter(Boolean);

    if (!books.length) {
        grid.innerHTML = `
            <div class="empty-state" style="grid-column: 1 / -1;">
                <i class="fa-regular fa-heart"></i>
                <h4>Your Wishlist is Empty</h4>
                <p>Tap the heart on any book to save it here for later.</p>
                <button class="btn btn-secondary btn-sm" onclick="handleTabSwitch('browse')">Browse the Bookshelf</button>
            </div>`;
        return;
    }
    grid.innerHTML = books.map(b => bookCardHTML(b, { wishlistPage: true })).join('');
}

/* -------------------- Overlay helpers -------------------- */
function openOverlay(html) {
    const ov = document.getElementById("view-overlay");
    ov.innerHTML = html;
    ov.classList.remove("hidden");
    ov.scrollTop = 0;
    document.body.style.overflow = "hidden";
}
function closeOverlay() {
    const ov = document.getElementById("view-overlay");
    ov.classList.add("hidden");
    ov.innerHTML = "";
    document.body.style.overflow = "";
}

/* -------------------- Book Details view -------------------- */
function openBookDetails(bookId) {
    const book = findBook(bookId);
    if (!book) return;
    const avg = getAverageRating(book.id, book.rating);
    const ratingStars = Math.floor(avg);
    const starsHTML = '<i class="fa-solid fa-star"></i>'.repeat(ratingStars) +
        (avg % 1 >= 0.5 ? '<i class="fa-solid fa-star-half-stroke"></i>' : '');
    const inWishlist = isInWishlist(book.id);

    openOverlay(`
        <div class="view-topbar">
            <button class="view-back-btn" onclick="closeOverlay()"><i class="fa-solid fa-arrow-left"></i> Back to Bookshelf</button>
            <h2>Book Details</h2>
            <span style="width:150px"></span>
        </div>
        <div class="view-body">
            <div class="details-hero">
                <div class="details-cover" style="background:${book.bgGradient}; color:${book.headerColor || '#fff'}">
                    <div class="spine-fold"></div>
                    <h2>${escapeHtml(book.title)}</h2>
                    <span>${escapeHtml(book.author)}</span>
                </div>
                <div class="details-info">
                    <span class="details-genre-chip">${escapeHtml(book.genre)}</span>
                    <h1>${escapeHtml(book.title)}</h1>
                    <p class="details-author">by ${escapeHtml(book.author)}</p>
                    <div class="details-rating-row">
                        ${starsHTML}
                        <span>${avg.toFixed(1)}</span>
                        <span class="rating-count">(${getBookReviews(book.id).length} review${getBookReviews(book.id).length === 1 ? '' : 's'})</span>
                    </div>
                    <p class="details-desc">${escapeHtml(book.description)}</p>
                    <div class="details-actions">
                        <button class="btn btn-primary" onclick="startReading(${book.id})">
                            <i class="fa-solid fa-book-open"></i> Proceed to Read
                        </button>
                        <button id="details-wishlist-btn" class="btn btn-secondary" onclick="toggleWishlist(${book.id})">
                            <i class="fa-${inWishlist ? 'solid' : 'regular'} fa-heart"></i>
                            <span>${inWishlist ? 'In Wishlist' : 'Add to Wishlist'}</span>
                        </button>
                    </div>
                </div>
            </div>

            <div class="reviews-section">
                <h3><i class="fa-solid fa-star-half-stroke text-primary"></i> Ratings &amp; Reviews</h3>
                <div id="details-reviews-list">${reviewsListHTML(book.id)}</div>
            </div>
        </div>
    `);
}

function refreshDetailsWishlistBtn(bookId) {
    const btn = document.getElementById("details-wishlist-btn");
    if (!btn) return;
    const inWishlist = isInWishlist(bookId);
    btn.innerHTML = `<i class="fa-${inWishlist ? 'solid' : 'regular'} fa-heart"></i><span>${inWishlist ? 'In Wishlist' : 'Add to Wishlist'}</span>`;
}

function reviewsListHTML(bookId) {
    const revs = getBookReviews(bookId).slice().reverse();
    if (!revs.length) {
        return `<p class="reviews-empty">No reviews yet. Be the first to review this book after reading it!</p>`;
    }
    return revs.map(r => {
        const stars = '<i class="fa-solid fa-star"></i>'.repeat(Number(r.rating)) +
            '<i class="fa-regular fa-star"></i>'.repeat(5 - Number(r.rating));
        return `
            <div class="review-item">
                <div class="review-item-head">
                    <span class="review-author"><i class="fa-solid fa-user-circle"></i> ${escapeHtml(r.userName)}</span>
                    <span class="review-date">${formatDate(r.date)}</span>
                </div>
                <div class="review-stars">${stars}</div>
                ${r.text ? `<p class="review-text">${escapeHtml(r.text)}</p>` : ''}
            </div>`;
    }).join('');
}

/* -------------------- Online Reader view -------------------- */
function generateChapters(book) {
    // Deterministic sample chapter text derived from the book's own metadata.
    const fillers = [
        `The story of ${book.title} unfolds slowly, drawing the reader into a world shaped by ${book.author}'s unmistakable voice. Every page turns with a quiet insistence, as if the book itself knows where it is taking you.`,
        `${book.description}`,
        `Here, in the heart of the ${book.genre.toLowerCase()} tradition, themes of ambition, doubt, and discovery weave together. Characters step forward, hesitate, and press on — and the reader follows, chapter after chapter.`,
        `Time seems to bend within these pages. What begins as a single thread of narrative widens into a tapestry, and by the closing lines you may find that the tale has quietly rearranged the way you see the world.`,
        `This digital edition is presented by Aetheria Library for your reading pleasure. Take your time, wander the paragraphs, and when you have reached the final word, we would love to hear what you thought.`
    ];
    let html = "";
    for (let i = 1; i <= 3; i++) {
        html += `<div class="reader-chapter">
            <h3>Chapter ${i}</h3>
            <p>${escapeHtml(fillers[(i - 1) % fillers.length])}</p>
            <p>${escapeHtml(fillers[(i + 1) % fillers.length])}</p>
            <p>${escapeHtml(fillers[(i + 3) % fillers.length])}</p>
        </div>`;
    }
    return html;
}

function startReading(bookId) {
    const book = findBook(bookId);
    if (!book) return;
    recordReading(book.id);

    openOverlay(`
        <div class="view-topbar">
            <button class="view-back-btn" onclick="closeOverlay()"><i class="fa-solid fa-arrow-left"></i> Close Reader</button>
            <h2><i class="fa-solid fa-book-open"></i> Reading</h2>
            <button class="view-back-btn" onclick="openBookDetails(${book.id})"><i class="fa-solid fa-circle-info"></i> Details</button>
        </div>
        <div class="reader-body">
            <h1 class="reader-title">${escapeHtml(book.title)}</h1>
            <p class="reader-author">by ${escapeHtml(book.author)}</p>
            ${generateChapters(book)}
            <div class="reader-finish-bar">
                <p><i class="fa-solid fa-flag-checkered"></i> You've reached the end of this edition.</p>
                <div id="review-mount">${reviewFormHTML(book.id)}</div>
            </div>
        </div>
    `);
    showToast("Enjoy Reading", `"${book.title}" is now open. Happy reading!`, "success");
}

/* -------------------- Reviews & Ratings submit -------------------- */
function reviewFormHTML(bookId) {
    return `
        <div class="review-form">
            <h4><i class="fa-solid fa-pen-nib"></i> Rate &amp; Review this book</h4>
            <label class="form-label">Your rating</label>
            <div class="star-input">
                <input type="radio" name="rev-star" id="rs5" value="5"><label for="rs5" title="5 stars"><i class="fa-solid fa-star"></i></label>
                <input type="radio" name="rev-star" id="rs4" value="4"><label for="rs4" title="4 stars"><i class="fa-solid fa-star"></i></label>
                <input type="radio" name="rev-star" id="rs3" value="3"><label for="rs3" title="3 stars"><i class="fa-solid fa-star"></i></label>
                <input type="radio" name="rev-star" id="rs2" value="2"><label for="rs2" title="2 stars"><i class="fa-solid fa-star"></i></label>
                <input type="radio" name="rev-star" id="rs1" value="1"><label for="rs1" title="1 star"><i class="fa-solid fa-star"></i></label>
            </div>
            <label class="form-label" for="rev-text">Your review (optional)</label>
            <textarea id="rev-text" placeholder="Share your thoughts about this book..."></textarea>
            <button class="btn btn-primary" onclick="submitReview(${bookId})">
                <i class="fa-solid fa-paper-plane"></i> Submit Review
            </button>
        </div>`;
}

function submitReview(bookId) {
    if (!state.activeUser) return;
    const checked = document.querySelector('input[name="rev-star"]:checked');
    if (!checked) {
        showToast("Rating Required", "Please select a star rating before submitting.", "warning");
        return;
    }
    const text = (document.getElementById("rev-text") || {}).value || "";
    const reviews = getReviews();
    reviews.push({
        id: Date.now() + Math.random(),
        bookId: Number(bookId),
        userEmail: currentEmail(),
        userName: state.activeUser.name,
        rating: Number(checked.value),
        text: text.trim(),
        date: new Date().toISOString()
    });
    saveReviews(reviews);
    showToast("Review Submitted", "Thank you for sharing your feedback!", "success");

    // Sync review to MySQL via PHP API
    callApi('reviews.php?action=add', {
        method: 'POST',
        body: JSON.stringify({
            user_email: currentEmail(),
            book_id: Number(bookId),
            user_name: state.activeUser.name,
            rating: Number(checked.value),
            text: text.trim()
        })
    }).catch(e => console.warn("Review submission MySQL sync notice:", e));

    const mount = document.getElementById("review-mount");
    if (mount) {
        mount.innerHTML = `<p style="color: var(--success);"><i class="fa-solid fa-circle-check"></i> Your review has been posted. Thank you!</p>`;
    }
}

/* -------------------- Admin Panel -------------------- */
function renderAdminPanel() {
    const mount = document.getElementById("admin-content");
    if (!mount) return;

    const reading = getReadingRecords();
    const reviews = getReviews();
    const users = state.users.filter(u => u.role !== "admin");

    const statCards = `
        <div class="admin-stat-cards">
            <div class="admin-stat-card glass-panel"><span class="num">${state.books.length}</span><span class="lbl">Books in Library</span></div>
            <div class="admin-stat-card glass-panel"><span class="num">${users.length}</span><span class="lbl">Registered Users</span></div>
            <div class="admin-stat-card glass-panel"><span class="num">${reading.length}</span><span class="lbl">Reading Records</span></div>
            <div class="admin-stat-card glass-panel"><span class="num">${reviews.length}</span><span class="lbl">Total Reviews</span></div>
        </div>`;

    // Reading activity table
    const readingRows = reading.length
        ? reading.slice().sort((a, b) => new Date(b.lastAccessed) - new Date(a.lastAccessed)).map(r => {
            const book = findBook(r.bookId);
            return `<tr>
                <td>${escapeHtml(r.userName)}</td>
                <td>${escapeHtml(r.userEmail)}</td>
                <td>${book ? escapeHtml(book.title) : 'Removed book'}</td>
                <td>${r.opens || 1}</td>
                <td>${formatDate(r.lastAccessed)}</td>
            </tr>`;
        }).join('')
        : `<tr><td colspan="5" style="text-align:center;color:var(--text-muted);padding:20px;">No reading activity yet.</td></tr>`;

    // Reviews table
    const reviewRows = reviews.length
        ? reviews.slice().reverse().map(rv => {
            const book = findBook(rv.bookId);
            return `<tr>
                <td>${escapeHtml(rv.userName)}</td>
                <td>${book ? escapeHtml(book.title) : 'Removed book'}</td>
                <td>${'★'.repeat(Number(rv.rating))}${'☆'.repeat(5 - Number(rv.rating))}</td>
                <td>${escapeHtml(rv.text) || '<span style="color:var(--text-muted)">—</span>'}</td>
                <td>${formatDate(rv.date)}</td>
            </tr>`;
        }).join('')
        : `<tr><td colspan="5" style="text-align:center;color:var(--text-muted);padding:20px;">No reviews submitted yet.</td></tr>`;

    // Manage books table
    const genreOptions = ["Fiction", "Sci-Fi & Fantasy", "Technology & Science",
        "History & Biography", "Mystery & Thriller", "Philosophy & Psychology"];
    const bookRows = state.books.slice().sort((a, b) => a.id - b.id).map(b => `
        <tr>
            <td>${b.id}</td>
            <td>${escapeHtml(b.title)}</td>
            <td>${escapeHtml(b.author)}</td>
            <td>${escapeHtml(b.genre)}</td>
            <td><button class="admin-book-remove" onclick="adminRemoveBook(${b.id})" title="Remove book">
                <i class="fa-solid fa-trash-can"></i></button></td>
        </tr>`).join('');

    mount.innerHTML = `
        ${statCards}

        <div class="admin-section glass-panel">
            <h3><i class="fa-solid fa-plus text-primary"></i> Add a New Book</h3>
            <div class="admin-form-grid">
                <input id="adm-title" type="text" placeholder="Book title" />
                <input id="adm-author" type="text" placeholder="Author" />
                <select id="adm-genre">${genreOptions.map(g => `<option value="${g}">${g}</option>`).join('')}</select>
                <input id="adm-rating" type="number" min="1" max="5" step="0.1" placeholder="Rating (1-5)" />
                <textarea id="adm-desc" class="full" placeholder="Short description"></textarea>
                <div class="full">
                    <button class="btn btn-primary" onclick="adminAddBook()"><i class="fa-solid fa-check"></i> Add Book to Library</button>
                </div>
            </div>
        </div>

        <div class="admin-section glass-panel">
            <h3><i class="fa-solid fa-book text-primary"></i> Manage Books (${state.books.length})</h3>
            <div class="admin-table-wrapper">
                <table class="admin-table">
                    <thead><tr><th>ID</th><th>Title</th><th>Author</th><th>Genre</th><th>Remove</th></tr></thead>
                    <tbody>${bookRows}</tbody>
                </table>
            </div>
        </div>

        <div class="admin-section glass-panel">
            <h3><i class="fa-solid fa-eye text-primary"></i> User Reading Activity</h3>
            <div class="admin-table-wrapper">
                <table class="admin-table">
                    <thead><tr><th>User</th><th>Email</th><th>Book</th><th>Opens</th><th>Last Accessed</th></tr></thead>
                    <tbody>${readingRows}</tbody>
                </table>
            </div>
        </div>

        <div class="admin-section glass-panel">
            <h3><i class="fa-solid fa-comments text-primary"></i> Ratings &amp; Reviews</h3>
            <div class="admin-table-wrapper">
                <table class="admin-table">
                    <thead><tr><th>User</th><th>Book</th><th>Rating</th><th>Review</th><th>Date</th></tr></thead>
                    <tbody>${reviewRows}</tbody>
                </table>
            </div>
        </div>
    `;
}

function persistBooks() {
    // Store admin-modified catalog so changes survive refresh.
    lsSet(LS.booksOverride, state.books);
}

function adminAddBook() {
    const title = document.getElementById("adm-title").value.trim();
    const author = document.getElementById("adm-author").value.trim();
    const genre = document.getElementById("adm-genre").value;
    const desc = document.getElementById("adm-desc").value.trim();
    let rating = parseFloat(document.getElementById("adm-rating").value);

    if (!title || !author || !desc) {
        showToast("Missing Fields", "Please provide a title, author and description.", "warning");
        return;
    }
    if (isNaN(rating) || rating < 1 || rating > 5) rating = 4.0;

    const gradients = [
        "linear-gradient(135deg, #c27d38, #5e3a15)",
        "linear-gradient(135deg, #0f172a, #06b6d4)",
        "linear-gradient(135deg, #3730a3, #4338ca)",
        "linear-gradient(135deg, #065f46, #059669)",
        "linear-gradient(135deg, #7f1d1d, #ef4444)"
    ];
    const newId = state.books.reduce((m, b) => Math.max(m, b.id), 0) + 1;
    state.books.push({
        id: newId,
        title, author, genre,
        description: desc,
        rating: Math.round(rating * 10) / 10,
        available: true,
        bgGradient: gradients[newId % gradients.length],
        headerColor: "#f3f4f6"
    });
    persistBooks();
    updateBannerStatistics();
    renderAdminPanel();
    showToast("Book Added", `"${title}" is now in the library.`, "success");
}

function adminRemoveBook(bookId) {
    const book = findBook(bookId);
    state.books = state.books.filter(b => b.id !== Number(bookId));
    persistBooks();
    updateBannerStatistics();
    renderAdminPanel();
    showToast("Book Removed", `"${book ? book.title : 'Book'}" removed from the library.`, "info");
}

/* -------------------- Initialisation -------------------- */
document.addEventListener("DOMContentLoaded", () => {
    // Only run on the dashboard page
    if (!document.getElementById("app-section")) return;

    // Apply any admin-modified catalog saved previously
    const overrideBooks = lsGet(LS.booksOverride, null);
    if (overrideBooks && Array.isArray(overrideBooks) && overrideBooks.length) {
        state.books = overrideBooks;
        if (typeof updateBannerStatistics === "function") updateBannerStatistics();
        // The browse tab was already rendered by app.js with the default set — refresh it.
        if (typeof renderCatalog === "function") renderCatalog();
    }

    // Connect Admin Panel buttons with smart authentication routing
    const adminBtn = document.getElementById("admin-tab-btn");
    if (adminBtn) {
        adminBtn.classList.remove("hidden");
        adminBtn.addEventListener("click", (e) => {
            e.preventDefault();
            if (isAdminUser()) {
                window.location.href = "admin.html";
            } else {
                window.location.href = "admin/login.html";
            }
        });
    }
    const adminHdrBtn = document.getElementById("admin-header-btn");
    if (adminHdrBtn) {
        adminHdrBtn.classList.remove("hidden");
        adminHdrBtn.addEventListener("click", (e) => {
            e.preventDefault();
            if (isAdminUser()) {
                window.location.href = "admin.html";
            } else {
                window.location.href = "admin/login.html";
            }
        });
    }

    // Close overlay with the Escape key
    document.addEventListener("keydown", (e) => {
        if (e.key === "Escape") {
            const ov = document.getElementById("view-overlay");
            if (ov && !ov.classList.contains("hidden")) closeOverlay();
        }
    });
});
