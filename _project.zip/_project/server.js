/* ==========================================================================
   Aetheria Library — Localhost Full-Stack Application Server
   Connects frontend with MySQL Database, REST APIs, and Static Asset Engine.
   Supports both Node.js environment and LAMP/XAMPP PHP API compatibility.
   ========================================================================== */

const express = require('express');
const cors = require('cors');
const path = require('path');
const config = require('./backend/config');
const { initDatabase, getDatabaseStatus } = require('./backend/db');

// Route modules
const authRoutes = require('./backend/routes/auth');
const usersRoutes = require('./backend/routes/users');
const booksRoutes = require('./backend/routes/books');
const loansRoutes = require('./backend/routes/loans');
const reviewsRoutes = require('./backend/routes/reviews');
const wishlistRoutes = require('./backend/routes/wishlist');
const readingRoutes = require('./backend/routes/reading');
const adminRoutes = require('./backend/routes/admin');

const app = express();
const PORT = process.env.PORT || config.port || 3000;

// ==========================================================================
// 1. Core Middleware
// ==========================================================================
app.use(cors({
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Request logging in development
app.use((req, res, next) => {
    if (req.path.startsWith('/api')) {
        console.log(`[API ${req.method}] ${req.path}`);
    }
    next();
});

// ==========================================================================
// 2. REST API Routes
// ==========================================================================
app.use('/api/auth', authRoutes);
app.use('/api/users', usersRoutes);
app.use('/api/books', booksRoutes);
app.use('/api/loans', loansRoutes);
app.use('/api/reviews', reviewsRoutes);
app.use('/api/wishlist', wishlistRoutes);
app.use('/api/reading', readingRoutes);
app.use('/api/admin', adminRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({
        success: true,
        status: 'online',
        database: getDatabaseStatus(),
        timestamp: new Date().toISOString()
    });
});

// ==========================================================================
// 3. PHP-Style Endpoint Bridges (For LAMP compatibility when served by Node)
// ==========================================================================
app.use('/api/auth.php', (req, res, next) => {
    const action = req.query.action || req.body?.action;
    if (action === 'login' || (!action && req.method === 'POST' && req.body?.email && !req.body?.name)) {
        req.url = '/login';
    } else if (action === 'register' || action === 'signup') {
        req.url = '/register';
    } else if (action === 'me') {
        req.url = '/me';
    } else if (action === 'logout') {
        req.url = '/logout';
    } else if (action === 'profile') {
        req.url = '/profile';
    } else if (action === 'reset_password') {
        req.url = '/reset-password';
    } else {
        req.url = '/';
    }
    authRoutes(req, res, next);
});

app.use('/api/books.php', (req, res, next) => {
    booksRoutes(req, res, next);
});

app.use('/api/admin.php', (req, res, next) => {
    const action = req.query.action || req.body?.action;
    if (action === 'dashboard' || action === 'stats') {
        req.url = '/dashboard';
    } else if (action === 'logs' || action === 'activity_logs') {
        req.url = '/activity-logs';
    } else {
        req.url = '/dashboard';
    }
    adminRoutes(req, res, next);
});

app.use('/api/loans.php', (req, res, next) => {
    loansRoutes(req, res, next);
});

// ==========================================================================
// 4. Static Frontend Delivery
// ==========================================================================
app.use(express.static(path.join(__dirname)));

// Root landing page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Legacy redirect for admin login
app.get(['/admin/login.html', '/admin/login'], (req, res) => {
    res.redirect('/admin_login.html');
});

// 404 handler for API routes
app.use('/api', (req, res) => {
    res.status(404).json({ success: false, message: `Endpoint not found: ${req.method} ${req.originalUrl}` });
});

// Global error handler
app.use((err, req, res, next) => {
    console.error(`[Server Error] ${err.message}`, err.stack);
    const status = err.status || 500;
    res.status(status).json({
        success: false,
        message: err.message || 'An unexpected internal server error occurred.'
    });
});

// ==========================================================================
// 5. Server Startup & Database Connection
// ==========================================================================
async function startServer() {
    try {
        console.log('--------------------------------------------------------------------');
        console.log('Initializing Aetheria Library Localhost System...');
        
        // Initialize MySQL Database connection and schema migrations
        await initDatabase();

        app.listen(PORT, () => {
            const dbStatus = getDatabaseStatus();
            console.log('====================================================================');
            console.log(`🚀 Aetheria Library running at: http://localhost:${PORT}`);
            console.log(`📂 Database Engine: ${dbStatus.mode.toUpperCase()} (Connected to ${dbStatus.database})`);
            console.log(`🔑 Predefined Accounts (Stored in SQL):`);
            console.log(`   • Member Account: demo@example.com / Demo@123`);
            console.log(`   • Admin Account:  admin@example.com / Admin@123`);
            console.log(`🌐 Accessible Pages:`);
            console.log(`   • Catalog & Home:   http://localhost:${PORT}/home.html`);
            console.log(`   • Member Sign In:   http://localhost:${PORT}/login.html`);
            console.log(`   • Member Register:  http://localhost:${PORT}/signup.html`);
            console.log(`   • Admin Console:    http://localhost:${PORT}/admin.html`);
            console.log(`   • Admin Login:      http://localhost:${PORT}/admin_login.html`);
            console.log('====================================================================');
        });
    } catch (err) {
        console.error('Failed to initialize server:', err);
        process.exit(1);
    }
}

startServer();
