<?php
/**
 * =============================================================================
 * Aetheria Library — Circulation & Loans API Controller
 * Handles borrowing, returns, and circulation monitoring in MySQL.
 * Foreign Key: user_email references users(email)
 * =============================================================================
 */

require_once __DIR__ . '/db.php';

$pdo = getDB();
$data = getRequestData();
$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? $_GET['action'] : (isset($data['action']) ? $data['action'] : '');

// Handle HTTP GET (List loans)
if ($method === 'GET' && empty($action)) {
    $userEmail = trim(isset($_GET['user_email']) ? $_GET['user_email'] : '');
    $status = trim(isset($_GET['status']) ? $_GET['status'] : 'all');

    try {
        $sql = "
            SELECT l.`id`, l.`user_email` AS `userId`, l.`book_id` AS `bookId`,
                   l.`borrow_date` AS `borrowDate`, l.`due_date` AS `dueDate`,
                   l.`return_date` AS `returnDate`, l.`status`,
                   b.`title` AS `bookTitle`, b.`author` AS `bookAuthor`, b.`genre` AS `bookGenre`,
                   u.`name` AS `userName`
            FROM `loans` l
            LEFT JOIN `books` b ON l.`book_id` = b.`id`
            LEFT JOIN `users` u ON l.`user_email` = u.`email`
            WHERE 1=1
        ";
        $params = [];

        if (!empty($userEmail)) {
            $sql .= " AND l.`user_email` = ?";
            $params[] = $userEmail;
        }

        if ($status !== 'all') {
            $sql .= " AND l.`status` = ?";
            $params[] = $status;
        }

        $sql .= " ORDER BY l.`borrow_date` DESC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $loans = $stmt->fetchAll();

        jsonResponse(true, $loans);
    } catch (PDOException $e) {
        jsonResponse(false, "Database query error: " . $e->getMessage(), 500);
    }
}

// Handle Actions (POST / PUT / DELETE)
switch ($action) {
    // -------------------------------------------------------------------------
    // 1. Borrow Book(s) (Member)
    // -------------------------------------------------------------------------
    case 'borrow':
        $userEmail = trim(strtolower(isset($data['user_email']) ? $data['user_email'] : (isset($data['userId']) ? $data['userId'] : '')));
        $bookIds = isset($data['book_ids']) ? $data['book_ids'] : (isset($data['bookId']) ? [$data['bookId']] : []);
        $durationDays = isset($data['duration_days']) ? (int)$data['duration_days'] : 14;

        if (empty($userEmail)) {
            jsonResponse(false, "User email is required to borrow books.", 400);
        }

        if (empty($bookIds) || !is_array($bookIds)) {
            jsonResponse(false, "At least one book ID must be specified.", 400);
        }

        try {
            // Verify user exists by email (PRIMARY KEY)
            $userCheck = $pdo->prepare("SELECT `email`, `name` FROM `users` WHERE `email` = ? LIMIT 1");
            $userCheck->execute([$userEmail]);
            $user = $userCheck->fetch();

            if (!$user) {
                jsonResponse(false, "Account not found for email: {$userEmail}", 404);
            }

            $createdLoans = [];
            $borrowDate = date('Y-m-d H:i:s');
            $dueDate = date('Y-m-d H:i:s', strtotime("+{$durationDays} days"));

            $loanStmt = $pdo->prepare("
                INSERT INTO `loans` (`user_email`, `book_id`, `borrow_date`, `due_date`, `status`)
                VALUES (?, ?, ?, ?, 'active-borrow')
            ");

            $bookUpdateStmt = $pdo->prepare("UPDATE `books` SET `available` = 0 WHERE `id` = ?");
            $readingLogStmt = $pdo->prepare("
                INSERT INTO `reading_logs` (`user_email`, `book_id`, `book_title`, `started_at`, `status`)
                VALUES (?, ?, ?, NOW(), 'reading')
            ");

            $bookTitleStmt = $pdo->prepare("SELECT `title` FROM `books` WHERE `id` = ?");

            foreach ($bookIds as $bId) {
                $bId = (int)$bId;
                $loanStmt->execute([$userEmail, $bId, $borrowDate, $dueDate]);
                $newLoanId = (int)$pdo->lastInsertId();

                $bookUpdateStmt->execute([$bId]);

                $bookTitleStmt->execute([$bId]);
                $titleRow = $bookTitleStmt->fetch();
                $bTitle = $titleRow ? $titleRow['title'] : "Book #{$bId}";

                $readingLogStmt->execute([$userEmail, $bId, $bTitle]);

                $createdLoans[] = [
                    'id' => $newLoanId,
                    'userId' => $userEmail,
                    'bookId' => $bId,
                    'bookTitle' => $bTitle,
                    'borrowDate' => $borrowDate,
                    'dueDate' => $dueDate,
                    'status' => 'active-borrow'
                ];
            }

            jsonResponse(true, [
                'loans' => $createdLoans,
                'message' => "Successfully borrowed " . count($createdLoans) . " book(s) in MySQL."
            ], 201);
        } catch (PDOException $e) {
            jsonResponse(false, "Borrow transaction failed: " . $e->getMessage(), 500);
        }
        break;

    // -------------------------------------------------------------------------
    // 2. Return Borrowed Book (Member or Admin)
    // -------------------------------------------------------------------------
    case 'return':
        $loanId = isset($data['loan_id']) ? (int)$data['loan_id'] : (isset($data['id']) ? (int)$data['id'] : 0);
        $bookId = isset($data['book_id']) ? (int)$data['book_id'] : (isset($data['bookId']) ? (int)$data['bookId'] : 0);
        $userEmail = trim(strtolower(isset($data['user_email']) ? $data['user_email'] : ''));

        try {
            if ($loanId > 0) {
                // Return by Loan ID
                $fetch = $pdo->prepare("SELECT * FROM `loans` WHERE `id` = ? LIMIT 1");
                $fetch->execute([$loanId]);
                $loan = $fetch->fetch();

                if (!$loan) jsonResponse(false, "Loan record #{$loanId} not found.", 404);

                $update = $pdo->prepare("UPDATE `loans` SET `status` = 'returned', `return_date` = NOW() WHERE `id` = ?");
                $update->execute([$loanId]);

                $pdo->prepare("UPDATE `books` SET `available` = 1 WHERE `id` = ?")->execute([$loan['book_id']]);

                jsonResponse(true, "Book returned successfully in MySQL.");
            } elseif ($bookId > 0 && !empty($userEmail)) {
                // Return by user email and book ID
                $update = $pdo->prepare("
                    UPDATE `loans` 
                    SET `status` = 'returned', `return_date` = NOW() 
                    WHERE `user_email` = ? AND `book_id` = ? AND `status` = 'active-borrow'
                ");
                $update->execute([$userEmail, $bookId]);

                $pdo->prepare("UPDATE `books` SET `available` = 1 WHERE `id` = ?")->execute([$bookId]);

                jsonResponse(true, "Book returned successfully in MySQL.");
            } else {
                jsonResponse(false, "Loan ID or (Book ID and User Email) required.", 400);
            }
        } catch (PDOException $e) {
            jsonResponse(false, "Return operation failed: " . $e->getMessage(), 500);
        }
        break;

    // -------------------------------------------------------------------------
    // 3. Delete Loan Record (Admin)
    // -------------------------------------------------------------------------
    case 'delete':
        $loanId = isset($data['loan_id']) ? (int)$data['loan_id'] : (isset($_GET['id']) ? (int)$_GET['id'] : 0);

        if (!$loanId) {
            jsonResponse(false, "Loan ID is required to delete record.", 400);
        }

        try {
            $stmt = $pdo->prepare("DELETE FROM `loans` WHERE `id` = ?");
            $stmt->execute([$loanId]);

            jsonResponse(true, "Loan record #{$loanId} removed from MySQL.");
        } catch (PDOException $e) {
            jsonResponse(false, "Delete loan failed: " . $e->getMessage(), 500);
        }
        break;

    default:
        jsonResponse(false, "Invalid loans action specified.", 400);
}
