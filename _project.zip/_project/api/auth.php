<?php
/**
 * =============================================================================
 * Aetheria Library — Authentication API Controller
 * Handles user sign in, registration, and password reset via MySQL.
 * Email is used as the PRIMARY KEY in the users table.
 * =============================================================================
 */

require_once __DIR__ . '/db.php';

$pdo = getDB();
$data = getRequestData();
$action = isset($_GET['action']) ? $_GET['action'] : (isset($data['action']) ? $data['action'] : '');

switch ($action) {
    // -------------------------------------------------------------------------
    // 1. Sign In / Login
    // -------------------------------------------------------------------------
    case 'login':
        $email = trim(strtolower(isset($data['email']) ? $data['email'] : ''));
        $password = isset($data['password']) ? $data['password'] : '';

        if (empty($email) || empty($password)) {
            jsonResponse(false, "Please provide both email address and password.", 400);
        }

        try {
            // Email is the PRIMARY KEY in the users table
            $stmt = $pdo->prepare("SELECT * FROM `users` WHERE `email` = ? LIMIT 1");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if (!$user) {
                jsonResponse(false, "No registered account found with this email address.", 404);
            }

            // Verify password (plain match for seed accounts or password_verify)
            $passwordMatches = ($user['password'] === $password) || 
                               (password_get_info($user['password'])['algo'] !== 0 && password_verify($password, $user['password']));

            if (!$passwordMatches) {
                jsonResponse(false, "Incorrect password credentials. Please retry.", 401);
            }

            // Exclude password hash from the returned response
            unset($user['password']);

            jsonResponse(true, [
                'user' => $user,
                'message' => "Welcome back, " . ($user['name'] ?: $user['first_name']) . "!"
            ]);
        } catch (PDOException $e) {
            jsonResponse(false, "Database query error: " . $e->getMessage(), 500);
        }
        break;

    // -------------------------------------------------------------------------
    // 2. Sign Up / Register Member
    // -------------------------------------------------------------------------
    case 'signup':
        $firstName = trim(isset($data['firstName']) ? $data['firstName'] : (isset($data['first_name']) ? $data['first_name'] : ''));
        $lastName = trim(isset($data['lastName']) ? $data['lastName'] : (isset($data['last_name']) ? $data['last_name'] : ''));
        $email = trim(strtolower(isset($data['email']) ? $data['email'] : ''));
        $password = isset($data['password']) ? $data['password'] : '';
        $gender = isset($data['gender']) ? $data['gender'] : 'Other';

        if (empty($firstName)) {
            jsonResponse(false, "Please enter your first name.", 400);
        }

        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            jsonResponse(false, "Please enter a valid email address.", 400);
        }

        if (empty($password) || strlen($password) < 6) {
            jsonResponse(false, "Password must be at least 6 characters long.", 400);
        }

        $fullName = trim($firstName . ' ' . $lastName);

        try {
            // Check if email (PRIMARY KEY) already exists
            $checkStmt = $pdo->prepare("SELECT `email` FROM `users` WHERE `email` = ? LIMIT 1");
            $checkStmt->execute([$email]);
            if ($checkStmt->fetch()) {
                jsonResponse(false, "An account with this email address already exists.", 409);
            }

            // Insert new user into MySQL with email as PRIMARY KEY
            $insertStmt = $pdo->prepare("
                INSERT INTO `users` (`email`, `name`, `first_name`, `last_name`, `password`, `gender`, `role`, `genre`, `avatar`, `created_at`)
                VALUES (?, ?, ?, ?, ?, ?, 'member', 'Sci-Fi & Fantasy', '1', NOW())
            ");
            $insertStmt->execute([$email, $fullName, $firstName, $lastName, $password, $gender]);

            // Retrieve the newly created user record
            $fetchStmt = $pdo->prepare("SELECT * FROM `users` WHERE `email` = ? LIMIT 1");
            $fetchStmt->execute([$email]);
            $newUser = $fetchStmt->fetch();
            unset($newUser['password']);

            jsonResponse(true, [
                'user' => $newUser,
                'message' => "Account created successfully! You can now sign in."
            ], 201);
        } catch (PDOException $e) {
            jsonResponse(false, "Database insert error: " . $e->getMessage(), 500);
        }
        break;

    // -------------------------------------------------------------------------
    // 3. Reset Password (using email as PRIMARY KEY)
    // -------------------------------------------------------------------------
    case 'reset_password':
        $email = trim(strtolower(isset($data['email']) ? $data['email'] : ''));
        $password = isset($data['password']) ? $data['password'] : '';

        if (empty($email)) {
            jsonResponse(false, "Please enter your account email address.", 400);
        }

        if (empty($password) || strlen($password) < 6) {
            jsonResponse(false, "Your new password must be at least 6 characters long.", 400);
        }

        try {
            // Verify that the user exists using email as PRIMARY KEY
            $checkStmt = $pdo->prepare("SELECT `email`, `name` FROM `users` WHERE `email` = ? LIMIT 1");
            $checkStmt->execute([$email]);
            $user = $checkStmt->fetch();

            if (!$user) {
                jsonResponse(false, "No registered account exists with this email address.", 404);
            }

            // Update the password in MySQL using email as PRIMARY KEY
            $updateStmt = $pdo->prepare("
                UPDATE `users` 
                SET `password` = ?, `updated_at` = NOW() 
                WHERE `email` = ?
            ");
            $updateStmt->execute([$password, $email]);

            jsonResponse(true, [
                'email' => $email,
                'message' => "Password has been successfully updated in MySQL database."
            ]);
        } catch (PDOException $e) {
            jsonResponse(false, "Database update error: " . $e->getMessage(), 500);
        }
        break;

    // -------------------------------------------------------------------------
    // 4. Fetch Current User Details (by email PRIMARY KEY)
    // -------------------------------------------------------------------------
    case 'me':
        $email = trim(strtolower(isset($_GET['email']) ? $_GET['email'] : (isset($data['email']) ? $data['email'] : '')));

        if (empty($email)) {
            jsonResponse(false, "Email parameter is required.", 400);
        }

        try {
            $stmt = $pdo->prepare("
                SELECT `email`, `name`, `first_name`, `last_name`, `gender`, `role`, `genre`, `avatar`, `phone`, `bio`, `premium`, `created_at`
                FROM `users` 
                WHERE `email` = ? 
                LIMIT 1
            ");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if (!$user) {
                jsonResponse(false, "User not found.", 404);
            }

            jsonResponse(true, $user);
        } catch (PDOException $e) {
            jsonResponse(false, "Database query error: " . $e->getMessage(), 500);
        }
        break;

    default:
        jsonResponse(false, "Invalid authentication action specified.", 400);
}
