<?php
/**
 * =============================================================================
 * Aetheria Library — Reviews API Controller
 * Handles book reader reviews and moderation in MySQL.
 * =============================================================================
 */

require_once __DIR__ . '/db.php';

$pdo = getDB();
$data = getRequestData();
$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? $_GET['action'] : (isset($data['action']) ? $data['action'] : '');

// Handle HTTP GET (List reviews)
if ($method === 'GET' && empty($action)) {
    $bookId = isset($_GET['book_id']) ? (int)$_GET['book_id'] : 0;
    $rating = isset($_GET['rating']) ? $_GET['rating'] : 'all';

    try {
        $sql = "
            SELECT r.`id`, r.`user_email` AS `userId`, r.`book_id` AS `bookId`,
                   r.`user_name` AS `userName`, r.`rating`, r.`text`, r.`created_at` AS `createdAt`,
                   b.`title` AS `bookTitle`
            FROM `reviews` r
            LEFT JOIN `books` b ON r.`book_id` = b.`id`
            WHERE 1=1
        ";
        $params = [];

        if ($bookId > 0) {
            $sql .= " AND r.`book_id` = ?";
            $params[] = $bookId;
        }

        if ($rating !== 'all' && is_numeric($rating)) {
            $sql .= " AND r.`rating` = ?";
            $params[] = (int)$rating;
        }

        $sql .= " ORDER BY r.`created_at` DESC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $reviews = $stmt->fetchAll();

        foreach ($reviews as &$r) {
            $r['rating'] = (int)$r['rating'];
        }

        jsonResponse(true, $reviews);
    } catch (PDOException $e) {
        jsonResponse(false, "Database query error: " . $e->getMessage(), 500);
    }
}

// Handle Actions (POST / PUT / DELETE)
switch ($action) {
    // -------------------------------------------------------------------------
    // 1. Add Review (Reader)
    // -------------------------------------------------------------------------
    case 'add':
        $userEmail = trim(strtolower(isset($data['user_email']) ? $data['user_email'] : (isset($data['userId']) ? $data['userId'] : '')));
        $bookId = isset($data['book_id']) ? (int)$data['book_id'] : (isset($data['bookId']) ? (int)$data['bookId'] : 0);
        $userName = trim(isset($data['user_name']) ? $data['user_name'] : (isset($data['userName']) ? $data['userName'] : 'Reader'));
        $rating = isset($data['rating']) ? (int)$data['rating'] : 5;
        $text = trim(isset($data['text']) ? $data['text'] : '');

        if (empty($userEmail) || !$bookId || empty($text)) {
            jsonResponse(false, "User email, book ID, and review text are required.", 400);
        }

        try {
            $stmt = $pdo->prepare("
                INSERT INTO `reviews` (`user_email`, `book_id`, `user_name`, `rating`, `text`, `created_at`)
                VALUES (?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([$userEmail, $bookId, $userName, $rating, $text]);
            $newId = (int)$pdo->lastInsertId();

            jsonResponse(true, [
                'id' => $newId,
                'message' => "Review posted successfully in MySQL."
            ], 201);
        } catch (PDOException $e) {
            jsonResponse(false, "Failed to submit review: " . $e->getMessage(), 500);
        }
        break;

    // -------------------------------------------------------------------------
    // 2. Delete Review (Admin)
    // -------------------------------------------------------------------------
    case 'delete':
        $reviewId = isset($data['id']) ? (int)$data['id'] : (isset($_GET['id']) ? (int)$_GET['id'] : 0);

        if (!$reviewId) {
            jsonResponse(false, "Review ID is required to delete.", 400);
        }

        try {
            $stmt = $pdo->prepare("DELETE FROM `reviews` WHERE `id` = ?");
            $stmt->execute([$reviewId]);

            jsonResponse(true, "Review #{$reviewId} deleted from MySQL.");
        } catch (PDOException $e) {
            jsonResponse(false, "Failed to delete review: " . $e->getMessage(), 500);
        }
        break;

    default:
        jsonResponse(false, "Invalid reviews action specified.", 400);
}
