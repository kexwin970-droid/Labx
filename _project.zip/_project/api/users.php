<?php
/**
 * =============================================================================
 * Aetheria Library — Users Management API Controller
 * Provides CRUD operations for users in MySQL.
 * Primary Key: email
 * =============================================================================
 */

require_once __DIR__ . '/db.php';

$pdo = getDB();
$data = getRequestData();
$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? $_GET['action'] : (isset($data['action']) ? $data['action'] : '');

// Handle HTTP GET (List users or get single user)
if ($method === 'GET' && empty($action)) {
    $search = trim(isset($_GET['search']) ? $_GET['search'] : '');
    $role = trim(isset($_GET['role']) ? $_GET['role'] : 'all');

    try {
        $sql = "
            SELECT u.`email`, u.`name`, u.`first_name` AS `firstName`, u.`last_name` AS `lastName`,
                   u.`gender`, u.`role`, u.`genre`, u.`avatar`, u.`phone`, u.`bio`, u.`premium`, u.`created_at`,
                   (SELECT COUNT(*) FROM `loans` l WHERE l.`user_email` = u.`email` AND l.`status` = 'active-borrow') AS activeLoans
            FROM `users` u
            WHERE 1=1
        ";
        $params = [];

        if (!empty($search)) {
            $sql .= " AND (u.`name` LIKE ? OR u.`email` LIKE ?)";
            $params[] = '%' . $search . '%';
            $params[] = '%' . $search . '%';
        }

        if ($role === 'admin') {
            $sql .= " AND u.`role` = 'admin'";
        } elseif ($role === 'member') {
            $sql .= " AND u.`role` != 'admin'";
        }

        $sql .= " ORDER BY (u.`role` = 'admin') DESC, u.`created_at` DESC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $users = $stmt->fetchAll();

        jsonResponse(true, $users);
    } catch (PDOException $e) {
        jsonResponse(false, "Database query error: " . $e->getMessage(), 500);
    }
}

// Handle Actions (POST / PUT / DELETE)
switch ($action) {
    // -------------------------------------------------------------------------
    // 1. Admin Create User
    // -------------------------------------------------------------------------
    case 'create':
        $firstName = trim(isset($data['firstName']) ? $data['firstName'] : (isset($data['first_name']) ? $data['first_name'] : ''));
        $lastName = trim(isset($data['lastName']) ? $data['lastName'] : (isset($data['last_name']) ? $data['last_name'] : ''));
        $email = trim(strtolower(isset($data['email']) ? $data['email'] : ''));
        $password = isset($data['password']) ? $data['password'] : 'password123';
        $gender = isset($data['gender']) ? $data['gender'] : 'Other';
        $role = isset($data['role']) ? $data['role'] : 'member';
        $genre = isset($data['genre']) ? $data['genre'] : 'Fiction';

        if (empty($firstName) || empty($email)) {
            jsonResponse(false, "First name and email address are required.", 400);
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            jsonResponse(false, "Please provide a valid email address.", 400);
        }

        $fullName = trim($firstName . ' ' . $lastName);

        try {
            // Check if email already exists
            $check = $pdo->prepare("SELECT `email` FROM `users` WHERE `email` = ? LIMIT 1");
            $check->execute([$email]);
            if ($check->fetch()) {
                jsonResponse(false, "An account with email " . htmlspecialchars($email) . " already exists.", 409);
            }

            $stmt = $pdo->prepare("
                INSERT INTO `users` (`email`, `name`, `first_name`, `last_name`, `password`, `gender`, `role`, `genre`, `avatar`, `created_at`)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, '1', NOW())
            ");
            $stmt->execute([$email, $fullName, $firstName, $lastName, $password, $gender, $role, $genre]);

            jsonResponse(true, [
                'email' => $email,
                'name' => $fullName,
                'role' => $role,
                'message' => "Account for {$fullName} created successfully in MySQL."
            ], 201);
        } catch (PDOException $e) {
            jsonResponse(false, "Failed to create user: " . $e->getMessage(), 500);
        }
        break;

    // -------------------------------------------------------------------------
    // 2. Update Profile Details
    // -------------------------------------------------------------------------
    case 'update_profile':
        $email = trim(strtolower(isset($data['email']) ? $data['email'] : ''));
        $firstName = trim(isset($data['firstName']) ? $data['firstName'] : (isset($data['first_name']) ? $data['first_name'] : ''));
        $lastName = trim(isset($data['lastName']) ? $data['lastName'] : (isset($data['last_name']) ? $data['last_name'] : ''));
        $gender = isset($data['gender']) ? $data['gender'] : null;
        $genre = isset($data['genre']) ? $data['genre'] : null;
        $phone = isset($data['phone']) ? $data['phone'] : null;
        $bio = isset($data['bio']) ? $data['bio'] : null;
        $premium = isset($data['premium']) ? (int)$data['premium'] : null;

        if (empty($email)) {
            jsonResponse(false, "User email is required to update profile.", 400);
        }

        try {
            // Check user exists
            $check = $pdo->prepare("SELECT * FROM `users` WHERE `email` = ? LIMIT 1");
            $check->execute([$email]);
            $user = $check->fetch();

            if (!$user) {
                jsonResponse(false, "User not found.", 404);
            }

            $fullName = !empty($firstName) ? trim($firstName . ' ' . $lastName) : $user['name'];

            $updateFields = [];
            $params = [];

            if (!empty($firstName)) {
                $updateFields[] = "`first_name` = ?";
                $params[] = $firstName;
            }
            if ($lastName !== null) {
                $updateFields[] = "`last_name` = ?";
                $params[] = $lastName;
            }
            if (!empty($fullName)) {
                $updateFields[] = "`name` = ?";
                $params[] = $fullName;
            }
            if (!empty($gender)) {
                $updateFields[] = "`gender` = ?";
                $params[] = $gender;
            }
            if (!empty($genre)) {
                $updateFields[] = "`genre` = ?";
                $params[] = $genre;
            }
            if ($phone !== null) {
                $updateFields[] = "`phone` = ?";
                $params[] = $phone;
            }
            if ($bio !== null) {
                $updateFields[] = "`bio` = ?";
                $params[] = $bio;
            }
            if ($premium !== null) {
                $updateFields[] = "`premium` = ?";
                $params[] = $premium;
            }

            if (empty($updateFields)) {
                jsonResponse(false, "No fields provided to update.", 400);
            }

            $params[] = $email; // for WHERE email = ?
            $sql = "UPDATE `users` SET " . implode(', ', $updateFields) . ", `updated_at` = NOW() WHERE `email` = ?";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);

            // Fetch updated record
            $fetch = $pdo->prepare("SELECT `email`, `name`, `first_name` AS `firstName`, `last_name` AS `lastName`, `gender`, `role`, `genre`, `avatar`, `phone`, `bio`, `premium` FROM `users` WHERE `email` = ?");
            $fetch->execute([$email]);
            $updatedUser = $fetch->fetch();

            jsonResponse(true, [
                'user' => $updatedUser,
                'message' => "Profile updated successfully in MySQL."
            ]);
        } catch (PDOException $e) {
            jsonResponse(false, "Failed to update profile: " . $e->getMessage(), 500);
        }
        break;

    // -------------------------------------------------------------------------
    // 3. Reset User Password (by email PRIMARY KEY)
    // -------------------------------------------------------------------------
    case 'reset_password':
        $email = trim(strtolower(isset($data['email']) ? $data['email'] : ''));
        $newPassword = isset($data['password']) ? $data['password'] : '';

        if (empty($email) || empty($newPassword)) {
            jsonResponse(false, "Email and new password are required.", 400);
        }

        if (strlen($newPassword) < 6) {
            jsonResponse(false, "Password must be at least 6 characters long.", 400);
        }

        try {
            $check = $pdo->prepare("SELECT `email` FROM `users` WHERE `email` = ? LIMIT 1");
            $check->execute([$email]);
            if (!$check->fetch()) {
                jsonResponse(false, "No registered account found with email: " . htmlspecialchars($email), 404);
            }

            $stmt = $pdo->prepare("UPDATE `users` SET `password` = ?, `updated_at` = NOW() WHERE `email` = ?");
            $stmt->execute([$newPassword, $email]);

            jsonResponse(true, "Password updated successfully for " . htmlspecialchars($email));
        } catch (PDOException $e) {
            jsonResponse(false, "Password update failed: " . $e->getMessage(), 500);
        }
        break;

    // -------------------------------------------------------------------------
    // 4. Delete User (by email PRIMARY KEY)
    // -------------------------------------------------------------------------
    case 'delete':
        $email = trim(strtolower(isset($data['email']) ? $data['email'] : (isset($_GET['email']) ? $_GET['email'] : '')));

        if (empty($email)) {
            jsonResponse(false, "Email parameter is required to delete an account.", 400);
        }

        if ($email === 'admin@aetheria.org') {
            jsonResponse(false, "The primary administrator account cannot be deleted.", 403);
        }

        try {
            $stmt = $pdo->prepare("DELETE FROM `users` WHERE `email` = ?");
            $stmt->execute([$email]);

            if ($stmt->rowCount() > 0) {
                jsonResponse(true, "Account {$email} has been successfully deleted from MySQL.");
            } else {
                jsonResponse(false, "Account not found or already deleted.", 404);
            }
        } catch (PDOException $e) {
            jsonResponse(false, "Failed to delete user: " . $e->getMessage(), 500);
        }
        break;

    default:
        jsonResponse(false, "Invalid users action specified.", 400);
}
