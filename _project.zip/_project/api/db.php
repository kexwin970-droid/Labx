<?php
/**
 * =============================================================================
 * Aetheria Library — MySQL Database Connection & Utilities
 * Uses PDO for secure, prepared SQL execution.
 * =============================================================================
 */

// Allow CORS for modern decoupled or local setups
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Database configuration defaults (standard XAMPP / WAMP / Docker setup)
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_PORT', getenv('DB_PORT') ?: '3306');
define('DB_NAME', getenv('DB_NAME') ?: 'aetheria_db');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');

/**
 * Get active PDO connection to MySQL.
 * Automatically attempts to create the database if it doesn't exist yet.
 */
function getDB() {
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }

    $dsnWithoutDb = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];

    try {
        // First connect to MySQL server
        $rawPdo = new PDO($dsnWithoutDb, DB_USER, DB_PASS, $options);
        $rawPdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        
        // Connect to the specific database
        $dsnWithDb = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $pdo = new PDO($dsnWithDb, DB_USER, DB_PASS, $options);

        // Auto-initialize tables if not present
        ensureTablesInitialized($pdo);

        return $pdo;
    } catch (PDOException $e) {
        jsonResponse(false, "MySQL Connection Error: " . $e->getMessage(), 500);
        exit;
    }
}

/**
 * Automatically creates tables and seeds default records if empty.
 */
function ensureTablesInitialized($pdo) {
    try {
        // Check if users table exists
        $check = $pdo->query("SHOW TABLES LIKE 'users'")->fetch();
        if (!$check) {
            // Read and execute database.sql schema
            $sqlFile = dirname(__DIR__) . '/database.sql';
            if (file_exists($sqlFile)) {
                $sql = file_get_contents($sqlFile);
                $pdo->exec($sql);
            }
        }
    } catch (Exception $e) {
        // Table check failed, ignore and allow explicit queries to run
    }
}

/**
 * Standard JSON response helper.
 */
function jsonResponse($success, $payload, $statusCode = 200, $extra = []) {
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    
    $response = [
        'success' => (bool)$success
    ];

    if ($success) {
        if (is_string($payload)) {
            $response['message'] = $payload;
        } else {
            $response['data'] = $payload;
        }
    } else {
        $response['error'] = is_string($payload) ? $payload : 'An error occurred';
    }

    if (!empty($extra)) {
        $response = array_merge($response, $extra);
    }

    echo json_encode($response);
    exit;
}

/**
 * Parse incoming HTTP request body (JSON or Form).
 */
function getRequestData() {
    $raw = file_get_contents('php://input');
    if (!empty($raw)) {
        $json = json_decode($raw, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($json)) {
            return $json;
        }
    }
    return $_POST;
}
