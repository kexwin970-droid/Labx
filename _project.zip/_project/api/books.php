<?php
/**
 * =============================================================================
 * Aetheria Library — Books Catalog API Controller
 * Provides CRUD operations for books in MySQL.
 * =============================================================================
 */

require_once __DIR__ . '/db.php';

$pdo = getDB();
$data = getRequestData();
$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? $_GET['action'] : (isset($data['action']) ? $data['action'] : '');

// Handle HTTP GET (List books or get single book)
if ($method === 'GET' && empty($action)) {
    $search = trim(isset($_GET['search']) ? $_GET['search'] : '');
    $genre = trim(isset($_GET['genre']) ? $_GET['genre'] : 'all');
    $avail = trim(isset($_GET['avail']) ? $_GET['avail'] : 'all');
    $bookId = isset($_GET['id']) ? (int)$_GET['id'] : null;

    try {
        if ($bookId) {
            $stmt = $pdo->prepare("SELECT * FROM `books` WHERE `id` = ? LIMIT 1");
            $stmt->execute([$bookId]);
            $book = $stmt->fetch();
            if (!$book) jsonResponse(false, "Book not found.", 404);
            $book['available'] = (bool)$book['available'];
            $book['rating'] = (float)$book['rating'];
            jsonResponse(true, $book);
        }

        $sql = "SELECT * FROM `books` WHERE 1=1";
        $params = [];

        if (!empty($search)) {
            $sql .= " AND (`title` LIKE ? OR `author` LIKE ? OR `description` LIKE ?)";
            $params[] = '%' . $search . '%';
            $params[] = '%' . $search . '%';
            $params[] = '%' . $search . '%';
        }

        if (!empty($genre) && $genre !== 'all') {
            $sql .= " AND `genre` = ?";
            $params[] = $genre;
        }

        if ($avail === 'available') {
            $sql .= " AND `available` = 1";
        } elseif ($avail === 'borrowed') {
            $sql .= " AND `available` = 0";
        }

        $sql .= " ORDER BY `id` ASC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $books = $stmt->fetchAll();

        foreach ($books as &$b) {
            $b['available'] = (bool)$b['available'];
            $b['rating'] = (float)$b['rating'];
        }

        jsonResponse(true, $books);
    } catch (PDOException $e) {
        jsonResponse(false, "Database query error: " . $e->getMessage(), 500);
    }
}

// Handle Actions (POST / PUT / DELETE)
switch ($action) {
    // -------------------------------------------------------------------------
    // 1. Add Book (Admin)
    // -------------------------------------------------------------------------
    case 'add':
        $title = trim(isset($data['title']) ? $data['title'] : '');
        $author = trim(isset($data['author']) ? $data['author'] : '');
        $genre = trim(isset($data['genre']) ? $data['genre'] : 'Fiction');
        $rating = isset($data['rating']) ? (float)$data['rating'] : 4.5;
        $gradient = isset($data['gradient']) ? $data['gradient'] : 'linear-gradient(135deg, #0f172a, #06b6d4)';
        $description = isset($data['description']) ? $data['description'] : '';
        $available = isset($data['available']) ? ((bool)$data['available'] ? 1 : 0) : 1;
        $isbn = isset($data['isbn']) ? $data['isbn'] : ('978-' . rand(1000000000, 9999999999));
        $pages = isset($data['pages']) ? (int)$data['pages'] : rand(200, 500);

        if (empty($title) || empty($author)) {
            jsonResponse(false, "Title and author are required fields.", 400);
        }

        try {
            $stmt = $pdo->prepare("
                INSERT INTO `books` (`title`, `author`, `genre`, `rating`, `available`, `gradient`, `description`, `isbn`, `pages`, `created_at`)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([$title, $author, $genre, $rating, $available, $gradient, $description, $isbn, $pages]);
            $newId = (int)$pdo->lastInsertId();

            jsonResponse(true, [
                'id' => $newId,
                'title' => $title,
                'message' => "Book \"{$title}\" added to library catalog in MySQL."
            ], 201);
        } catch (PDOException $e) {
            jsonResponse(false, "Failed to add book: " . $e->getMessage(), 500);
        }
        break;

    // -------------------------------------------------------------------------
    // 2. Edit Book (Admin)
    // -------------------------------------------------------------------------
    case 'edit':
        $id = isset($data['id']) ? (int)$data['id'] : 0;
        $title = trim(isset($data['title']) ? $data['title'] : '');
        $author = trim(isset($data['author']) ? $data['author'] : '');
        $genre = trim(isset($data['genre']) ? $data['genre'] : 'Fiction');
        $rating = isset($data['rating']) ? (float)$data['rating'] : 4.5;
        $description = isset($data['description']) ? $data['description'] : '';
        $available = isset($data['available']) ? ($data['available'] === 'true' || $data['available'] === true || $data['available'] === 1 || $data['available'] === '1' ? 1 : 0) : 1;

        if (!$id || empty($title) || empty($author)) {
            jsonResponse(false, "Book ID, title, and author are required.", 400);
        }

        try {
            $stmt = $pdo->prepare("
                UPDATE `books` 
                SET `title` = ?, `author` = ?, `genre` = ?, `rating` = ?, `description` = ?, `available` = ?
                WHERE `id` = ?
            ");
            $stmt->execute([$title, $author, $genre, $rating, $description, $available, $id]);

            jsonResponse(true, [
                'id' => $id,
                'title' => $title,
                'message' => "Book \"{$title}\" updated in MySQL catalog."
            ]);
        } catch (PDOException $e) {
            jsonResponse(false, "Failed to update book: " . $e->getMessage(), 500);
        }
        break;

    // -------------------------------------------------------------------------
    // 3. Delete Book (Admin)
    // -------------------------------------------------------------------------
    case 'delete':
        $id = isset($data['id']) ? (int)$data['id'] : (isset($_GET['id']) ? (int)$_GET['id'] : 0);

        if (!$id) {
            jsonResponse(false, "Book ID is required to delete.", 400);
        }

        try {
            $stmt = $pdo->prepare("DELETE FROM `books` WHERE `id` = ?");
            $stmt->execute([$id]);

            jsonResponse(true, "Book #{$id} has been removed from MySQL catalog.");
        } catch (PDOException $e) {
            jsonResponse(false, "Failed to delete book: " . $e->getMessage(), 500);
        }
        break;

    default:
        jsonResponse(false, "Invalid books action specified.", 400);
}
