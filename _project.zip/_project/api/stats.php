<?php
/**
 * =============================================================================
 * Aetheria Library — Admin Analytics & Stats API Controller
 * Computes live database statistics for the Administrator Dashboard.
 * =============================================================================
 */

require_once __DIR__ . '/db.php';

$pdo = getDB();

try {
    // 1. Total counts
    $totalBooks = (int)$pdo->query("SELECT COUNT(*) FROM `books`")->fetchColumn();
    $totalUsers = (int)$pdo->query("SELECT COUNT(*) FROM `users`")->fetchColumn();
    $totalMembers = (int)$pdo->query("SELECT COUNT(*) FROM `users` WHERE `role` != 'admin'")->fetchColumn();
    $totalAdmins = (int)$pdo->query("SELECT COUNT(*) FROM `users` WHERE `role` = 'admin'")->fetchColumn();
    $activeLoans = (int)$pdo->query("SELECT COUNT(*) FROM `loans` WHERE `status` = 'active-borrow'")->fetchColumn();
    $overdueLoans = (int)$pdo->query("SELECT COUNT(*) FROM `loans` WHERE `status` = 'active-borrow' AND `due_date` < NOW()")->fetchColumn();
    $returnedLoans = (int)$pdo->query("SELECT COUNT(*) FROM `loans` WHERE `status` = 'returned'")->fetchColumn();
    $totalReviews = (int)$pdo->query("SELECT COUNT(*) FROM `reviews`")->fetchColumn();

    // 2. Loans by Book Genre
    $genreStmt = $pdo->query("
        SELECT b.`genre`, COUNT(l.`id`) AS `count`
        FROM `loans` l
        JOIN `books` b ON l.`book_id` = b.`id`
        GROUP BY b.`genre`
        ORDER BY `count` DESC
    ");
    $genreStats = $genreStmt->fetchAll();

    // 3. Recent 5 Loans
    $recentLoansStmt = $pdo->query("
        SELECT l.`id`, l.`user_email` AS `userId`, l.`borrow_date` AS `borrowDate`, l.`status`,
               b.`title` AS `bookTitle`, u.`name` AS `userName`
        FROM `loans` l
        LEFT JOIN `books` b ON l.`book_id` = b.`id`
        LEFT JOIN `users` u ON l.`user_email` = u.`email`
        ORDER BY l.`borrow_date` DESC
        LIMIT 5
    ");
    $recentLoans = $recentLoansStmt->fetchAll();

    // 4. Recent 5 Users
    $recentUsersStmt = $pdo->query("
        SELECT `email`, `name`, `role`, `gender`, `created_at`
        FROM `users`
        ORDER BY `created_at` DESC
        LIMIT 5
    ");
    $recentUsers = $recentUsersStmt->fetchAll();

    jsonResponse(true, [
        'totalBooks' => $totalBooks,
        'totalUsers' => $totalUsers,
        'totalMembers' => $totalMembers,
        'totalAdmins' => $totalAdmins,
        'activeLoans' => $activeLoans,
        'overdueLoans' => $overdueLoans,
        'returnedLoans' => $returnedLoans,
        'totalReviews' => $totalReviews,
        'genreStats' => $genreStats,
        'recentLoans' => $recentLoans,
        'recentUsers' => $recentUsers
    ]);
} catch (PDOException $e) {
    jsonResponse(false, "Failed to compute stats: " . $e->getMessage(), 500);
}
