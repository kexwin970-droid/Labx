/* ==========================================================================
   Aetheria Library — Admin Console Controller
   Full administrative oversight: Catalog, Users, Circulation, Reviews & Logs
   ========================================================================== */

// Local Storage Keys
const STORAGE_KEYS = {
    books: "aetheria_books",
    users: "aetheria_users",
    loans: "aetheria_loans",
    reviews: "aetheria_reviews",
    reading: "aetheria_reading",
    activeUser: "aetheria_active_user",
    theme: "aetheria_theme"
};

// Available book gradients
const GRADIENTS = [
    "linear-gradient(135deg, #c27d38, #5e3a15)",
    "linear-gradient(135deg, #0f172a, #06b6d4)",
    "linear-gradient(135deg, #3730a3, #4338ca)",
    "linear-gradient(135deg, #78350f, #b45309)",
    "linear-gradient(135deg, #064e3b, #34d399)",
    "linear-gradient(135deg, #701a75, #ec4899)",
    "linear-gradient(135deg, #7f1d1d, #ef4444)",
    "linear-gradient(135deg, #1e293b, #475569)"
];

const GENRES = [
    "Fiction",
    "Sci-Fi & Fantasy",
    "Technology & Science",
    "History & Biography",
    "Mystery & Thriller",
    "Philosophy & Psychology"
];

// Admin State
const adminState = {
    books: [],
    users: [],
    loans: [],
    reviews: [],
    reading: [],
    activeUser: null,
    currentTab: "overview",
    selectedGradient: GRADIENTS[0],
    editingBookId: null,
    // Filters
    bookSearch: "",
    bookGenre: "all",
    bookAvail: "all",
    userSearch: "",
    userRole: "all",
    loanSearch: "",
    loanStatus: "all",
    reviewSearch: "",
    reviewRating: "all",
    readingSearch: ""
};

// ==========================================================================
// Initialization & Security Gate
// ==========================================================================
document.addEventListener("DOMContentLoaded", () => {
    initTheme();
    loadAllData();
    checkAdminAccess();
});

function initTheme() {
    const savedTheme = localStorage.getItem(STORAGE_KEYS.theme) || "dark";
    document.documentElement.setAttribute("data-theme", savedTheme);
    updateThemeIcons(savedTheme);

    const themeToggle = document.getElementById("theme-toggle");
    if (themeToggle) {
        themeToggle.addEventListener("click", () => {
            const current = document.documentElement.getAttribute("data-theme");
            const next = current === "dark" ? "light" : "dark";
            document.documentElement.setAttribute("data-theme", next);
            localStorage.setItem(STORAGE_KEYS.theme, next);
            updateThemeIcons(next);
            showToast("Theme Updated", `Switched to ${next === "dark" ? "Dark Mode" : "Light Mode"}.`, "info");
        });
    }
}

function updateThemeIcons(theme) {
    const moonIcon = document.querySelector(".moon-icon");
    const sunIcon = document.querySelector(".sun-icon");
    if (!moonIcon || !sunIcon) return;
    if (theme === "dark") {
        moonIcon.classList.remove("hidden");
        sunIcon.classList.add("hidden");
    } else {
        moonIcon.classList.add("hidden");
        sunIcon.classList.remove("hidden");
    }
}

function checkAdminAccess() {
    const currentUser = getActiveUser();
    if (!currentUser || currentUser.role !== "admin") {
        window.location.href = "admin/login.html";
        return;
    }
    adminState.activeUser = currentUser;

    const adminApp = document.getElementById("admin-app-container");
    if (adminApp) adminApp.classList.remove("hidden");

    // Populate admin user pill
    const adminAvatar = document.getElementById("admin-avatar");
    const adminName = document.getElementById("admin-name");
    if (adminAvatar) {
        adminAvatar.src = `https://api.dicebear.com/7.x/bottts/svg?seed=${currentUser.name}&backgroundColor=b6e3f4`;
    }
    if (adminName) {
        adminName.textContent = currentUser.name || "Aetheria Admin";
    }

    setupNavigation();
    setupFilters();
    setupModals();
    setupLogout();

    // Render Initial View
    renderAll();
}

function setupLogout() {
    const logoutBtn = document.getElementById("admin-logout-btn");
    if (logoutBtn) {
        logoutBtn.addEventListener("click", () => {
            clearActiveUser();
            showToast("Signed Out", "Administrator session closed.", "info");
            setTimeout(() => {
                window.location.href = "admin/login.html";
            }, 400);
        });
    }
}

// ==========================================================================
// Data Storage & Retrieval (MySQL Bridge & Local Cache)
// ==========================================================================
async function loadAllData() {
    // 1. Initial synchronous load from LocalStorage cache
    loadFromLocalStorage();

    // 2. Fresh synchronization from MySQL via PHP API
    if (window.location.protocol !== 'file:') {
        try {
            const [usersRes, booksRes, loansRes, reviewsRes] = await Promise.allSettled([
                callApi('users.php'),
                callApi('books.php'),
                callApi('loans.php'),
                callApi('reviews.php')
            ]);

            let changed = false;

            if (usersRes.status === 'fulfilled' && usersRes.value && usersRes.value.success && Array.isArray(usersRes.value.data)) {
                adminState.users = usersRes.value.data;
                saveUsers(adminState.users);
                changed = true;
            }

            if (booksRes.status === 'fulfilled' && booksRes.value && booksRes.value.success && Array.isArray(booksRes.value.data)) {
                adminState.books = booksRes.value.data;
                saveData(STORAGE_KEYS.books, adminState.books);
                changed = true;
            }

            if (loansRes.status === 'fulfilled' && loansRes.value && loansRes.value.success && Array.isArray(loansRes.value.data)) {
                adminState.loans = loansRes.value.data;
                saveData(STORAGE_KEYS.loans, adminState.loans);
                changed = true;
            }

            if (reviewsRes.status === 'fulfilled' && reviewsRes.value && reviewsRes.value.success && Array.isArray(reviewsRes.value.data)) {
                adminState.reviews = reviewsRes.value.data;
                saveData(STORAGE_KEYS.reviews, adminState.reviews);
                changed = true;
            }

            if (changed) {
                renderAll();
            }
        } catch (err) {
            console.warn("Could not sync admin data with MySQL backend:", err);
        }
    }
}

function loadFromLocalStorage() {
    // 1. Books
    try {
        const storedBooks = localStorage.getItem(STORAGE_KEYS.books);
        if (storedBooks) {
            adminState.books = JSON.parse(storedBooks);
        } else {
            adminState.books = getSeedBooks();
            saveData(STORAGE_KEYS.books, adminState.books);
        }
    } catch (e) {
        adminState.books = getSeedBooks();
    }

    // 2. Users
    try {
        adminState.users = getUsers();
    } catch (e) {
        adminState.users = [];
    }

    // 3. Loans
    try {
        const storedLoans = localStorage.getItem(STORAGE_KEYS.loans);
        if (storedLoans) {
            adminState.loans = JSON.parse(storedLoans);
        } else {
            adminState.loans = getSeedLoans();
            saveData(STORAGE_KEYS.loans, adminState.loans);
        }
    } catch (e) {
        adminState.loans = [];
    }

    // 4. Reviews
    try {
        const storedReviews = localStorage.getItem(STORAGE_KEYS.reviews);
        adminState.reviews = storedReviews ? JSON.parse(storedReviews) : getSeedReviews();
    } catch (e) {
        adminState.reviews = [];
    }

    // 5. Reading logs
    try {
        const storedReading = localStorage.getItem(STORAGE_KEYS.reading);
        adminState.reading = storedReading ? JSON.parse(storedReading) : [];
    } catch (e) {
        adminState.reading = [];
    }
}

function saveData(key, data) {
    try {
        localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
        console.error(`Error saving data for ${key}:`, e);
    }
}

// ==========================================================================
// Navigation & Tab Controller
// ==========================================================================
function setupNavigation() {
    const navItems = document.querySelectorAll(".admin-nav-item");
    navItems.forEach(btn => {
        btn.addEventListener("click", () => {
            const targetView = btn.getAttribute("data-view");
            switchAdminTab(targetView);
        });
    });
}

function switchAdminTab(tabName) {
    adminState.currentTab = tabName;

    // Update active nav button
    document.querySelectorAll(".admin-nav-item").forEach(btn => {
        if (btn.getAttribute("data-view") === tabName) {
            btn.classList.add("active");
        } else {
            btn.classList.remove("active");
        }
    });

    // Update visible panel
    document.querySelectorAll(".admin-view-panel").forEach(panel => {
        if (panel.id === `view-${tabName}`) {
            panel.classList.remove("hidden");
        } else {
            panel.classList.add("hidden");
        }
    });

    // Render corresponding panel
    if (tabName === "overview") renderOverview();
    else if (tabName === "books") renderBooks();
    else if (tabName === "users") renderUsers();
    else if (tabName === "loans") renderLoans();
    else if (tabName === "reviews") renderReviews();
    else if (tabName === "reading") renderReadingLogs();
    else if (tabName === "settings") renderSettings();
}

function renderAll() {
    updateHeaderCounters();
    renderOverview();
    renderBooks();
    renderUsers();
    renderLoans();
    renderReviews();
    renderReadingLogs();
    renderSettings();
}

function updateHeaderCounters() {
    const hdrBooks = document.getElementById("hdr-books-count");
    const hdrLoans = document.getElementById("hdr-loans-count");
    const badgeBooks = document.getElementById("badge-books-count");
    const badgeLoans = document.getElementById("badge-loans-count");
    const badgeUsers = document.getElementById("badge-users-count");

    const activeLoans = adminState.loans.filter(l => l.status === "active-borrow").length;

    if (hdrBooks) hdrBooks.textContent = adminState.books.length;
    if (hdrLoans) hdrLoans.textContent = activeLoans;
    if (badgeBooks) badgeBooks.textContent = adminState.books.length;
    if (badgeLoans) badgeLoans.textContent = activeLoans;
    if (badgeUsers) badgeUsers.textContent = adminState.users.length;
}

// ==========================================================================
// 1. Overview Panel
// ==========================================================================
function renderOverview() {
    updateHeaderCounters();

    const totalBooks = adminState.books.length;
    const availableBooks = adminState.books.filter(b => b.available).length;
    const borrowedBooks = totalBooks - availableBooks;

    const totalUsers = adminState.users.length;
    const totalMembers = adminState.users.filter(u => u.role !== "admin").length;

    const activeLoans = adminState.loans.filter(l => l.status === "active-borrow");
    const overdueLoans = activeLoans.filter(l => new Date(l.dueDate) < new Date());

    const totalReviews = adminState.reviews.length;
    const avgRating = totalReviews > 0
        ? (adminState.reviews.reduce((acc, r) => acc + Number(r.rating || 0), 0) / totalReviews).toFixed(1)
        : "5.0";

    // Set stat card values
    document.getElementById("stat-total-books").textContent = totalBooks;
    document.getElementById("stat-books-sub").textContent = `${availableBooks} Available · ${borrowedBooks} Borrowed`;

    document.getElementById("stat-total-users").textContent = totalUsers;
    document.getElementById("stat-users-sub").textContent = `${totalMembers} Members · 1 Admin`;

    document.getElementById("stat-active-loans").textContent = activeLoans.length;
    document.getElementById("stat-loans-sub").textContent = overdueLoans.length > 0
        ? `${overdueLoans.length} Overdue Attention!`
        : "All on Schedule";

    document.getElementById("stat-total-reviews").textContent = totalReviews;
    document.getElementById("stat-reviews-sub").textContent = `Average Rating: ★ ${avgRating} / 5.0`;

    // Render Genre Distribution
    renderGenreDistribution();

    // Render Recent Activity Stream
    renderActivityStream();
}

function renderGenreDistribution() {
    const container = document.getElementById("genre-distribution-container");
    if (!container) return;

    const total = adminState.books.length || 1;
    const counts = {};
    GENRES.forEach(g => counts[g] = 0);

    adminState.books.forEach(b => {
        if (counts[b.genre] !== undefined) counts[b.genre]++;
        else counts["Fiction"] = (counts["Fiction"] || 0) + 1;
    });

    container.innerHTML = GENRES.map(genre => {
        const count = counts[genre] || 0;
        const percent = Math.round((count / total) * 100);
        return `
            <div class="admin-genre-row">
                <div class="admin-genre-meta">
                    <span class="admin-genre-name">${escapeHtml(genre)}</span>
                    <span class="admin-genre-count">${count} books (${percent}%)</span>
                </div>
                <div class="admin-progress-bar">
                    <div class="admin-progress-fill" style="width: ${percent}%;"></div>
                </div>
            </div>
        `;
    }).join("");
}

function renderActivityStream() {
    const container = document.getElementById("recent-activity-container");
    if (!container) return;

    const activities = [];

    // Latest Loans
    adminState.loans.slice(0, 5).forEach(l => {
        const book = findBookById(l.bookId);
        const user = adminState.users.find(u => u.email === l.userId);
        activities.push({
            type: l.status === "returned" ? "return" : "loan",
            icon: l.status === "returned" ? "fa-rotate-left" : "fa-book-bookmark",
            title: l.status === "returned" ? "Book Returned" : "Loan Issued",
            desc: `<strong>${escapeHtml(user ? user.name : l.userId)}</strong> ${l.status === 'returned' ? 'returned' : 'borrowed'} "${escapeHtml(book ? book.title : 'Book #" + l.bookId')}"`,
            date: new Date(l.status === "returned" && l.returnDate ? l.returnDate : l.borrowDate)
        });
    });

    // Latest Reviews
    adminState.reviews.slice(0, 3).forEach(r => {
        const book = findBookById(r.bookId);
        activities.push({
            type: "review",
            icon: "fa-star",
            title: "New Review",
            desc: `<strong>${escapeHtml(r.userName || "Reader")}</strong> rated "${escapeHtml(book ? book.title : 'Book')}" ${'★'.repeat(r.rating || 5)}`,
            date: new Date(r.date || Date.now())
        });
    });

    // Sort by date descending
    activities.sort((a, b) => b.date - a.date);

    if (activities.length === 0) {
        container.innerHTML = `<div style="text-align:center;padding:20px;color:var(--text-muted);">No activity logs recorded yet.</div>`;
        return;
    }

    container.innerHTML = activities.slice(0, 6).map(act => `
        <div class="admin-activity-item">
            <div class="admin-activity-icon ${act.type}">
                <i class="fa-solid ${act.icon}"></i>
            </div>
            <div class="admin-activity-desc">
                ${act.desc}
            </div>
            <div class="admin-activity-time">
                ${formatRelativeTime(act.date)}
            </div>
        </div>
    `).join("");
}

// ==========================================================================
// 2. Books & Catalog Management
// ==========================================================================
function renderBooks() {
    const tbody = document.getElementById("books-table-tbody");
    const countSpan = document.getElementById("books-count-summary");
    if (!tbody) return;

    let filtered = adminState.books.filter(b => {
        const q = adminState.bookSearch.toLowerCase();
        const matchesSearch = !q || b.title.toLowerCase().includes(q) || b.author.toLowerCase().includes(q);
        const matchesGenre = adminState.bookGenre === "all" || b.genre === adminState.bookGenre;
        const matchesAvail = adminState.bookAvail === "all"
            || (adminState.bookAvail === "available" && b.available)
            || (adminState.bookAvail === "borrowed" && !b.available);
        return matchesSearch && matchesGenre && matchesAvail;
    });

    if (countSpan) countSpan.textContent = `Showing ${filtered.length} of ${adminState.books.length} books`;

    if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;padding:30px;color:var(--text-muted);">No books match the current filter criteria.</td></tr>`;
        return;
    }

    tbody.innerHTML = filtered.map(b => `
        <tr>
            <td style="font-weight:700;color:var(--text-muted);font-size:0.8rem;">#${b.id}</td>
            <td>
                <div class="book-cell">
                    <div class="book-thumb" style="background:${b.bgGradient || GRADIENTS[0]}"></div>
                    <div class="book-title-meta">
                        <span class="title">${escapeHtml(b.title)}</span>
                        <span class="author">by ${escapeHtml(b.author)}</span>
                    </div>
                </div>
            </td>
            <td><span class="genre-tag">${escapeHtml(b.genre)}</span></td>
            <td><span style="color:#f59e0b;font-weight:600;"><i class="fa-solid fa-star"></i> ${b.rating || 4.5}</span></td>
            <td>
                <span class="status-pill ${b.available ? 'status-available' : 'status-borrowed'}">
                    ${b.available ? 'Available' : 'On Loan'}
                </span>
            </td>
            <td>
                <button class="btn btn-secondary btn-sm" onclick="toggleBookStock(${b.id})" style="font-size:0.75rem;padding:4px 8px;">
                    ${b.available ? 'Mark Borrowed' : 'Mark Available'}
                </button>
            </td>
            <td>
                <div class="admin-action-btns">
                    <button class="btn-action-icon" title="Edit Book" onclick="openEditBookModal(${b.id})">
                        <i class="fa-solid fa-pen-to-square"></i>
                    </button>
                    <button class="btn-action-icon danger" title="Delete Book" onclick="confirmDeleteBook(${b.id})">
                        <i class="fa-solid fa-trash-can"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join("");
}

async function toggleBookStock(bookId) {
    const book = findBookById(bookId);
    if (!book) return;
    book.available = !book.available;
    saveData(STORAGE_KEYS.books, adminState.books);
    renderBooks();
    renderOverview();
    showToast("Status Updated", `"${book.title}" is now ${book.available ? 'Available' : 'Marked as Borrowed'}.`, "success");

    callApi('books.php?action=edit', {
        method: 'POST',
        body: JSON.stringify({
            id: book.id,
            title: book.title,
            author: book.author,
            genre: book.genre,
            rating: book.rating,
            description: book.description || '',
            available: book.available
        })
    }).catch(e => console.warn("Book stock sync notice:", e));
}

async function confirmDeleteBook(bookId) {
    const book = findBookById(bookId);
    if (!book) return;

    if (confirm(`Are you sure you want to delete "${book.title}" from the library?`)) {
        adminState.books = adminState.books.filter(b => b.id !== bookId);
        saveData(STORAGE_KEYS.books, adminState.books);
        renderBooks();
        renderOverview();
        showToast("Book Deleted", `"${book.title}" was removed from the catalog.`, "info");

        callApi('books.php?action=delete', {
            method: 'POST',
            body: JSON.stringify({ id: bookId })
        }).catch(e => console.warn("Delete book sync notice:", e));
    }
}

// ==========================================================================
// 3. Members & Users Directory
// ==========================================================================
function renderUsers() {
    const tbody = document.getElementById("users-table-tbody");
    const countSpan = document.getElementById("users-count-summary");
    if (!tbody) return;

    let filtered = adminState.users.filter(u => {
        const q = adminState.userSearch.toLowerCase();
        const matchesSearch = !q || (u.name && u.name.toLowerCase().includes(q)) || u.email.toLowerCase().includes(q);
        const matchesRole = adminState.userRole === "all"
            || (adminState.userRole === "admin" && u.role === "admin")
            || (adminState.userRole === "member" && u.role !== "admin");
        return matchesSearch && matchesRole;
    });

    if (countSpan) countSpan.textContent = `Showing ${filtered.length} of ${adminState.users.length} registered accounts`;

    if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;padding:30px;color:var(--text-muted);">No members found matching your search.</td></tr>`;
        return;
    }

    tbody.innerHTML = filtered.map(u => {
        const activeLoansCount = adminState.loans.filter(l => l.userId === u.email && l.status === "active-borrow").length;
        const isAdmin = u.role === "admin";
        return `
            <tr>
                <td>
                    <div style="display:flex;align-items:center;gap:10px;">
                        <img src="https://api.dicebear.com/7.x/bottts/svg?seed=${u.name}&backgroundColor=b6e3f4" style="width:32px;height:32px;border-radius:50%;" alt="Avatar">
                        <div>
                            <span style="font-weight:600;color:var(--text-primary);display:block;">${escapeHtml(u.name || "Member")}</span>
                            <span style="font-size:0.76rem;color:var(--text-muted);">${escapeHtml(u.email)}</span>
                        </div>
                    </div>
                </td>
                <td>${escapeHtml(u.gender || "Not specified")}</td>
                <td>
                    <span class="role-pill ${isAdmin ? 'role-admin' : 'role-member'}">
                        <i class="fa-solid ${isAdmin ? 'fa-shield-halved' : 'fa-user'}"></i>
                        ${isAdmin ? 'Administrator' : 'Member'}
                    </span>
                </td>
                <td><span style="font-weight:600;color:${activeLoansCount > 0 ? 'var(--primary)' : 'var(--text-muted)'};">${activeLoansCount} active</span></td>
                <td>••••••••</td>
                <td>
                    <div class="admin-action-btns">
                        <button class="btn btn-secondary btn-sm" onclick="promptResetPassword('${u.email}')" style="font-size:0.75rem;padding:4px 8px;">
                            <i class="fa-solid fa-key"></i> Reset Pass
                        </button>
                        ${!isAdmin ? `
                            <button class="btn-action-icon danger" title="Delete Account" onclick="confirmDeleteUser('${u.email}')">
                                <i class="fa-solid fa-user-xmark"></i>
                            </button>
                        ` : '<span style="font-size:0.72rem;color:var(--text-muted);padding:4px;">Protected</span>'}
                    </div>
                </td>
            </tr>
        `;
    }).join("");
}

async function promptResetPassword(email) {
    const user = adminState.users.find(u => u.email === email);
    if (!user) return;

    const newPass = prompt(`Enter new password for ${user.name} (${user.email}):`);
    if (!newPass) return;
    if (newPass.length < 6) {
        showToast("Error", "Password must be at least 6 characters long.", "error");
        return;
    }

    user.password = newPass;
    saveUsers(adminState.users);

    const apiRes = await apiResetPassword(email, newPass);
    if (apiRes && apiRes.success) {
        showToast("Password Reset", `Password updated in MySQL database for ${user.email}.`, "success");
    } else {
        showToast("Password Reset", `Password updated for ${user.email}.`, "success");
    }
}

async function confirmDeleteUser(email) {
    if (email === "admin@aetheria.org") {
        showToast("Forbidden", "The primary administrator account cannot be deleted.", "error");
        return;
    }

    const user = adminState.users.find(u => u.email === email);
    if (!user) return;

    if (confirm(`Are you sure you want to delete member ${user.name} (${user.email})? This action cannot be undone.`)) {
        adminState.users = adminState.users.filter(u => u.email !== email);
        saveUsers(adminState.users);
        renderUsers();
        renderOverview();
        showToast("User Removed", `Account ${email} has been removed.`, "info");

        apiDeleteUser(email).catch(e => console.warn("Delete user sync notice:", e));
    }
}

// ==========================================================================
// 4. Circulation & Loans Monitor
// ==========================================================================
function renderLoans() {
    const tbody = document.getElementById("loans-table-tbody");
    const countSpan = document.getElementById("loans-count-summary");
    if (!tbody) return;

    const now = new Date();

    let filtered = adminState.loans.filter(l => {
        const q = adminState.loanSearch.toLowerCase();
        const book = findBookById(l.bookId);
        const user = adminState.users.find(u => u.email === l.userId);

        const matchesSearch = !q
            || l.userId.toLowerCase().includes(q)
            || (user && user.name.toLowerCase().includes(q))
            || (book && book.title.toLowerCase().includes(q));

        const isOverdue = l.status === "active-borrow" && new Date(l.dueDate) < now;
        const matchesStatus = adminState.loanStatus === "all"
            || (adminState.loanStatus === "active" && l.status === "active-borrow" && !isOverdue)
            || (adminState.loanStatus === "overdue" && isOverdue)
            || (adminState.loanStatus === "returned" && l.status === "returned");

        return matchesSearch && matchesStatus;
    });

    if (countSpan) countSpan.textContent = `Showing ${filtered.length} of ${adminState.loans.length} loan records`;

    if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;padding:30px;color:var(--text-muted);">No loan records match your criteria.</td></tr>`;
        return;
    }

    tbody.innerHTML = filtered.map(l => {
        const book = findBookById(l.bookId);
        const user = adminState.users.find(u => u.email === l.userId);
        const isOverdue = l.status === "active-borrow" && new Date(l.dueDate) < now;

        let statusClass = "status-borrowed";
        let statusText = "Active Loan";
        if (l.status === "returned") {
            statusClass = "status-returned";
            statusText = "Returned";
        } else if (isOverdue) {
            statusClass = "status-overdue";
            statusText = "Overdue Alert!";
        }

        return `
            <tr>
                <td style="font-weight:700;color:var(--text-muted);font-size:0.8rem;">#${Math.floor(l.id)}</td>
                <td>
                    <span style="font-weight:600;color:var(--text-primary);display:block;">${escapeHtml(user ? user.name : l.userId)}</span>
                    <span style="font-size:0.76rem;color:var(--text-muted);">${escapeHtml(l.userId)}</span>
                </td>
                <td>
                    <span style="font-weight:600;color:var(--text-secondary);">${escapeHtml(book ? book.title : 'Book #' + l.bookId)}</span>
                </td>
                <td>${formatDate(l.borrowDate)}</td>
                <td style="color:${isOverdue ? 'var(--error)' : 'inherit'};font-weight:${isOverdue ? '700' : 'normal'};">
                    ${formatDate(l.dueDate)}
                </td>
                <td>
                    <span class="status-pill ${statusClass}">
                        ${statusText}
                    </span>
                </td>
                <td>
                    <div class="admin-action-btns">
                        ${l.status === 'active-borrow' ? `
                            <button class="btn btn-primary btn-sm" onclick="adminReturnLoan(${l.id})" style="font-size:0.75rem;padding:4px 8px;">
                                <i class="fa-solid fa-check"></i> Mark Returned
                            </button>
                            <button class="btn btn-secondary btn-sm" onclick="adminRenewLoan(${l.id})" title="Extend loan by 14 days" style="font-size:0.75rem;padding:4px 8px;">
                                <i class="fa-solid fa-clock-rotate-left"></i> +14d
                            </button>
                        ` : `<span style="font-size:0.76rem;color:var(--text-muted);">Returned on ${formatDate(l.returnDate)}</span>`}
                    </div>
                </td>
            </tr>
        `;
    }).join("");
}

async function adminReturnLoan(loanId) {
    const loan = adminState.loans.find(l => l.id.toString() === loanId.toString());
    if (!loan) return;

    loan.status = "returned";
    loan.returnDate = new Date().toISOString();

    // Mark book available in catalog
    const book = findBookById(loan.bookId);
    if (book) {
        book.available = true;
        saveData(STORAGE_KEYS.books, adminState.books);
    }

    saveData(STORAGE_KEYS.loans, adminState.loans);
    renderLoans();
    renderBooks();
    renderOverview();
    showToast("Loan Returned", `Book "${book ? book.title : 'Book'}" marked as returned and back in catalog.`, "success");

    callApi('loans.php?action=return', {
        method: 'POST',
        body: JSON.stringify({ loan_id: loan.id, book_id: loan.bookId, user_email: loan.userId })
    }).catch(e => console.warn("Admin return loan sync notice:", e));
}

function adminRenewLoan(loanId) {
    const loan = adminState.loans.find(l => l.id.toString() === loanId.toString());
    if (!loan) return;

    const currentDue = new Date(loan.dueDate);
    currentDue.setDate(currentDue.getDate() + 14);
    loan.dueDate = currentDue.toISOString();

    saveData(STORAGE_KEYS.loans, adminState.loans);
    renderLoans();
    renderOverview();
    showToast("Loan Extended", `Due date extended to ${formatDate(loan.dueDate)}.`, "success");
}

// ==========================================================================
// 5. Ratings & Reviews Moderation
// ==========================================================================
function renderReviews() {
    const tbody = document.getElementById("reviews-table-tbody");
    const countSpan = document.getElementById("reviews-count-summary");
    if (!tbody) return;

    let filtered = adminState.reviews.filter(r => {
        const q = adminState.reviewSearch.toLowerCase();
        const book = findBookById(r.bookId);
        const matchesSearch = !q
            || (r.userName && r.userName.toLowerCase().includes(q))
            || (r.text && r.text.toLowerCase().includes(q))
            || (book && book.title.toLowerCase().includes(q));

        const matchesRating = adminState.reviewRating === "all"
            || Number(r.rating) === Number(adminState.reviewRating);

        return matchesSearch && matchesRating;
    });

    if (countSpan) countSpan.textContent = `Showing ${filtered.length} of ${adminState.reviews.length} reviews`;

    if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;padding:30px;color:var(--text-muted);">No reviews submitted or matching current filter.</td></tr>`;
        return;
    }

    tbody.innerHTML = filtered.map((r, idx) => {
        const book = findBookById(r.bookId);
        const stars = '★'.repeat(Number(r.rating || 5)) + '☆'.repeat(5 - Number(r.rating || 5));
        return `
            <tr>
                <td style="font-weight:600;color:var(--text-primary);">${escapeHtml(r.userName || "Anonymous Reader")}</td>
                <td style="color:var(--text-secondary);">${escapeHtml(book ? book.title : 'Book #' + r.bookId)}</td>
                <td style="color:#f59e0b;letter-spacing:1px;font-size:1rem;">${stars}</td>
                <td style="color:var(--text-secondary);max-width:320px;font-size:0.85rem;line-height:1.4;">
                    "${escapeHtml(r.text || "No written comment.")}"
                </td>
                <td>${formatDate(r.date || new Date())}</td>
                <td>
                    <button class="btn-action-icon danger" title="Delete Review" onclick="adminDeleteReview(${idx})">
                        <i class="fa-solid fa-trash-can"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join("");
}

async function adminDeleteReview(index) {
    const review = adminState.reviews[index];
    if (confirm("Are you sure you want to delete this community review?")) {
        if (review && review.id) {
            callApi('reviews.php?action=delete', {
                method: 'POST',
                body: JSON.stringify({ id: review.id })
            }).catch(e => console.warn("Admin delete review sync notice:", e));
        }
        adminState.reviews.splice(index, 1);
        saveData(STORAGE_KEYS.reviews, adminState.reviews);
        renderReviews();
        renderOverview();
        showToast("Review Deleted", "The review has been removed.", "info");
    }
}

// ==========================================================================
// 6. Reading Activity Logs
// ==========================================================================
function renderReadingLogs() {
    const tbody = document.getElementById("reading-table-tbody");
    const countSpan = document.getElementById("reading-count-summary");
    if (!tbody) return;

    let filtered = adminState.reading.filter(r => {
        const q = adminState.readingSearch.toLowerCase();
        const book = findBookById(r.bookId);
        return !q
            || (r.userName && r.userName.toLowerCase().includes(q))
            || (r.userEmail && r.userEmail.toLowerCase().includes(q))
            || (book && book.title.toLowerCase().includes(q));
    });

    if (countSpan) countSpan.textContent = `Showing ${filtered.length} total reading sessions logged`;

    if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;padding:30px;color:var(--text-muted);">No online reading sessions logged yet. Readers open books from the Bookshelf!</td></tr>`;
        return;
    }

    tbody.innerHTML = filtered.slice().reverse().map(r => {
        const book = findBookById(r.bookId);
        return `
            <tr>
                <td style="font-weight:600;color:var(--text-primary);">${escapeHtml(r.userName || "Reader")}</td>
                <td style="color:var(--text-muted);">${escapeHtml(r.userEmail || "N/A")}</td>
                <td style="color:var(--text-secondary);font-weight:500;">${escapeHtml(book ? book.title : 'Book #' + r.bookId)}</td>
                <td><span style="font-weight:700;color:var(--primary);">${r.opens || 1} times</span></td>
                <td>${formatDate(r.lastAccessed)}</td>
            </tr>
        `;
    }).join("");
}

// ==========================================================================
// 7. Settings & Database Management
// ==========================================================================
function renderSettings() {
    document.getElementById("sys-books-count").textContent = adminState.books.length;
    document.getElementById("sys-users-count").textContent = adminState.users.length;
    document.getElementById("sys-loans-count").textContent = adminState.loans.length;
    document.getElementById("sys-reviews-count").textContent = adminState.reviews.length;
    document.getElementById("sys-reading-count").textContent = adminState.reading.length;
}

function exportDatabaseJSON() {
    const backupData = {
        exportedAt: new Date().toISOString(),
        version: "1.0",
        books: adminState.books,
        users: adminState.users,
        loans: adminState.loans,
        reviews: adminState.reviews,
        reading: adminState.reading
    };

    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(backupData, null, 2));
    const downloadAnchor = document.createElement("a");
    const dateStr = new Date().toISOString().slice(0, 10);
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `aetheria_library_backup_${dateStr}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();

    showToast("Export Complete", "Library database backup downloaded as JSON.", "success");
}

function importDatabaseJSON(fileInput) {
    const file = fileInput.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const data = JSON.parse(e.target.result);
            if (data.books && Array.isArray(data.books)) {
                adminState.books = data.books;
                saveData(STORAGE_KEYS.books, adminState.books);
            }
            if (data.users && Array.isArray(data.users)) {
                adminState.users = data.users;
                saveUsers(adminState.users);
            }
            if (data.loans && Array.isArray(data.loans)) {
                adminState.loans = data.loans;
                saveData(STORAGE_KEYS.loans, adminState.loans);
            }
            if (data.reviews && Array.isArray(data.reviews)) {
                adminState.reviews = data.reviews;
                saveData(STORAGE_KEYS.reviews, adminState.reviews);
            }
            if (data.reading && Array.isArray(data.reading)) {
                adminState.reading = data.reading;
                saveData(STORAGE_KEYS.reading, adminState.reading);
            }
            renderAll();
            showToast("Database Restored", "Library database restored from uploaded backup file.", "success");
        } catch (err) {
            showToast("Import Failed", "Invalid JSON backup file structure.", "error");
        }
    };
    reader.readAsText(file);
    fileInput.value = "";
}

function resetToFactoryDemoData() {
    if (!confirm("WARNING: This will reset all books, loans, and community reviews to factory defaults. Continue?")) return;

    localStorage.removeItem(STORAGE_KEYS.books);
    localStorage.removeItem(STORAGE_KEYS.loans);
    localStorage.removeItem(STORAGE_KEYS.reviews);
    localStorage.removeItem(STORAGE_KEYS.reading);

    loadAllData();
    renderAll();
    showToast("Reset Completed", "Library catalog and demo records restored to initial state.", "info");
}

// ==========================================================================
// Modals & Form Operations
// ==========================================================================
function setupModals() {
    // Gradient picker in Add Book modal
    const picker = document.getElementById("gradient-picker-container");
    if (picker) {
        picker.innerHTML = GRADIENTS.map((grad, i) => `
            <div class="gradient-option ${i === 0 ? 'selected' : ''}" style="background: ${grad}" onclick="selectGradient('${grad}', this)"></div>
        `).join("");
    }

    // Add Book Form
    const addBookForm = document.getElementById("add-book-form");
    if (addBookForm) {
        addBookForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const title = document.getElementById("add-book-title").value.trim();
            const author = document.getElementById("add-book-author").value.trim();
            const genre = document.getElementById("add-book-genre").value;
            const rating = parseFloat(document.getElementById("add-book-rating").value) || 4.5;
            const desc = document.getElementById("add-book-desc").value.trim();

            if (!title || !author) {
                showToast("Missing Info", "Please provide at least a book title and author.", "warning");
                return;
            }

            const newId = adminState.books.reduce((m, b) => Math.max(m, b.id || 0), 0) + 1;
            const newBook = {
                id: newId,
                title,
                author,
                genre,
                rating: Math.min(5, Math.max(1, rating)),
                description: desc || "A fascinating addition to the Aetheria literary collection.",
                available: true,
                bgGradient: adminState.selectedGradient,
                headerColor: "#f3f4f6"
            };

            adminState.books.unshift(newBook);
            saveData(STORAGE_KEYS.books, adminState.books);
            closeModal("add-book-modal");
            addBookForm.reset();
            renderBooks();
            renderOverview();
            showToast("Book Created", `"${title}" has been added to the library collection.`, "success");

            callApi('books.php?action=add', {
                method: 'POST',
                body: JSON.stringify({
                    title,
                    author,
                    genre,
                    rating,
                    description: desc,
                    available: 1,
                    gradient: adminState.selectedGradient
                })
            }).catch(e => console.warn("Add book sync notice:", e));
        });
    }

    // Edit Book Form
    const editBookForm = document.getElementById("edit-book-form");
    if (editBookForm) {
        editBookForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const bookId = adminState.editingBookId;
            const book = findBookById(bookId);
            if (!book) return;

            book.title = document.getElementById("edit-book-title").value.trim();
            book.author = document.getElementById("edit-book-author").value.trim();
            book.genre = document.getElementById("edit-book-genre").value;
            book.rating = parseFloat(document.getElementById("edit-book-rating").value) || 4.5;
            book.available = document.getElementById("edit-book-avail").value === "true";
            book.description = document.getElementById("edit-book-desc").value.trim();

            saveData(STORAGE_KEYS.books, adminState.books);
            closeModal("edit-book-modal");
            renderBooks();
            renderOverview();
            showToast("Book Updated", `Changes to "${book.title}" have been saved.`, "success");

            callApi('books.php?action=edit', {
                method: 'POST',
                body: JSON.stringify({
                    id: book.id,
                    title: book.title,
                    author: book.author,
                    genre: book.genre,
                    rating: book.rating,
                    description: book.description,
                    available: book.available
                })
            }).catch(e => console.warn("Edit book sync notice:", e));
        });
    }

    // Add Member Form
    const addUserForm = document.getElementById("add-user-form");
    if (addUserForm) {
        addUserForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const firstName = document.getElementById("add-user-firstname").value.trim();
            const lastName = document.getElementById("add-user-lastname").value.trim();
            const email = document.getElementById("add-user-email").value.trim().toLowerCase();
            const password = document.getElementById("add-user-password").value;
            const gender = document.getElementById("add-user-gender").value;
            const role = document.getElementById("add-user-role").value;

            if (adminState.users.some(u => u.email === email)) {
                showToast("Duplicate Account", "An account with this email address already exists.", "error");
                return;
            }

            const fullName = `${firstName} ${lastName}`.trim();
            const newUser = {
                name: fullName,
                firstName,
                lastName,
                email,
                password,
                gender,
                role,
                genre: "Fiction",
                avatar: "1"
            };

            adminState.users.push(newUser);
            saveUsers(adminState.users);
            closeModal("add-user-modal");
            addUserForm.reset();
            renderUsers();
            renderOverview();
            showToast("Member Registered", `Account for ${fullName} created successfully.`, "success");

            // Insert into MySQL with email as PRIMARY KEY
            apiCreateUser(newUser).then(res => {
                if (res && res.success) {
                    showToast("MySQL Synced", `Account for ${fullName} saved to MySQL database.`, "info");
                }
            }).catch(e => console.warn("Add user sync notice:", e));
        });
    }
}

function selectGradient(gradient, element) {
    adminState.selectedGradient = gradient;
    document.querySelectorAll(".gradient-option").forEach(el => el.classList.remove("selected"));
    if (element) element.classList.add("selected");
}

function openAddBookModal() {
    openModal("add-book-modal");
}

function openEditBookModal(bookId) {
    const book = findBookById(bookId);
    if (!book) return;

    adminState.editingBookId = bookId;
    document.getElementById("edit-book-title").value = book.title;
    document.getElementById("edit-book-author").value = book.author;
    document.getElementById("edit-book-genre").value = book.genre;
    document.getElementById("edit-book-rating").value = book.rating;
    document.getElementById("edit-book-avail").value = book.available ? "true" : "false";
    document.getElementById("edit-book-desc").value = book.description || "";

    openModal("edit-book-modal");
}

function openAddUserModal() {
    openModal("add-user-modal");
}

function openModal(id) {
    const modal = document.getElementById(id);
    if (modal) modal.classList.remove("hidden");
}

function closeModal(id) {
    const modal = document.getElementById(id);
    if (modal) modal.classList.add("hidden");
}

// ==========================================================================
// Filter Listeners Setup
// ==========================================================================
function setupFilters() {
    // Books filter
    const bookSearch = document.getElementById("book-search-input");
    const bookGenre = document.getElementById("book-genre-filter");
    const bookAvail = document.getElementById("book-avail-filter");

    if (bookSearch) bookSearch.addEventListener("input", (e) => {
        adminState.bookSearch = e.target.value.trim();
        renderBooks();
    });
    if (bookGenre) bookGenre.addEventListener("change", (e) => {
        adminState.bookGenre = e.target.value;
        renderBooks();
    });
    if (bookAvail) bookAvail.addEventListener("change", (e) => {
        adminState.bookAvail = e.target.value;
        renderBooks();
    });

    // Users filter
    const userSearch = document.getElementById("user-search-input");
    const userRole = document.getElementById("user-role-filter");

    if (userSearch) userSearch.addEventListener("input", (e) => {
        adminState.userSearch = e.target.value.trim();
        renderUsers();
    });
    if (userRole) userRole.addEventListener("change", (e) => {
        adminState.userRole = e.target.value;
        renderUsers();
    });

    // Loans filter
    const loanSearch = document.getElementById("loan-search-input");
    const loanStatus = document.getElementById("loan-status-filter");

    if (loanSearch) loanSearch.addEventListener("input", (e) => {
        adminState.loanSearch = e.target.value.trim();
        renderLoans();
    });
    if (loanStatus) loanStatus.addEventListener("change", (e) => {
        adminState.loanStatus = e.target.value;
        renderLoans();
    });

    // Reviews filter
    const reviewSearch = document.getElementById("review-search-input");
    const reviewRating = document.getElementById("review-rating-filter");

    if (reviewSearch) reviewSearch.addEventListener("input", (e) => {
        adminState.reviewSearch = e.target.value.trim();
        renderReviews();
    });
    if (reviewRating) reviewRating.addEventListener("change", (e) => {
        adminState.reviewRating = e.target.value;
        renderReviews();
    });

    // Reading filter
    const readingSearch = document.getElementById("reading-search-input");
    if (readingSearch) readingSearch.addEventListener("input", (e) => {
        adminState.readingSearch = e.target.value.trim();
        renderReadingLogs();
    });
}

// ==========================================================================
// Helpers & Fallback Seeds
// ==========================================================================
function findBookById(id) {
    return adminState.books.find(b => b.id === Number(id));
}

function formatDate(dateString) {
    if (!dateString) return "N/A";
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return "N/A";
    return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

function formatRelativeTime(date) {
    const d = new Date(date);
    if (isNaN(d.getTime())) return "Recently";
    const diff = Math.floor((new Date() - d) / 1000);
    if (diff < 60) return "Just now";
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return `${Math.floor(diff / 86400)}d ago`;
}

function escapeHtml(str) {
    if (typeof str !== "string") return "";
    return str.replace(/[&<>"']/g, c => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[c]));
}

function getSeedBooks() {
    return [
        {
            id: 1,
            title: "Dune",
            author: "Frank Herbert",
            genre: "Sci-Fi & Fantasy",
            description: "Set on the desert planet Arrakis, Dune is the story of the boy Paul Atreides, heir to a noble family tasked with ruling an inhospitable world where the only thing of value is the spice melange.",
            rating: 4.9,
            available: true,
            bgGradient: "linear-gradient(135deg, #c27d38, #5e3a15)",
            headerColor: "#f3f4f6"
        },
        {
            id: 2,
            title: "Neuromancer",
            author: "William Gibson",
            genre: "Sci-Fi & Fantasy",
            description: "Case, a low-level computer hacker, is hired by a mysterious employer to pull off the ultimate hack against a powerful artificial intelligence.",
            rating: 4.7,
            available: true,
            bgGradient: "linear-gradient(135deg, #0f172a, #06b6d4)",
            headerColor: "#67e8f9"
        },
        {
            id: 3,
            title: "The Shadow of the Wind",
            author: "Carlos Ruiz Zafón",
            genre: "Mystery & Thriller",
            description: "In the ruins of Barcelona, Daniel Sempere is taken to the Cemetery of Forgotten Books, where he selects a novel that changes the course of his life.",
            rating: 4.8,
            available: true,
            bgGradient: "linear-gradient(135deg, #3730a3, #4338ca)",
            headerColor: "#e0e7ff"
        },
        {
            id: 4,
            title: "Sapiens: A Brief History",
            author: "Yuval Noah Harari",
            genre: "History & Biography",
            description: "Dr Yuval Noah Harari spans the whole of human history, from the very first humans to walk the earth to the radical breakthroughs of the Cognitive revolution.",
            rating: 4.6,
            available: true,
            bgGradient: "linear-gradient(135deg, #78350f, #b45309)",
            headerColor: "#fef3c7"
        },
        {
            id: 5,
            title: "Clean Code",
            author: "Robert C. Martin",
            genre: "Technology & Science",
            description: "Even bad code can function. But if code isn't clean, it can bring a development organization to its knees. This book teaches you how to write software well.",
            rating: 4.8,
            available: true,
            bgGradient: "linear-gradient(135deg, #065f46, #059669)",
            headerColor: "#d1fae5"
        },
        {
            id: 6,
            title: "Meditations",
            author: "Marcus Aurelius",
            genre: "Philosophy & Psychology",
            description: "The private reflections of the Roman Emperor Marcus Aurelius offering profound insights into the human condition, resilience, and virtue.",
            rating: 4.9,
            available: true,
            bgGradient: "linear-gradient(135deg, #701a75, #ec4899)",
            headerColor: "#fce7f3"
        }
    ];
}

function getSeedLoans() {
    return [
        {
            id: 1001,
            userId: "demo@aetheria.org",
            bookId: 1,
            borrowDate: new Date(Date.now() - 5 * 86400000).toISOString(),
            dueDate: new Date(Date.now() + 9 * 86400000).toISOString(),
            returnDate: null,
            status: "active-borrow"
        },
        {
            id: 1002,
            userId: "demo@aetheria.org",
            bookId: 3,
            borrowDate: new Date(Date.now() - 22 * 86400000).toISOString(),
            dueDate: new Date(Date.now() - 8 * 86400000).toISOString(),
            returnDate: null,
            status: "active-borrow"
        },
        {
            id: 1003,
            userId: "demo@aetheria.org",
            bookId: 5,
            borrowDate: new Date(Date.now() - 30 * 86400000).toISOString(),
            dueDate: new Date(Date.now() - 16 * 86400000).toISOString(),
            returnDate: new Date(Date.now() - 15 * 86400000).toISOString(),
            status: "returned"
        }
    ];
}

function getSeedReviews() {
    return [
        {
            bookId: 1,
            userId: "demo@aetheria.org",
            userName: "Arthur Pendragon",
            rating: 5,
            text: "An absolute masterpiece of worldbuilding and ecological foresight. Required reading for everyone.",
            date: new Date(Date.now() - 3 * 86400000).toISOString()
        },
        {
            bookId: 5,
            userId: "demo@aetheria.org",
            userName: "Arthur Pendragon",
            rating: 5,
            text: "Transformed how I structure software architecture. Every chapter is golden.",
            date: new Date(Date.now() - 12 * 86400000).toISOString()
        }
    ];
}
