/* ==========================================================================
   Aetheria Library — Common Authentication & MySQL API Utilities
   Communicates with MySQL backend via PHP endpoints, with LocalStorage sync.
   User Primary Key in MySQL: email
   ========================================================================== */

const DEFAULT_USERS = [
    {
        email: "demo@aetheria.org",
        password: "password123",
        name: "Arthur Pendragon",
        firstName: "Arthur",
        lastName: "Pendragon",
        gender: "Male",
        genre: "Sci-Fi & Fantasy",
        avatar: "1",
        role: "member"
    }
];

// Hard-coded administrator account (single admin per spec)
const ADMIN_ACCOUNT = {
    email: "admin@aetheria.org",
    password: "admin123",
    name: "Aetheria Admin",
    firstName: "Aetheria",
    lastName: "Admin",
    gender: "Other",
    genre: "Technology & Science",
    avatar: "1",
    role: "admin"
};

// ==========================================================================
// MySQL Backend API Bridge
// ==========================================================================
function getApiUrl(endpoint) {
    const isInsideAdmin = window.location.pathname.includes('/admin/') || 
                          window.location.href.includes('/admin/login.html') ||
                          window.location.href.includes('/admin/index.html');
    const base = isInsideAdmin ? '../api/' : 'api/';
    return base + endpoint;
}

/**
 * Universal async API caller for PHP + MySQL backend.
 * Gracefully handles offline / file:// protocol setups by falling back to localStorage.
 */
async function callApi(endpoint, options = {}) {
    // If running directly as local file without web server, return fallback
    if (window.location.protocol === 'file:') {
        return { isLocalFile: true, success: false, error: "Running on file:// protocol. MySQL requires PHP web server (e.g. Apache/XAMPP)." };
    }

    try {
        const url = getApiUrl(endpoint);
        const headers = Object.assign({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }, options.headers || {});

        const response = await fetch(url, {
            ...options,
            headers
        });

        const data = await response.json().catch(() => null);
        if (!data) {
            return { success: false, error: `Invalid server response (HTTP ${response.status})` };
        }
        return data;
    } catch (err) {
        console.warn("MySQL PHP API not reached, using local fallback:", err);
        return { success: false, networkError: true, error: err.message };
    }
}

/**
 * Sign In / Authenticate via MySQL
 */
async function apiLogin(email, password) {
    const res = await callApi('auth.php?action=login', {
        method: 'POST',
        body: JSON.stringify({ email, password })
    });
    return res;
}

/**
 * Register new user into MySQL (email is PRIMARY KEY)
 */
async function apiSignup(userData) {
    const res = await callApi('auth.php?action=signup', {
        method: 'POST',
        body: JSON.stringify(userData)
    });
    return res;
}

/**
 * Reset password in MySQL using email as PRIMARY KEY
 */
async function apiResetPassword(email, password) {
    const res = await callApi('auth.php?action=reset_password', {
        method: 'POST',
        body: JSON.stringify({ email, password })
    });
    return res;
}

/**
 * Fetch users list from MySQL
 */
async function apiGetUsers(search = '', role = 'all') {
    const query = new URLSearchParams({ search, role }).toString();
    const res = await callApi(`users.php?${query}`, { method: 'GET' });
    return res;
}

/**
 * Admin create user in MySQL
 */
async function apiCreateUser(userData) {
    const res = await callApi('users.php?action=create', {
        method: 'POST',
        body: JSON.stringify(userData)
    });
    return res;
}

/**
 * Update user profile in MySQL by email
 */
async function apiUpdateProfile(email, profileData) {
    const res = await callApi('users.php?action=update_profile', {
        method: 'POST',
        body: JSON.stringify({ email, ...profileData })
    });
    return res;
}

/**
 * Delete user from MySQL by email (PRIMARY KEY)
 */
async function apiDeleteUser(email) {
    const res = await callApi('users.php?action=delete', {
        method: 'POST',
        body: JSON.stringify({ email })
    });
    return res;
}

// ==========================================================================
// Local Storage Session & Client-side Helpers
// ==========================================================================

// Ensure the administrator account is always present in the user list
function ensureAdminAccount(users) {
    if (!users.some(u => u.email === ADMIN_ACCOUNT.email)) {
        users.push({ ...ADMIN_ACCOUNT });
    } else {
        const admin = users.find(u => u.email === ADMIN_ACCOUNT.email);
        admin.role = "admin";
    }
    return users;
}

// Load registered users from LocalStorage cache
function getUsers() {
    let users;
    try {
        const storedUsers = localStorage.getItem("aetheria_users");
        users = storedUsers ? JSON.parse(storedUsers) : [...DEFAULT_USERS];
    } catch (e) {
        console.error("Error reading users from LocalStorage:", e);
        users = [...DEFAULT_USERS];
    }
    ensureAdminAccount(users);
    localStorage.setItem("aetheria_users", JSON.stringify(users));
    return users;
}

// Save registered users to LocalStorage cache
function saveUsers(users) {
    try {
        localStorage.setItem("aetheria_users", JSON.stringify(users));
    } catch (e) {
        console.error("Error saving users to LocalStorage:", e);
    }
}

// Get logged-in active user
function getActiveUser() {
    try {
        const activeUser = localStorage.getItem("aetheria_active_user");
        if (activeUser) {
            return JSON.parse(activeUser);
        }
    } catch (e) {
        console.error("Error reading active user from LocalStorage:", e);
    }
    return null;
}

// Set active user session
function setActiveUser(user) {
    try {
        localStorage.setItem("aetheria_active_user", JSON.stringify(user));
    } catch (e) {
        console.error("Error saving active user to LocalStorage:", e);
    }
}

// Clear active user session
function clearActiveUser() {
    localStorage.removeItem("aetheria_active_user");
}

// Toast Notification Engine
function showToast(title, message, type = "success") {
    const container = document.getElementById("toast-container");
    if (!container) return;

    let iconClass = "fa-solid fa-circle-check";
    if (type === "error") iconClass = "fa-solid fa-triangle-exclamation";
    if (type === "warning") iconClass = "fa-solid fa-circle-exclamation";
    if (type === "info") iconClass = "fa-solid fa-circle-info";

    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <i class="${iconClass} toast-icon"></i>
        <div class="toast-content">
            <div class="toast-title">${title}</div>
            <div class="toast-message">${message}</div>
        </div>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.style.animation = "fadeIn 0.3s ease reverse forwards";
        setTimeout(() => {
            toast.remove();
        }, 300);
    }, 4000);
}

// Password toggler helper
function togglePasswordVisibility(fieldId) {
    const input = document.getElementById(fieldId);
    if (!input) return;
    const button = input.nextElementSibling;
    const icon = button ? button.querySelector("i") : null;
    
    if (input.type === "password") {
        input.type = "text";
        if (icon) icon.className = "fa-solid fa-eye-slash";
    } else {
        input.type = "password";
        if (icon) icon.className = "fa-solid fa-eye";
    }
}
