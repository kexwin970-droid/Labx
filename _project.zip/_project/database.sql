-- =============================================================================
-- Aetheria Library — MySQL Database Schema & Initial Data
-- Database: aetheria_db
-- Primary Key for users: email (as required for reset password & identification)
-- =============================================================================

CREATE DATABASE IF NOT EXISTS `aetheria_db` 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE `aetheria_db`;

-- -----------------------------------------------------------------------------
-- 1. Table: users
-- Primary Key: email (VARCHAR 191 to safely support utf8mb4 index limits)
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `reading_logs`;
DROP TABLE IF EXISTS `reviews`;
DROP TABLE IF EXISTS `loans`;
DROP TABLE IF EXISTS `books`;
DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
    `email` VARCHAR(191) NOT NULL PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL,
    `first_name` VARCHAR(100) NOT NULL,
    `last_name` VARCHAR(100) DEFAULT '',
    `password` VARCHAR(255) NOT NULL,
    `gender` ENUM('Male', 'Female', 'Other') DEFAULT 'Other',
    `role` ENUM('member', 'admin') DEFAULT 'member',
    `genre` VARCHAR(100) DEFAULT 'Fiction',
    `avatar` VARCHAR(50) DEFAULT '1',
    `phone` VARCHAR(50) DEFAULT '',
    `bio` TEXT DEFAULT NULL,
    `premium` TINYINT(1) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 2. Table: books
-- -----------------------------------------------------------------------------
CREATE TABLE `books` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `title` VARCHAR(255) NOT NULL,
    `author` VARCHAR(255) NOT NULL,
    `genre` VARCHAR(100) NOT NULL,
    `rating` DECIMAL(2,1) DEFAULT 4.5,
    `available` TINYINT(1) DEFAULT 1,
    `gradient` VARCHAR(255) DEFAULT 'linear-gradient(135deg, #0f172a, #06b6d4)',
    `description` TEXT,
    `isbn` VARCHAR(50) DEFAULT '',
    `pages` INT DEFAULT 300,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 3. Table: loans
-- Foreign Keys: user_email -> users(email), book_id -> books(id)
-- -----------------------------------------------------------------------------
CREATE TABLE `loans` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_email` VARCHAR(191) NOT NULL,
    `book_id` INT NOT NULL,
    `borrow_date` DATETIME NOT NULL,
    `due_date` DATETIME NOT NULL,
    `return_date` DATETIME DEFAULT NULL,
    `status` ENUM('active-borrow', 'returned', 'overdue') DEFAULT 'active-borrow',
    CONSTRAINT `fk_loans_user_email` 
        FOREIGN KEY (`user_email`) REFERENCES `users` (`email`) 
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_loans_book_id` 
        FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) 
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 4. Table: reviews
-- -----------------------------------------------------------------------------
CREATE TABLE `reviews` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_email` VARCHAR(191) NOT NULL,
    `book_id` INT NOT NULL,
    `user_name` VARCHAR(255) NOT NULL,
    `rating` INT NOT NULL,
    `text` TEXT NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_reviews_user_email` 
        FOREIGN KEY (`user_email`) REFERENCES `users` (`email`) 
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_reviews_book_id` 
        FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) 
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- 5. Table: reading_logs
-- -----------------------------------------------------------------------------
CREATE TABLE `reading_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_email` VARCHAR(191) NOT NULL,
    `book_id` INT NOT NULL,
    `book_title` VARCHAR(255) NOT NULL,
    `started_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `status` VARCHAR(50) DEFAULT 'reading',
    CONSTRAINT `fk_reading_user_email` 
        FOREIGN KEY (`user_email`) REFERENCES `users` (`email`) 
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_reading_book_id` 
        FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) 
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================================================
-- Initial Seed Data
-- =============================================================================

-- Seed Users (Demo Admin and Demo Readers with email as PRIMARY KEY)
INSERT INTO `users` (`email`, `name`, `first_name`, `last_name`, `password`, `gender`, `role`, `genre`, `avatar`, `created_at`) VALUES
('admin@aetheria.org', 'Aetheria Admin', 'Aetheria', 'Admin', 'admin123', 'Other', 'admin', 'Technology & Science', '1', NOW()),
('demo@aetheria.org', 'Arthur Pendragon', 'Arthur', 'Pendragon', 'password123', 'Male', 'member', 'Sci-Fi & Fantasy', '1', NOW()),
('elena.rostova@literary.net', 'Elena Rostova', 'Elena', 'Rostova', 'password123', 'Female', 'member', 'Fiction', '2', NOW()),
('marcus.vane@archive.org', 'Marcus Vane', 'Marcus', 'Vane', 'password123', 'Male', 'member', 'History & Biography', '3', NOW());

-- Seed Books
INSERT INTO `books` (`id`, `title`, `author`, `genre`, `rating`, `available`, `gradient`, `description`, `isbn`, `pages`) VALUES
(1, 'The Midnight Library', 'Matt Haig', 'Fiction', 4.8, 1, 'linear-gradient(135deg, #0f172a, #06b6d4)', 'Between life and death there is a library with infinite shelves of infinite books, each representing a life you could have lived.', '978-0525559474', 304),
(2, 'Project Hail Mary', 'Andy Weir', 'Sci-Fi & Fantasy', 4.9, 1, 'linear-gradient(135deg, #3730a3, #4338ca)', 'A lone astronaut must save the earth from an astronomical disaster with the help of an unexpected extraterrestrial ally.', '978-0593135204', 496),
(3, 'Clean Code', 'Robert C. Martin', 'Technology & Science', 4.7, 0, 'linear-gradient(135deg, #064e3b, #34d399)', 'A handbook of agile software craftsmanship teaching how to write clean, maintainable, and elegant software.', '978-0132350884', 464),
(4, 'Sapiens: A Brief History', 'Yuval Noah Harari', 'History & Biography', 4.6, 1, 'linear-gradient(135deg, #78350f, #b45309)', 'Explore how humankind evolved from unremarkable apes to rulers of the planet earth.', '978-0062316097', 464),
(5, 'The Silent Patient', 'Alex Michaelides', 'Mystery & Thriller', 4.5, 1, 'linear-gradient(135deg, #7f1d1d, #ef4444)', 'A shocking psychological thriller of a woman’s act of violence against her husband, and of the therapist obsessed with uncovering her motive.', '978-1250301696', 336),
(6, 'Atomic Habits', 'James Clear', 'Philosophy & Psychology', 4.9, 1, 'linear-gradient(135deg, #701a75, #ec4899)', 'An easy and proven way to build good habits and break bad ones through 1% daily compounding.', '978-0735211292', 320),
(7, 'Dune', 'Frank Herbert', 'Sci-Fi & Fantasy', 4.7, 1, 'linear-gradient(135deg, #c27d38, #5e3a15)', 'Set on the desert planet Arrakis, Dune tells the story of the boy Paul Atreides, heir to a noble family tasked with ruling an inhospitable world.', '978-0441013593', 688),
(8, 'The Psychology of Money', 'Morgan Housel', 'Philosophy & Psychology', 4.8, 1, 'linear-gradient(135deg, #1e293b, #475569)', 'Timeless lessons on wealth, greed, and happiness doing well with money isn’t necessarily about what you know.', '978-0857197689', 256),
(9, 'A Brief History of Time', 'Stephen Hawking', 'Technology & Science', 4.6, 0, 'linear-gradient(135deg, #0f172a, #06b6d4)', 'A landmark volume in science writing by one of the great minds of our time, exploring black holes and cosmological origins.', '978-0553380163', 220),
(10, 'Educated', 'Tara Westover', 'History & Biography', 4.7, 1, 'linear-gradient(135deg, #78350f, #b45309)', 'An unforgettable memoir about a young girl who kept out of school leaves her survivalist family and goes on to earn a PhD from Cambridge.', '978-0399590504', 352);

-- Seed Loans
INSERT INTO `loans` (`id`, `user_email`, `book_id`, `borrow_date`, `due_date`, `return_date`, `status`) VALUES
(1001, 'demo@aetheria.org', 1, DATE_SUB(NOW(), INTERVAL 5 DAY), DATE_ADD(NOW(), INTERVAL 9 DAY), NULL, 'active-borrow'),
(1002, 'demo@aetheria.org', 3, DATE_SUB(NOW(), INTERVAL 22 DAY), DATE_SUB(NOW(), INTERVAL 8 DAY), NULL, 'active-borrow'),
(1003, 'elena.rostova@literary.net', 9, DATE_SUB(NOW(), INTERVAL 14 DAY), DATE_ADD(NOW(), INTERVAL 0 DAY), NULL, 'active-borrow'),
(1004, 'marcus.vane@archive.org', 4, DATE_SUB(NOW(), INTERVAL 30 DAY), DATE_SUB(NOW(), INTERVAL 16 DAY), DATE_SUB(NOW(), INTERVAL 17 DAY), 'returned');

-- Seed Reviews
INSERT INTO `reviews` (`user_email`, `book_id`, `user_name`, `rating`, `text`, `created_at`) VALUES
('demo@aetheria.org', 1, 'Arthur Pendragon', 5, 'An evocative exploration of second chances and quiet wonders. The concept of infinite choices is deeply moving.', DATE_SUB(NOW(), INTERVAL 4 DAY)),
('elena.rostova@literary.net', 2, 'Elena Rostova', 5, 'Andy Weir delivers again! Rocky is one of my favorite literary characters in modern science fiction. Truly exceptional.', DATE_SUB(NOW(), INTERVAL 2 DAY)),
('marcus.vane@archive.org', 6, 'Marcus Vane', 5, 'The 1% rule changed my daily workflow. Extremely practical handbook on habit building.', DATE_SUB(NOW(), INTERVAL 7 DAY));

-- Seed Reading Logs
INSERT INTO `reading_logs` (`user_email`, `book_id`, `book_title`, `started_at`, `status`) VALUES
('demo@aetheria.org', 1, 'The Midnight Library', DATE_SUB(NOW(), INTERVAL 5 DAY), 'reading'),
('demo@aetheria.org', 3, 'Clean Code', DATE_SUB(NOW(), INTERVAL 22 DAY), 'reading'),
('elena.rostova@literary.net', 9, 'A Brief History of Time', DATE_SUB(NOW(), INTERVAL 14 DAY), 'reading');
