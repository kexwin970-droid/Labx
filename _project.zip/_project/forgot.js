/* ==========================================================================
   Aetheria Library — Forgot / Reset Password Controller
   Resets password in MySQL database using email as the PRIMARY KEY.
   PHP Endpoint: api/auth.php?action=reset_password
   ========================================================================== */

document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("forgot-form");
    if (!form) return;

    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        const email = document.getElementById("forgot-email").value.trim().toLowerCase();
        const password = document.getElementById("forgot-password").value;
        const confirm = document.getElementById("forgot-confirm").value;

        // 1. Basic field validation
        if (!email) {
            showToast("Missing Email", "Please enter your account email address.", "error");
            return;
        }

        if (password.length < 6) {
            showToast("Weak Password", "Your new password must be at least 6 characters.", "warning");
            return;
        }

        if (password !== confirm) {
            showToast("Passwords Do Not Match", "Please make sure both password fields are identical.", "error");
            return;
        }

        // 2. Call MySQL backend to reset password using email as PRIMARY KEY
        const apiRes = await apiResetPassword(email, password);

        if (apiRes && apiRes.success) {
            // Also synchronize local storage cache
            const users = getUsers();
            const user = users.find(u => u.email.toLowerCase() === email);
            if (user) {
                user.password = password;
                saveUsers(users);
            }

            showToast("Password Updated", "Your password has been successfully reset in MySQL database. Redirecting...", "success");

            setTimeout(() => {
                window.location.href = "login.html";
            }, 1200);
            return;
        }

        // 3. Fallback if running offline or on file:// protocol
        if (apiRes && (apiRes.isLocalFile || apiRes.networkError)) {
            const users = getUsers();
            const user = users.find(u => u.email.toLowerCase() === email);

            if (!user) {
                showToast("Account Not Found", "No registered account exists with this email address.", "error");
                return;
            }

            user.password = password;
            saveUsers(users);

            showToast("Password Updated", "Your password has been reset. Redirecting to sign in...", "success");

            setTimeout(() => {
                window.location.href = "login.html";
            }, 1200);
            return;
        }

        // Display error returned from MySQL
        const errorMsg = (apiRes && apiRes.error) ? apiRes.error : "Failed to reset password. Please check your email address.";
        showToast("Reset Failed", errorMsg, "error");
    });
});
