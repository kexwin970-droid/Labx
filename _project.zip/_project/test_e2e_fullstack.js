/**
 * Comprehensive Full-Stack End-to-End Verification Test
 * Tests all 14 requirements specified in the user request.
 */
const http = require('http');

function request(options, data) {
    return new Promise((resolve, reject) => {
        const req = http.request(options, (res) => {
            let body = '';
            res.on('data', chunk => body += chunk);
            res.on('end', () => {
                let parsed = null;
                try { parsed = JSON.parse(body); } catch (e) { parsed = body; }
                resolve({ status: res.statusCode, headers: res.headers, body: parsed });
            });
        });
        req.on('error', reject);
        if (data) {
            req.write(typeof data === 'string' ? data : JSON.stringify(data));
        }
        req.end();
    });
}

async function runTests() {
    console.log('====================================================');
    console.log('🚀 RUNNING COMPREHENSIVE E2E VERIFICATION SUITE');
    console.log('====================================================\n');

    let passed = 0;
    let failed = 0;

    function assert(cond, name, details = '') {
        if (cond) {
            console.log(`✅ [PASS] ${name}`);
            passed++;
        } else {
            console.error(`❌ [FAIL] ${name} ${details ? '- ' + details : ''}`);
            failed++;
        }
    }

    try {
        // 1. Demo Member Login
        console.log('--- Test 1: Demo Member Login ---');
        const demoLogin = await request({
            hostname: 'localhost',
            port: 3000,
            path: '/api/auth/login',
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        }, { identifier: 'demo@example.com', password: 'Demo@123' });

        assert(demoLogin.status === 200 && demoLogin.body.success, 'Demo user can log in with demo@example.com / Demo@123');
        assert(demoLogin.body.data && demoLogin.body.data.token, 'Demo user receives valid JWT token');
        const demoToken = demoLogin.body.data ? demoLogin.body.data.token : null;
        const demoUser = demoLogin.body.data ? demoLogin.body.data.user : null;

        // Also test login by username: 'demo'
        const demoUsernameLogin = await request({
            hostname: 'localhost',
            port: 3000,
            path: '/api/auth/login',
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        }, { identifier: 'demo', password: 'Demo@123' });
        assert(demoUsernameLogin.status === 200 && demoUsernameLogin.body.success, 'Demo user can log in using username "demo"');

        // 2. Demo Admin Login
        console.log('\n--- Test 2: Demo Admin Login ---');
        const adminLogin = await request({
            hostname: 'localhost',
            port: 3000,
            path: '/api/auth/login',
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        }, { identifier: 'admin@example.com', password: 'Admin@123' });

        assert(adminLogin.status === 200 && adminLogin.body.success, 'Demo admin can log in with admin@example.com / Admin@123');
        assert(adminLogin.body.data && adminLogin.body.data.user.role === 'admin', 'Admin user role is verified as "admin"');
        const adminToken = adminLogin.body.data ? adminLogin.body.data.token : null;

        // Also test admin login by username 'admin'
        const adminUsernameLogin = await request({
            hostname: 'localhost',
            port: 3000,
            path: '/api/auth/login',
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        }, { identifier: 'admin', password: 'Admin@123' });
        assert(adminUsernameLogin.status === 200 && adminUsernameLogin.body.success, 'Demo admin can log in using username "admin"');

        // 3. New User Registration creates a MySQL record
        console.log('\n--- Test 3: New User Registration ---');
        const testUserEmail = `tester_${Date.now()}@example.com`;
        const testUsername = `tester_${Date.now()}`;
        const regRes = await request({
            hostname: 'localhost',
            port: 3000,
            path: '/api/auth/register',
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        }, {
            username: testUsername,
            email: testUserEmail,
            password: 'Password@123',
            name: 'Test Reader',
            firstName: 'Test',
            lastName: 'Reader',
            gender: 'Female'
        });

        assert(regRes.status === 201 && regRes.body.success, 'New user registration succeeds and creates database record');
        assert(regRes.body.data && regRes.body.data.user.email === testUserEmail, 'Registration returns created user profile');
        const newUserId = regRes.body.data ? regRes.body.data.user.id : null;
        const newUserToken = regRes.body.data ? regRes.body.data.token : null;

        // 4. User Login Validates Against MySQL
        console.log('\n--- Test 4: User Login Validates Against MySQL ---');
        const newLoginRes = await request({
            hostname: 'localhost',
            port: 3000,
            path: '/api/auth/login',
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        }, { identifier: testUserEmail, password: 'Password@123' });
        assert(newLoginRes.status === 200 && newLoginRes.body.success, 'Newly registered user can log in');

        // Invalid login check
        const badLoginRes = await request({
            hostname: 'localhost',
            port: 3000,
            path: '/api/auth/login',
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        }, { identifier: testUserEmail, password: 'WrongPassword' });
        assert(badLoginRes.status === 401 && !badLoginRes.body.success, 'Invalid password is rejected with HTTP 401');

        // 5. Profile changes update MySQL
        console.log('\n--- Test 5: Profile Update Updates MySQL ---');
        const updateRes = await request({
            hostname: 'localhost',
            port: 3000,
            path: '/api/auth/profile',
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${newUserToken}`
            }
        }, {
            name: 'Updated Reader Name',
            firstName: 'Updated',
            lastName: 'Reader',
            gender: 'Other',
            bio: 'Avid sci-fi reader'
        });
        assert(updateRes.status === 200 && updateRes.body.success, 'Profile updated successfully via REST API');

        // Fetch /api/auth/me to verify persistence
        const meRes = await request({
            hostname: 'localhost',
            port: 3000,
            path: '/api/auth/me',
            method: 'GET',
            headers: { 'Authorization': `Bearer ${newUserToken}` }
        });
        assert(meRes.status === 200 && meRes.body.data.name === 'Updated Reader Name', 'Updated profile retrieved persistently from database');

        // 6. Admin can see newly registered users
        console.log('\n--- Test 6: Admin Sees Newly Registered Users ---');
        const adminUsersRes = await request({
            hostname: 'localhost',
            port: 3000,
            path: '/api/users',
            method: 'GET',
            headers: { 'Authorization': `Bearer ${adminToken}` }
        });
        assert(adminUsersRes.status === 200 && Array.isArray(adminUsersRes.body.data), 'Admin GET /api/users returns list of users');
        const foundNewUser = adminUsersRes.body.data.find(u => u.email === testUserEmail);
        assert(!!foundNewUser, 'Newly registered user is visible in admin directory');

        // 7. Admin changes are reflected in user account
        console.log('\n--- Test 7: Admin Changes Reflected in Database ---');
        const statusRes = await request({
            hostname: 'localhost',
            port: 3000,
            path: `/api/users/${newUserId}/status`,
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${adminToken}`
            }
        }, { status: 'disabled' });
        assert(statusRes.status === 200 && statusRes.body.success, 'Admin can update user status to disabled');

        // 8. Disabled users cannot authenticate
        console.log('\n--- Test 8: Disabled User Authentication Check ---');
        const disabledLoginRes = await request({
            hostname: 'localhost',
            port: 3000,
            path: '/api/auth/login',
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        }, { identifier: testUserEmail, password: 'Password@123' });
        assert(disabledLoginRes.status === 403 && !disabledLoginRes.body.success, 'Disabled user cannot log in (HTTP 403 Account Disabled)');

        // Re-enable user
        await request({
            hostname: 'localhost',
            port: 3000,
            path: `/api/users/${newUserId}/status`,
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${adminToken}`
            }
        }, { status: 'active' });

        // 9. Activity logs are generated correctly
        console.log('\n--- Test 9: Activity and Audit Logging ---');
        const logsRes = await request({
            hostname: 'localhost',
            port: 3000,
            path: '/api/admin/activity-logs',
            method: 'GET',
            headers: { 'Authorization': `Bearer ${adminToken}` }
        });
        assert(logsRes.status === 200 && Array.isArray(logsRes.body.data), 'Admin can retrieve activity logs from database');
        const hasLoginLog = logsRes.body.data.some(l => l.action.includes('LOGIN'));
        const hasRegisterLog = logsRes.body.data.some(l => l.action === 'USER_REGISTER');
        const hasStatusLog = logsRes.body.data.some(l => l.action === 'USER_STATUS_CHANGE');
        assert(hasLoginLog && hasRegisterLog && hasStatusLog, 'Audit logs properly record logins, registrations, and status changes');

        // 10. Logout invalidates session
        console.log('\n--- Test 10: Logout Invalidation ---');
        const logoutRes = await request({
            hostname: 'localhost',
            port: 3000,
            path: '/api/auth/logout',
            method: 'POST',
            headers: { 'Authorization': `Bearer ${newUserToken}` }
        });
        assert(logoutRes.status === 200 && logoutRes.body.success, 'User logout API succeeds');

        // 11. Unauthorized users cannot access admin APIs
        console.log('\n--- Test 11: Unauthorized Access Prevention ---');
        const unauthDashRes = await request({
            hostname: 'localhost',
            port: 3000,
            path: '/api/admin/dashboard',
            method: 'GET',
            headers: { 'Authorization': `Bearer ${demoToken}` } // demo member token, not admin
        });
        assert(unauthDashRes.status === 403, 'Regular member token cannot access Admin Dashboard (HTTP 403 Forbidden)');

        // 12. Direct API requests without token are blocked
        console.log('\n--- Test 12: Anonymous Access Blocked on Protected Routes ---');
        const noTokenRes = await request({
            hostname: 'localhost',
            port: 3000,
            path: '/api/users',
            method: 'GET'
        });
        assert(noTokenRes.status === 401, 'Request without token is blocked with HTTP 401 Unauthorized');

        // 13. Circulation flow: Borrow and Return in MySQL
        console.log('\n--- Test 13: Circulation Flow (Borrow & Return) ---');
        const borrowRes = await request({
            hostname: 'localhost',
            port: 3000,
            path: '/api/loans/borrow',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${demoToken}`
            }
        }, { bookIds: [2], durationDays: 14 });
        assert(borrowRes.status === 201 && borrowRes.body.success, 'Member can borrow book #2');
        const loanItem = Array.isArray(borrowRes.body.data) ? borrowRes.body.data[0] : (borrowRes.body.data && borrowRes.body.data.loans ? borrowRes.body.data.loans[0] : borrowRes.body.data);
        const loanId = loanItem ? (loanItem.loanId || loanItem.id) : null;

        const returnRes = await request({
            hostname: 'localhost',
            port: 3000,
            path: '/api/loans/return',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${demoToken}`
            }
        }, { loanId: loanId, bookId: 2 });
        assert(returnRes.status === 200 && returnRes.body.success, 'Member can return book #2 and update database');

        // 14. Admin Dashboard Metrics Calculated from Database
        console.log('\n--- Test 14: Admin Dashboard Metrics Calculated Live ---');
        const dashRes = await request({
            hostname: 'localhost',
            port: 3000,
            path: '/api/admin/dashboard',
            method: 'GET',
            headers: { 'Authorization': `Bearer ${adminToken}` }
        });
        assert(dashRes.status === 200 && dashRes.body.success, 'Admin dashboard returns live statistics');
        const stats = dashRes.body.stats || dashRes.body.data;
        assert(stats && stats.totalUsers >= 2, `Total users calculated live (${stats.totalUsers})`);
        assert(stats && stats.totalBooks >= 1, `Total books calculated live (${stats.totalBooks})`);
        assert(Array.isArray(stats.recentActivity), 'Recent activity stream included in dashboard stats');

        console.log('\n====================================================');
        console.log(`📊 FINAL TEST RESULTS: ${passed} PASSED, ${failed} FAILED`);
        console.log('====================================================\n');

        if (failed > 0) {
            process.exit(1);
        } else {
            process.exit(0);
        }
    } catch (err) {
        console.error('Fatal test error:', err);
        process.exit(1);
    }
}

runTests();
