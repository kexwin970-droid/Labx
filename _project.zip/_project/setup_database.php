<?php
/**
 * =============================================================================
 * Aetheria Library — MySQL Database Installer & Diagnostics
 * Web installer to verify and initialize MySQL database schema and seeds.
 * =============================================================================
 */

require_once __DIR__ . '/api/db.php';

$isCli = (php_sapi_name() === 'cli');
$results = [];
$error = null;

try {
    // 1. Connect without db
    $dsnWithoutDb = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ];
    $pdoRaw = new PDO($dsnWithoutDb, DB_USER, DB_PASS, $options);
    $results[] = "Connected to MySQL server at " . DB_HOST . ":" . DB_PORT . " as user '" . DB_USER . "'.";

    // 2. Create database
    $pdoRaw->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $results[] = "Database `" . DB_NAME . "` created or verified.";

    // 3. Connect to database
    $dsnWithDb = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $pdo = new PDO($dsnWithDb, DB_USER, DB_PASS, $options);
    $results[] = "Connected to database `" . DB_NAME . "`.";

    // 4. Run database.sql
    $sqlFile = __DIR__ . '/database.sql';
    if (file_exists($sqlFile)) {
        $sql = file_get_contents($sqlFile);
        $pdo->exec($sql);
        $results[] = "Executed `database.sql` successfully. All tables created and seed data inserted.";
    } else {
        throw new Exception("File `database.sql` not found in project root.");
    }

    // 5. Verification queries
    $userCount = $pdo->query("SELECT COUNT(*) FROM `users`")->fetchColumn();
    $bookCount = $pdo->query("SELECT COUNT(*) FROM `books`")->fetchColumn();
    $loanCount = $pdo->query("SELECT COUNT(*) FROM `loans`")->fetchColumn();

    $results[] = "Verified users table: {$userCount} accounts loaded (Primary Key: `email`).";
    $results[] = "Verified books table: {$bookCount} titles loaded.";
    $results[] = "Verified loans table: {$loanCount} loan records loaded.";

} catch (Exception $e) {
    $error = $e->getMessage();
}

if ($isCli) {
    echo "\n=== AETHERIA LIBRARY DATABASE SETUP ===\n";
    foreach ($results as $res) {
        echo " [+] " . $res . "\n";
    }
    if ($error) {
        echo " [-] ERROR: " . $error . "\n";
        exit(1);
    }
    echo "=======================================\n";
    echo "Database initialized successfully!\n\n";
    exit(0);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aetheria Library — MySQL Database Setup</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Outfit:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --bg: #090d16;
            --card-bg: rgba(18, 24, 38, 0.85);
            --border: rgba(255, 255, 255, 0.08);
            --text: #f1f5f9;
            --text-muted: #94a3b8;
            --primary: #3b82f6;
            --success: #10b981;
            --error: #ef4444;
        }
        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--bg);
            color: var(--text);
            margin: 0;
            padding: 40px 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            box-sizing: border-box;
        }
        .setup-card {
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 36px;
            max-width: 600px;
            width: 100%;
            box-shadow: 0 20px 40px rgba(0,0,0,0.4);
            backdrop-filter: blur(10px);
        }
        .header {
            text-align: center;
            margin-bottom: 24px;
        }
        .header h1 {
            font-family: 'Outfit', sans-serif;
            font-size: 1.8rem;
            margin: 0 0 8px 0;
        }
        .header p {
            color: var(--text-muted);
            margin: 0;
            font-size: 0.95rem;
        }
        .status-box {
            background: rgba(0,0,0,0.25);
            border-radius: 10px;
            padding: 16px 20px;
            margin-bottom: 24px;
            font-family: monospace;
            font-size: 0.9rem;
            line-height: 1.6;
        }
        .log-item {
            color: var(--success);
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 6px;
        }
        .log-error {
            color: var(--error);
            display: flex;
            align-items: flex-start;
            gap: 10px;
        }
        .badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 600;
            margin-bottom: 12px;
        }
        .badge-success { background: rgba(16, 185, 129, 0.2); color: #34d399; }
        .badge-error { background: rgba(239, 68, 68, 0.2); color: #f87171; }
        .links {
            display: flex;
            gap: 12px;
            margin-top: 24px;
        }
        .btn {
            flex: 1;
            padding: 12px 18px;
            border-radius: 8px;
            text-decoration: none;
            text-align: center;
            font-weight: 600;
            font-size: 0.9rem;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.2s;
        }
        .btn-primary { background: var(--primary); color: #fff; }
        .btn-secondary { background: rgba(255,255,255,0.08); color: var(--text); }
        .btn:hover { opacity: 0.9; }
    </style>
</head>
<body>
    <div class="setup-card">
        <div class="header">
            <i class="fa-solid fa-database" style="font-size: 2.4rem; color: var(--primary); margin-bottom: 12px;"></i>
            <h1>Aetheria Library</h1>
            <p>MySQL Database Installation & Verification</p>
        </div>

        <?php if ($error): ?>
            <div class="badge badge-error"><i class="fa-solid fa-triangle-exclamation"></i> Connection Notice</div>
            <div class="status-box">
                <div class="log-error">
                    <i class="fa-solid fa-circle-xmark"></i>
                    <div>
                        <strong>Database Initialization Failed:</strong><br>
                        <?= htmlspecialchars($error) ?>
                    </div>
                </div>
            </div>
            <p style="color: var(--text-muted); font-size: 0.85rem; line-height: 1.5;">
                <strong>Configuration Note:</strong> If MySQL is running on a different port or password, you can configure your credentials in <code>api/db.php</code> or set the environment variables <code>DB_HOST</code>, <code>DB_USER</code>, <code>DB_PASS</code>.
            </p>
        <?php else: ?>
            <div class="badge badge-success"><i class="fa-solid fa-circle-check"></i> Setup Complete</div>
            <div class="status-box">
                <?php foreach ($results as $r): ?>
                    <div class="log-item">
                        <i class="fa-solid fa-check"></i>
                        <span><?= htmlspecialchars($r) ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
            <p style="color: var(--text-muted); font-size: 0.85rem; line-height: 1.5;">
                <i class="fa-solid fa-circle-info"></i> <strong>Primary Key Note:</strong> The <code>users</code> table uses <code>email</code> as its PRIMARY KEY. Password resets, user authentications, and admin operations query directly by this primary key.
            </p>
        <?php endif; ?>

        <div class="links">
            <a href="login.html" class="btn btn-primary"><i class="fa-solid fa-arrow-right-to-bracket"></i> Reader Login</a>
            <a href="admin/login.html" class="btn btn-secondary"><i class="fa-solid fa-shield-halved"></i> Admin Console</a>
        </div>
    </div>
</body>
</html>
