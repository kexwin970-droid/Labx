const http = require('http');

function request(options, data) {
    return new Promise((resolve, reject) => {
        const req = http.request(options, (res) => {
            let body = '';
            res.on('data', chunk => body += chunk);
            res.on('end', () => {
                let parsed = null;
                try { parsed = JSON.parse(body); } catch (e) { parsed = body; }
                resolve({ status: res.statusCode, headers: res.headers, body: parsed });
            });
        });
        req.on('error', reject);
        if (data) {
            req.write(typeof data === 'string' ? data : JSON.stringify(data));
        }
        req.end();
    });
}

async function run() {
    console.log('--- 1. Testing Registration with email as primary key ---');
    const userEmail = `sql_tester_${Date.now()}@aetheria.org`;
    const regRes = await request({
        hostname: 'localhost',
        port: 3000,
        path: '/api/auth/register',
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
    }, {
        username: `sqluser_${Date.now()}`,
        email: userEmail,
        password: 'Password123!',
        firstName: 'SQL',
        lastName: 'Tester',
        gender: 'Other'
    });
    console.log('Registration Status:', regRes.status, 'Response:', regRes.body);
    if (!regRes.body.success) throw new Error('Registration failed');

    console.log('\n--- 2. Testing Login and verifying last_login & session creation ---');
    const loginRes = await request({
        hostname: 'localhost',
        port: 3000,
        path: '/api/auth/login',
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
    }, {
        identifier: userEmail,
        password: 'Password123!'
    });
    console.log('Login Status:', loginRes.status, 'User:', loginRes.body.data.user.email);
    if (!loginRes.body.success) throw new Error('Login failed');

    console.log('\n--- 3. Testing Admin Login ---');
    const adminLoginRes = await request({
        hostname: 'localhost',
        port: 3000,
        path: '/api/auth/login',
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
    }, {
        identifier: 'admin@example.com',
        password: 'Admin@123'
    });
    const adminToken = adminLoginRes.body.data.token;
    console.log('Admin Login Token obtained.');

    console.log('\n--- 4. Testing Admin creates book -> reflects on SQL and website catalog ---');
    const createBookRes = await request({
        hostname: 'localhost',
        port: 3000,
        path: '/api/books',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${adminToken}`
        }
    }, {
        title: 'The Cyberpunk Chronicles 2099',
        author: 'Alexandre Sterling',
        genre: 'Sci-Fi & Fantasy',
        rating: 4.9,
        description: 'A revolutionary tale of neon towers and quantum synthetic consciousness.',
        available: true,
        bgGradient: 'linear-gradient(135deg, #0f172a, #06b6d4)',
        headerColor: '#67e8f9'
    });
    console.log('Create Book Status:', createBookRes.status, 'Book:', createBookRes.body.data);
    const createdBookId = createBookRes.body.data.id;

    console.log('\n--- 5. Verifying website catalog GET /api/books contains new book ---');
    const getBooksRes = await request({
        hostname: 'localhost',
        port: 3000,
        path: '/api/books',
        method: 'GET'
    });
    const foundBook = getBooksRes.body.data.find(b => b.id === createdBookId);
    console.log('Found Book in Catalog:', !!foundBook, foundBook?.title);
    if (!foundBook) throw new Error('New book not found in public catalog!');

    console.log('\n--- 6. Testing Admin updates book -> reflects on website catalog ---');
    const updateBookRes = await request({
        hostname: 'localhost',
        port: 3000,
        path: `/api/books/${createdBookId}`,
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${adminToken}`
        }
    }, {
        title: 'The Cyberpunk Chronicles 2099 (Expanded Edition)',
        author: 'Alexandre Sterling',
        genre: 'Sci-Fi & Fantasy',
        available: false
    });
    console.log('Update Book Status:', updateBookRes.status, updateBookRes.body);

    const getUpdatedBookRes = await request({
        hostname: 'localhost',
        port: 3000,
        path: `/api/books/${createdBookId}`,
        method: 'GET'
    });
    console.log('Updated Book in Catalog:', getUpdatedBookRes.body.data.title, 'Available:', getUpdatedBookRes.body.data.available);
    if (getUpdatedBookRes.body.data.available !== false) throw new Error('Book update did not reflect!');

    console.log('\n--- 7. Testing Admin deletes book -> reflects on website catalog ---');
    const deleteBookRes = await request({
        hostname: 'localhost',
        port: 3000,
        path: `/api/books/${createdBookId}`,
        method: 'DELETE',
        headers: {
            'Authorization': `Bearer ${adminToken}`
        }
    });
    console.log('Delete Book Status:', deleteBookRes.status, deleteBookRes.body);

    const getBooksAfterDeleteRes = await request({
        hostname: 'localhost',
        port: 3000,
        path: '/api/books',
        method: 'GET'
    });
    const foundDeletedBook = getBooksAfterDeleteRes.body.data.find(b => b.id === createdBookId);
    console.log('Book present after delete?', !!foundDeletedBook);
    if (foundDeletedBook) throw new Error('Deleted book still exists in catalog!');

    console.log('\n✅ ALL ADMIN, SQL, AND AUTH INTEGRATION TESTS PASSED PERFECTLY!');
}

run().catch(err => {
    console.error('Test Failed:', err);
    process.exit(1);
});
