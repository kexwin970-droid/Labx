/* ==========================================================================
   Aetheria Library — Login Page Controller
   Authenticates users with MySQL database backend via PHP api/auth.php.
   ========================================================================== */

document.addEventListener("DOMContentLoaded", () => {
    // If user is already logged in, redirect to home page
    const currentUser = getActiveUser();
    if (currentUser) {
        window.location.href = "home.html";
        return;
    }

    const loginForm = document.getElementById("login-form");
    if (!loginForm) return;

    loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        
        const emailInput = document.getElementById("login-email");
        const passwordInput = document.getElementById("login-password");

        const email = emailInput.value.trim().toLowerCase();
        const password = passwordInput.value;

        if (!email || !password) {
            showToast("Missing Fields", "Please enter both email address and password.", "warning");
            return;
        }

        // 1. Attempt authentication against MySQL via PHP API
        const apiRes = await apiLogin(email, password);

        if (apiRes && apiRes.success && apiRes.data && apiRes.data.user) {
            const user = apiRes.data.user;
            setActiveUser(user);
            showToast("Access Granted", `Welcome back, ${user.name || user.firstName}! Redirecting...`, "success");

            setTimeout(() => {
                if (user.role === "admin") {
                    window.location.href = "admin.html";
                } else {
                    window.location.href = "home.html";
                }
            }, 800);
            return;
        }

        // If MySQL API is unreachable (e.g. running on file:// or server not started), use local storage fallback
        if (apiRes && (apiRes.isLocalFile || apiRes.networkError)) {
            const users = getUsers();
            const user = users.find(u => u.email.toLowerCase() === email);

            if (!user) {
                showToast("Login Failed", "No registered account found with this email address.", "error");
                return;
            }

            if (user.password !== password) {
                showToast("Login Failed", "Incorrect password credentials. Please retry.", "error");
                return;
            }

            setActiveUser(user);
            showToast("Access Granted", `Welcome back, ${user.name}! Redirecting...`, "success");

            setTimeout(() => {
                if (user.role === "admin") {
                    window.location.href = "admin.html";
                } else {
                    window.location.href = "home.html";
                }
            }, 800);
            return;
        }

        // Display error message returned from MySQL API
        const errorMsg = (apiRes && apiRes.error) ? apiRes.error : "Authentication failed. Please verify credentials.";
        showToast("Login Failed", errorMsg, "error");
    });
});
