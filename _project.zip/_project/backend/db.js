/* ==========================================================================
   Aetheria Library — Central Database Bridge (MySQL + Resilient Driver)
   Manages connection pool, schema migrations, demo account seeding,
   and parameterized SQL execution.
   ========================================================================== */

const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const path = require('path');
const config = require('./config');

let pool = null;
let isConnectedToMySQL = false;
let fallbackStore = null;

// Ensure local fallback data directory exists
const dataDir = path.join(__dirname, '..', 'data');
if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
}
const fallbackDbPath = path.join(dataDir, 'aetheria_database.json');

// Default books collection for seeding
const SEED_BOOKS = [
    {
        id: 1,
        title: "Dune",
        author: "Frank Herbert",
        genre: "Sci-Fi & Fantasy",
        description: "Set on the desert planet Arrakis, Dune is the story of the boy Paul Atreides, who would become the mysterious man known as Muad'Dib.",
        rating: 4.9,
        available: 1,
        bg_gradient: "linear-gradient(135deg, #c27d38, #5e3a15)",
        header_color: "#f3f4f6",
        isbn: "978-0441013593",
        pages: 688
    },
    {
        id: 2,
        title: "Neuromancer",
        author: "William Gibson",
        genre: "Sci-Fi & Fantasy",
        description: "Case, a low-level computer hacker, is hired by a mysterious employer to pull off the ultimate hack against a powerful artificial intelligence.",
        rating: 4.7,
        available: 1,
        bg_gradient: "linear-gradient(135deg, #0f172a, #06b6d4)",
        header_color: "#67e8f9",
        isbn: "978-0441569595",
        pages: 271
    },
    {
        id: 3,
        title: "The Shadow of the Wind",
        author: "Carlos Ruiz Zafón",
        genre: "Mystery & Thriller",
        description: "In the ruins of Barcelona, Daniel Sempere is taken to the Cemetery of Forgotten Books, where he selects a novel that changes the course of his life.",
        rating: 4.8,
        available: 1,
        bg_gradient: "linear-gradient(135deg, #3730a3, #4338ca)",
        header_color: "#e0e7ff",
        isbn: "978-0143034902",
        pages: 487
    },
    {
        id: 4,
        title: "Sapiens: A Brief History",
        author: "Yuval Noah Harari",
        genre: "History & Biography",
        description: "Dr Yuval Noah Harari spans the whole of human history, from the very first humans to walk the earth to the radical breakthroughs of the Cognitive revolution.",
        rating: 4.6,
        available: 1,
        bg_gradient: "linear-gradient(135deg, #78350f, #b45309)",
        header_color: "#fef3c7",
        isbn: "978-0062316097",
        pages: 464
    },
    {
        id: 5,
        title: "Clean Code",
        author: "Robert C. Martin",
        genre: "Technology & Science",
        description: "Even bad code can function. But if code isn't clean, it can bring a development organization to its knees. This book teaches you how to write software well.",
        rating: 4.8,
        available: 1,
        bg_gradient: "linear-gradient(135deg, #065f46, #059669)",
        header_color: "#a7f3d0",
        isbn: "978-0132350884",
        pages: 464
    },
    {
        id: 6,
        title: "The Silent Patient",
        author: "Alex Michaelides",
        genre: "Mystery & Thriller",
        description: "Alicia Berenson's life is seemingly perfect. One evening her husband returns home, and she shoots him five times in the face, and then never speaks another word.",
        rating: 4.5,
        available: 1,
        bg_gradient: "linear-gradient(135deg, #7f1d1d, #ef4444)",
        header_color: "#fca5a5",
        isbn: "978-1250301696",
        pages: 336
    },
    {
        id: 7,
        title: "Steve Jobs",
        author: "Walter Isaacson",
        genre: "History & Biography",
        description: "Based on more than forty interviews with Steve Jobs conducted over two years, this is the exclusive, riveting biography of the creative entrepreneur.",
        rating: 4.7,
        available: 1,
        bg_gradient: "linear-gradient(135deg, #1e293b, #475569)",
        header_color: "#cbd5e1",
        isbn: "978-1451648539",
        pages: 656
    },
    {
        id: 8,
        title: "Designing Data-Intensive Apps",
        author: "Martin Kleppmann",
        genre: "Technology & Science",
        description: "An in-depth guide through the absolute forest of data systems: databases, caches, stream processors, and the core designs powering modern tech giants.",
        rating: 4.9,
        available: 1,
        bg_gradient: "linear-gradient(135deg, #0f172a, #4f46e5)",
        header_color: "#c7d2fe",
        isbn: "978-1449373320",
        pages: 616
    },
    {
        id: 9,
        title: "The Great Gatsby",
        author: "F. Scott Fitzgerald",
        genre: "Fiction",
        description: "The story of the fabulously wealthy Jay Gatsby and his new love for the beautiful Daisy Buchanan, of lavish parties on Long Island at a time when The New York Times noted gin was the national drink.",
        rating: 4.4,
        available: 1,
        bg_gradient: "linear-gradient(135deg, #831843, #be185d)",
        header_color: "#fbcfe8",
        isbn: "978-0743273565",
        pages: 180
    },
    {
        id: 10,
        title: "Atomic Habits",
        author: "James Clear",
        genre: "Philosophy & Psychology",
        description: "An easy and proven way to build good habits and break bad ones through tiny 1% daily changes that compound into remarkable lifetime results.",
        rating: 4.9,
        available: 1,
        bg_gradient: "linear-gradient(135deg, #701a75, #ec4899)",
        header_color: "#f5d0fe",
        isbn: "978-0735211292",
        pages: 320
    },
    {
        id: 11,
        title: "The Psychology of Money",
        author: "Morgan Housel",
        genre: "Philosophy & Psychology",
        description: "Timeless lessons on wealth, greed, and happiness. Doing well with money isn’t necessarily about what you know, it’s about how you behave.",
        rating: 4.8,
        available: 1,
        bg_gradient: "linear-gradient(135deg, #1e293b, #475569)",
        header_color: "#cbd5e1",
        isbn: "978-0857197689",
        pages: 256
    },
    {
        id: 12,
        title: "Project Hail Mary",
        author: "Andy Weir",
        genre: "Sci-Fi & Fantasy",
        description: "Ryland Grace is the sole survivor on a desperate, last-chance mission—and if he fails, humanity and the earth itself will perish.",
        rating: 4.9,
        available: 1,
        bg_gradient: "linear-gradient(135deg, #3730a3, #4338ca)",
        header_color: "#e0e7ff",
        isbn: "978-0593135204",
        pages: 496
    }
];

// Helper to load/save fallback data store
function loadFallbackStore() {
    if (fallbackStore) return fallbackStore;
    if (fs.existsSync(fallbackDbPath)) {
        try {
            fallbackStore = JSON.parse(fs.readFileSync(fallbackDbPath, 'utf8'));
            return fallbackStore;
        } catch (e) {
            console.warn("Could not read fallback database file, creating fresh:", e.message);
        }
    }
    fallbackStore = {
        users: [],
        user_profiles: [],
        sessions: [],
        activity_logs: [],
        books: [],
        loans: [],
        reviews: [],
        wishlists: [],
        reading_records: []
    };
    saveFallbackStore();
    return fallbackStore;
}

function saveFallbackStore() {
    if (!fallbackStore) return;
    try {
        fs.writeFileSync(fallbackDbPath, JSON.stringify(fallbackStore, null, 2), 'utf8');
    } catch (e) {
        console.error("Error writing to fallback database file:", e.message);
    }
}

/**
 * Initialize Database (Connects to MySQL, sets up schema, seeds demo accounts)
 */
async function initDatabase() {
    console.log(`[Database] Attempting connection to MySQL at ${config.db.host}:${config.db.port}...`);

    try {
        // Step 1: Connect to MySQL server (without selecting DB first)
        const rootConnection = await mysql.createConnection({
            host: config.db.host,
            port: config.db.port,
            user: config.db.user,
            password: config.db.password
        });

        // Step 2: Ensure database exists
        await rootConnection.query(
            `CREATE DATABASE IF NOT EXISTS \`${config.db.database}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`
        );
        await rootConnection.end();

        // Step 3: Create connection pool to the database
        pool = mysql.createPool({
            host: config.db.host,
            port: config.db.port,
            user: config.db.user,
            password: config.db.password,
            database: config.db.database,
            waitForConnections: true,
            connectionLimit: 10,
            queueLimit: 0
        });

        // Test connection
        await pool.query('SELECT 1');
        isConnectedToMySQL = true;
        console.log(`[Database] Connected successfully to MySQL database "${config.db.database}"`);

        // Step 4: Run Table Migrations
        await runMySQLMigrations();

        // Step 5: Seed Demo Accounts and Initial Catalog
        await seedMySQLDemoData();

        return { success: true, mode: 'mysql' };
    } catch (err) {
        console.warn(`[Database] MySQL server not reachable (${err.message}).`);
        console.log(`[Database] Activating integrated relational fallback engine.`);
        isConnectedToMySQL = false;
        initFallbackStore();
        return { success: true, mode: 'fallback' };
    }
}

/**
 * Run DDL Schema Migrations on MySQL
 */
async function runMySQLMigrations() {
    console.log('[Database] Running MySQL table migrations...');

    // 1. users (PRIMARY KEY: email)
    await pool.query(`
        CREATE TABLE IF NOT EXISTS \`users\` (
            \`email\` VARCHAR(191) NOT NULL PRIMARY KEY,
            \`id\` INT AUTO_INCREMENT UNIQUE,
            \`username\` VARCHAR(50) NOT NULL UNIQUE,
            \`password_hash\` VARCHAR(255) NOT NULL,
            \`role\` ENUM('member', 'admin') NOT NULL DEFAULT 'member',
            \`status\` ENUM('active', 'disabled') NOT NULL DEFAULT 'active',
            \`last_login\` DATETIME DEFAULT NULL,
            \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX \`idx_users_username\` (\`username\`),
            INDEX \`idx_users_role\` (\`role\`),
            INDEX \`idx_users_status\` (\`status\`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    // 2. user_profiles
    await pool.query(`
        CREATE TABLE IF NOT EXISTS \`user_profiles\` (
            \`user_email\` VARCHAR(191) NOT NULL PRIMARY KEY,
            \`first_name\` VARCHAR(100) DEFAULT '',
            \`last_name\` VARCHAR(100) DEFAULT '',
            \`display_name\` VARCHAR(255) DEFAULT '',
            \`gender\` ENUM('Male', 'Female', 'Other') DEFAULT 'Other',
            \`preferred_genre\` VARCHAR(100) DEFAULT 'Sci-Fi & Fantasy',
            \`avatar\` VARCHAR(50) DEFAULT '1',
            \`phone\` VARCHAR(50) DEFAULT '',
            \`bio\` TEXT DEFAULT NULL,
            \`premium\` TINYINT(1) DEFAULT 0,
            \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            CONSTRAINT \`fk_profile_user_email\`
                FOREIGN KEY (\`user_email\`) REFERENCES \`users\` (\`email\`)
                ON DELETE CASCADE ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    // 3. sessions
    await pool.query(`
        CREATE TABLE IF NOT EXISTS \`sessions\` (
            \`id\` INT AUTO_INCREMENT PRIMARY KEY,
            \`user_email\` VARCHAR(191) NOT NULL,
            \`token\` VARCHAR(500) NOT NULL,
            \`ip_address\` VARCHAR(45) DEFAULT '',
            \`user_agent\` VARCHAR(255) DEFAULT '',
            \`expires_at\` DATETIME NOT NULL,
            \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX \`idx_sessions_token\` (\`token\`(191)),
            INDEX \`idx_sessions_user_email\` (\`user_email\`),
            CONSTRAINT \`fk_sessions_user_email\`
                FOREIGN KEY (\`user_email\`) REFERENCES \`users\` (\`email\`)
                ON DELETE CASCADE ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    // 4. activity_logs
    await pool.query(`
        CREATE TABLE IF NOT EXISTS \`activity_logs\` (
            \`id\` INT AUTO_INCREMENT PRIMARY KEY,
            \`user_email\` VARCHAR(191) DEFAULT NULL,
            \`action\` VARCHAR(100) NOT NULL,
            \`description\` TEXT NOT NULL,
            \`ip_address\` VARCHAR(45) DEFAULT '',
            \`user_agent\` VARCHAR(255) DEFAULT '',
            \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX \`idx_activity_user_email\` (\`user_email\`),
            INDEX \`idx_activity_action\` (\`action\`),
            INDEX \`idx_activity_created\` (\`created_at\`),
            CONSTRAINT \`fk_activity_user_email\`
                FOREIGN KEY (\`user_email\`) REFERENCES \`users\` (\`email\`)
                ON DELETE SET NULL ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    // 5. books
    await pool.query(`
        CREATE TABLE IF NOT EXISTS \`books\` (
            \`id\` INT AUTO_INCREMENT PRIMARY KEY,
            \`title\` VARCHAR(255) NOT NULL,
            \`author\` VARCHAR(255) NOT NULL,
            \`genre\` VARCHAR(100) NOT NULL,
            \`description\` TEXT,
            \`rating\` DECIMAL(2,1) DEFAULT 4.5,
            \`available\` TINYINT(1) DEFAULT 1,
            \`bg_gradient\` VARCHAR(255) DEFAULT 'linear-gradient(135deg, #0f172a, #06b6d4)',
            \`header_color\` VARCHAR(50) DEFAULT '#f3f4f6',
            \`isbn\` VARCHAR(50) DEFAULT '',
            \`pages\` INT DEFAULT 300,
            \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX \`idx_books_genre\` (\`genre\`),
            INDEX \`idx_books_available\` (\`available\`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    // 6. loans
    await pool.query(`
        CREATE TABLE IF NOT EXISTS \`loans\` (
            \`id\` INT AUTO_INCREMENT PRIMARY KEY,
            \`user_email\` VARCHAR(191) NOT NULL,
            \`book_id\` INT NOT NULL,
            \`borrow_date\` DATETIME NOT NULL,
            \`due_date\` DATETIME NOT NULL,
            \`return_date\` DATETIME DEFAULT NULL,
            \`status\` ENUM('active-borrow', 'returned', 'overdue') DEFAULT 'active-borrow',
            \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX \`idx_loans_status\` (\`status\`),
            INDEX \`idx_loans_user_email\` (\`user_email\`),
            CONSTRAINT \`fk_loans_user_email\`
                FOREIGN KEY (\`user_email\`) REFERENCES \`users\` (\`email\`)
                ON DELETE CASCADE ON UPDATE CASCADE,
            CONSTRAINT \`fk_loans_book\`
                FOREIGN KEY (\`book_id\`) REFERENCES \`books\` (\`id\`)
                ON DELETE CASCADE ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    // 7. reviews
    await pool.query(`
        CREATE TABLE IF NOT EXISTS \`reviews\` (
            \`id\` INT AUTO_INCREMENT PRIMARY KEY,
            \`user_email\` VARCHAR(191) NOT NULL,
            \`book_id\` INT NOT NULL,
            \`rating\` INT NOT NULL,
            \`review_text\` TEXT NOT NULL,
            \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX \`idx_reviews_book\` (\`book_id\`),
            CONSTRAINT \`fk_reviews_user_email\`
                FOREIGN KEY (\`user_email\`) REFERENCES \`users\` (\`email\`)
                ON DELETE CASCADE ON UPDATE CASCADE,
            CONSTRAINT \`fk_reviews_book\`
                FOREIGN KEY (\`book_id\`) REFERENCES \`books\` (\`id\`)
                ON DELETE CASCADE ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    // 8. wishlists
    await pool.query(`
        CREATE TABLE IF NOT EXISTS \`wishlists\` (
            \`id\` INT AUTO_INCREMENT PRIMARY KEY,
            \`user_email\` VARCHAR(191) NOT NULL,
            \`book_id\` INT NOT NULL,
            \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY \`unique_user_book_wishlist\` (\`user_email\`, \`book_id\`),
            CONSTRAINT \`fk_wishlist_user_email\`
                FOREIGN KEY (\`user_email\`) REFERENCES \`users\` (\`email\`)
                ON DELETE CASCADE ON UPDATE CASCADE,
            CONSTRAINT \`fk_wishlist_book\`
                FOREIGN KEY (\`book_id\`) REFERENCES \`books\` (\`id\`)
                ON DELETE CASCADE ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    // 9. reading_records
    await pool.query(`
        CREATE TABLE IF NOT EXISTS \`reading_records\` (
            \`id\` INT AUTO_INCREMENT PRIMARY KEY,
            \`user_email\` VARCHAR(191) NOT NULL,
            \`book_id\` INT NOT NULL,
            \`first_accessed\` DATETIME NOT NULL,
            \`last_accessed\` DATETIME NOT NULL,
            \`opens\` INT DEFAULT 1,
            \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY \`unique_user_book_reading\` (\`user_email\`, \`book_id\`),
            CONSTRAINT \`fk_reading_user_email\`
                FOREIGN KEY (\`user_email\`) REFERENCES \`users\` (\`email\`)
                ON DELETE CASCADE ON UPDATE CASCADE,
            CONSTRAINT \`fk_reading_book\`
                FOREIGN KEY (\`book_id\`) REFERENCES \`books\` (\`id\`)
                ON DELETE CASCADE ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    console.log('[Database] MySQL tables verified successfully.');
}

/**
 * Seed Demo Accounts & Initial Data in MySQL
 */
async function seedMySQLDemoData() {
    // 1. Demo User: username: 'demo', email: 'demo@example.com', password: 'Demo@123'
    const [demoRows] = await pool.query('SELECT email FROM users WHERE email = ? OR username = ?', ['demo@example.com', 'demo']);
    if (demoRows.length === 0) {
        console.log('[Database] Seeding predefined demo member account (demo@example.com)...');
        const hash = bcrypt.hashSync('Demo@123', 10);
        await pool.query(
            'INSERT INTO users (email, username, password_hash, role, status) VALUES (?, ?, ?, ?, ?)',
            ['demo@example.com', 'demo', hash, 'member', 'active']
        );
        await pool.query(
            'INSERT INTO user_profiles (user_email, first_name, last_name, display_name, gender, preferred_genre, avatar) VALUES (?, ?, ?, ?, ?, ?, ?)',
            ['demo@example.com', 'Arthur', 'Pendragon', 'Arthur Pendragon', 'Male', 'Sci-Fi & Fantasy', '1']
        );
    }

    // 2. Demo Admin: username: 'admin', email: 'admin@example.com', password: 'Admin@123'
    const [adminRows] = await pool.query('SELECT email FROM users WHERE email = ? OR username = ?', ['admin@example.com', 'admin']);
    if (adminRows.length === 0) {
        console.log('[Database] Seeding predefined demo administrator account (admin@example.com)...');
        const hash = bcrypt.hashSync('Admin@123', 10);
        await pool.query(
            'INSERT INTO users (email, username, password_hash, role, status) VALUES (?, ?, ?, ?, ?)',
            ['admin@example.com', 'admin', hash, 'admin', 'active']
        );
        await pool.query(
            'INSERT INTO user_profiles (user_email, first_name, last_name, display_name, gender, preferred_genre, avatar) VALUES (?, ?, ?, ?, ?, ?, ?)',
            ['admin@example.com', 'Aetheria', 'Admin', 'System Administrator', 'Other', 'Technology & Science', '1']
        );
    }

    // Also support legacy demo accounts if they don't exist
    const [legacyDemo] = await pool.query('SELECT email FROM users WHERE email = ?', ['demo@aetheria.org']);
    if (legacyDemo.length === 0) {
        const hash = bcrypt.hashSync('password123', 10);
        await pool.query(
            'INSERT INTO users (email, username, password_hash, role, status) VALUES (?, ?, ?, ?, ?)',
            ['demo@aetheria.org', 'arthur', hash, 'member', 'active']
        );
        await pool.query(
            'INSERT INTO user_profiles (user_email, first_name, last_name, display_name, gender, preferred_genre, avatar) VALUES (?, ?, ?, ?, ?, ?, ?)',
            ['demo@aetheria.org', 'Arthur', 'Pendragon', 'Arthur Pendragon', 'Male', 'Sci-Fi & Fantasy', '1']
        );
    }

    // 3. Books Catalog
    const [bookCountRows] = await pool.query('SELECT COUNT(*) as count FROM books');
    if (bookCountRows[0].count === 0) {
        console.log('[Database] Seeding books catalog into MySQL...');
        for (const b of SEED_BOOKS) {
            await pool.query(
                `INSERT INTO books (id, title, author, genre, description, rating, available, bg_gradient, header_color, isbn, pages)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [b.id, b.title, b.author, b.genre, b.description, b.rating, b.available, b.bg_gradient, b.header_color, b.isbn, b.pages]
            );
        }
    }

    console.log('[Database] MySQL initial seed check complete.');
}

/**
 * Initialize Fallback Store (If MySQL server is currently offline/unreachable)
 */
function initFallbackStore() {
    const store = loadFallbackStore();

    // 1. Seed demo user if missing
    let demoUser = store.users.find(u => u.username === 'demo' || u.email === 'demo@example.com');
    if (!demoUser) {
        console.log('[Fallback Engine] Seeding demo member account (demo / demo@example.com)...');
        const hash = bcrypt.hashSync('Demo@123', 10);
        const id = store.users.length ? Math.max(...store.users.map(u => u.id)) + 1 : 1;
        demoUser = {
            id,
            username: 'demo',
            email: 'demo@example.com',
            password_hash: hash,
            role: 'member',
            status: 'active',
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
        };
        store.users.push(demoUser);
        store.user_profiles.push({
            id,
            user_id: id,
            user_email: demoUser.email,
            first_name: 'Arthur',
            last_name: 'Pendragon',
            display_name: 'Arthur Pendragon',
            gender: 'Male',
            preferred_genre: 'Sci-Fi & Fantasy',
            avatar: '1',
            phone: '',
            bio: 'Avid reader and explorer of fantastical worlds.',
            premium: 1,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
        });
    }

    // 2. Seed demo admin if missing
    let adminUser = store.users.find(u => u.username === 'admin' || u.email === 'admin@example.com');
    if (!adminUser) {
        console.log('[Fallback Engine] Seeding demo admin account (admin / admin@example.com)...');
        const hash = bcrypt.hashSync('Admin@123', 10);
        const id = Math.max(...store.users.map(u => u.id)) + 1;
        adminUser = {
            id,
            username: 'admin',
            email: 'admin@example.com',
            password_hash: hash,
            role: 'admin',
            status: 'active',
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
        };
        store.users.push(adminUser);
        store.user_profiles.push({
            id,
            user_id: id,
            user_email: adminUser.email,
            first_name: 'Aetheria',
            last_name: 'Admin',
            display_name: 'System Administrator',
            gender: 'Other',
            preferred_genre: 'Technology & Science',
            avatar: '1',
            phone: '',
            bio: 'Administrator overseeing library circulation and member access.',
            premium: 1,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
        });
    }

    // Support legacy demo accounts
    if (!store.users.some(u => u.email === 'demo@aetheria.org')) {
        const id = Math.max(...store.users.map(u => u.id)) + 1;
        store.users.push({
            id,
            username: 'arthur',
            email: 'demo@aetheria.org',
            password_hash: bcrypt.hashSync('password123', 10),
            role: 'member',
            status: 'active',
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
        });
        store.user_profiles.push({
            id,
            user_id: id,
            user_email: 'demo@aetheria.org',
            first_name: 'Arthur',
            last_name: 'Pendragon',
            display_name: 'Arthur Pendragon',
            gender: 'Male',
            preferred_genre: 'Sci-Fi & Fantasy',
            avatar: '1',
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
        });
    }

    // 3. Books
    if (store.books.length === 0) {
        console.log('[Fallback Engine] Seeding books catalog...');
        store.books = JSON.parse(JSON.stringify(SEED_BOOKS));
    }

    // 4. Sample loans for demo user if none exist
    if (store.loans.length === 0 && demoUser) {
        store.loans.push({
            id: 101,
            user_id: demoUser.id,
            user_email: demoUser.email,
            book_id: 1,
            borrow_date: new Date(Date.now() - 5 * 86400000).toISOString(),
            due_date: new Date(Date.now() + 9 * 86400000).toISOString(),
            return_date: null,
            status: 'active-borrow',
            created_at: new Date().toISOString()
        });
        store.loans.push({
            id: 102,
            user_id: demoUser.id,
            user_email: demoUser.email,
            book_id: 5,
            borrow_date: new Date(Date.now() - 20 * 86400000).toISOString(),
            due_date: new Date(Date.now() - 6 * 86400000).toISOString(),
            return_date: new Date(Date.now() - 7 * 86400000).toISOString(),
            status: 'returned',
            created_at: new Date().toISOString()
        });
    }

    saveFallbackStore();
    console.log('[Fallback Engine] Relational data engine ready.');
}

/**
 * Universal query runner: executes against MySQL pool if connected,
 * or fallback engine with accurate relational queries.
 */
async function query(sql, params = []) {
    if (isConnectedToMySQL && pool) {
        const [rows, fields] = await pool.query(sql, params);
        return rows;
    }

    // Fallback SQL-like evaluator
    return executeFallbackQuery(sql, params);
}

/**
 * Fallback SQL-like evaluator for basic CRUD, JOINs, and aggregates
 */
function executeFallbackQuery(sql, params = []) {
    const store = loadFallbackStore();
    const cleanSql = sql.trim().replace(/\s+/g, ' ');

    // 1. SELECT queries
    if (/^SELECT/i.test(cleanSql)) {
        // COUNT aggregations
        if (/COUNT\(\*\)/i.test(cleanSql)) {
            let table = '';
            if (/FROM\s+`?users`?/i.test(cleanSql)) table = 'users';
            else if (/FROM\s+`?books`?/i.test(cleanSql)) table = 'books';
            else if (/FROM\s+`?loans`?/i.test(cleanSql)) table = 'loans';
            else if (/FROM\s+`?reviews`?/i.test(cleanSql)) table = 'reviews';

            let list = store[table] || [];
            if (/WHERE\s+status\s*=\s*'active'/i.test(cleanSql)) {
                list = list.filter(item => item.status === 'active');
            } else if (/WHERE\s+status\s*=\s*'disabled'/i.test(cleanSql)) {
                list = list.filter(item => item.status === 'disabled');
            } else if (/WHERE\s+role\s*=\s*'admin'/i.test(cleanSql)) {
                list = list.filter(item => item.role === 'admin');
            } else if (/WHERE\s+role\s*=\s*'member'/i.test(cleanSql)) {
                list = list.filter(item => item.role === 'member');
            } else if (/WHERE\s+available\s*=\s*1/i.test(cleanSql)) {
                list = list.filter(item => item.available == 1);
            } else if (/WHERE\s+status\s*=\s*'active-borrow'\s+AND\s+due_date\s*<\s*NOW\(\)/i.test(cleanSql)) {
                const now = new Date();
                list = list.filter(item => item.status === 'active-borrow' && new Date(item.due_date) < now);
            } else if (/WHERE\s+status\s*=\s*'active-borrow'/i.test(cleanSql)) {
                list = list.filter(item => item.status === 'active-borrow');
            } else if (/WHERE\s+status\s*=\s*'returned'/i.test(cleanSql)) {
                list = list.filter(item => item.status === 'returned');
            }
            return [{ count: list.length, 'COUNT(*)': list.length }];
        }

        // Users queries
        if (/FROM\s+`?users`?/i.test(cleanSql)) {
            let results = store.users.map(u => {
                const profile = store.user_profiles.find(p => (p.user_email && p.user_email === u.email) || p.user_id === u.id) || {};
                return {
                    ...u,
                    first_name: profile.first_name || '',
                    last_name: profile.last_name || '',
                    display_name: profile.display_name || '',
                    gender: profile.gender || 'Other',
                    preferred_genre: profile.preferred_genre || 'Fiction',
                    avatar: profile.avatar || '1',
                    phone: profile.phone || '',
                    bio: profile.bio || '',
                    premium: profile.premium || 0
                };
            });

            // Filter by ID
            if (/WHERE\s+(?:users\.|u\.)?id\s*=\s*\?/i.test(cleanSql)) {
                const id = parseInt(params[0], 10);
                return results.filter(u => u.id === id);
            }

            // Filter by username OR email (login)
            if (/WHERE\s+(?:(?:u\.|users\.)?username\s*=\s*\?\s+OR\s+(?:u\.|users\.)?email\s*=\s*\?|(?:u\.|users\.)?email\s*=\s*\?\s+OR\s+(?:u\.|users\.)?username\s*=\s*\?)/i.test(cleanSql)) {
                const ident = (params[0] || '').toLowerCase();
                return results.filter(u => (u.username && u.username.toLowerCase() === ident) || (u.email && u.email.toLowerCase() === ident));
            }

            // Filter by email
            if (/WHERE\s+(?:u\.|users\.)?email\s*=\s*\?/i.test(cleanSql)) {
                const email = (params[0] || '').toLowerCase();
                return results.filter(u => u.email && u.email.toLowerCase() === email);
            }

            // Filter by username
            if (/WHERE\s+(?:u\.|users\.)?username\s*=\s*\?/i.test(cleanSql)) {
                const username = (params[0] || '').toLowerCase();
                return results.filter(u => u.username && u.username.toLowerCase() === username);
            }

            if (/LIMIT\s+(\d+)/i.test(cleanSql)) {
                const lim = parseInt(cleanSql.match(/LIMIT\s+(\d+)/i)[1], 10);
                return results.slice(0, lim);
            }

            return results;
        }

        // Books queries
        if (/FROM\s+`?books`?/i.test(cleanSql)) {
            if (/WHERE\s+id\s*=\s*\?/i.test(cleanSql)) {
                const id = parseInt(params[0], 10);
                return store.books.filter(b => b.id === id);
            }
            return store.books;
        }

        // Loans queries
        if (/FROM\s+`?loans`?/i.test(cleanSql)) {
            let res = store.loans.map(l => {
                const user = store.users.find(u => u.id === l.user_id);
                const profile = user ? store.user_profiles.find(p => p.user_id === user.id) : null;
                const book = store.books.find(b => b.id === l.book_id);
                return {
                    ...l,
                    username: user ? user.username : 'unknown',
                    user_email: user ? user.email : '',
                    user_name: profile ? profile.display_name : (user ? user.username : 'User'),
                    book_title: book ? book.title : 'Unknown Book',
                    book_author: book ? book.author : '',
                    book_gradient: book ? book.bg_gradient : ''
                };
            });

            if (/WHERE\s+user_id\s*=\s*\?/i.test(cleanSql)) {
                const uid = parseInt(params[0], 10);
                return res.filter(l => l.user_id === uid);
            }
            return res;
        }

        // Reviews queries
        if (/FROM\s+`?reviews`?/i.test(cleanSql)) {
            let res = store.reviews.map(r => {
                const user = store.users.find(u => u.id === r.user_id);
                const profile = user ? store.user_profiles.find(p => p.user_id === user.id) : null;
                const book = store.books.find(b => b.id === r.book_id);
                return {
                    ...r,
                    user_name: profile ? profile.display_name : (user ? user.username : 'Reader'),
                    user_email: user ? user.email : '',
                    book_title: book ? book.title : 'Book'
                };
            });
            if (/WHERE\s+book_id\s*=\s*\?/i.test(cleanSql)) {
                const bid = parseInt(params[0], 10);
                return res.filter(r => r.book_id === bid);
            }
            return res;
        }

        // Activity logs queries
        if (/FROM\s+`?activity_logs`?/i.test(cleanSql)) {
            let res = store.activity_logs.map(a => {
                const user = store.users.find(u => u.id === a.user_id);
                return {
                    ...a,
                    username: user ? user.username : null,
                    email: user ? user.email : null,
                    role: user ? user.role : null
                };
            });
            return res.reverse();
        }

        // Wishlists
        if (/FROM\s+`?wishlists`?/i.test(cleanSql)) {
            if (/WHERE\s+user_id\s*=\s*\?/i.test(cleanSql)) {
                const uid = parseInt(params[0], 10);
                return store.wishlists.filter(w => w.user_id === uid);
            }
            return store.wishlists;
        }

        // Reading records
        if (/FROM\s+`?reading_records`?/i.test(cleanSql)) {
            if (/WHERE\s+user_id\s*=\s*\?/i.test(cleanSql)) {
                const uid = parseInt(params[0], 10);
                return store.reading_records.filter(r => r.user_id === uid);
            }
            return store.reading_records;
        }

        // Sessions
        if (/FROM\s+`?sessions`?/i.test(cleanSql)) {
            if (/WHERE\s+token\s*=\s*\?/i.test(cleanSql)) {
                return store.sessions.filter(s => s.token === params[0]);
            }
            return store.sessions;
        }

        // User profiles
        if (/FROM\s+`?user_profiles`?/i.test(cleanSql)) {
            if (/WHERE\s+user_id\s*=\s*\?/i.test(cleanSql)) {
                const uid = parseInt(params[0], 10);
                return store.user_profiles.filter(p => p.user_id === uid);
            }
            return store.user_profiles;
        }

        return [];
    }

    // 2. INSERT queries
    if (/^INSERT INTO/i.test(cleanSql)) {
        let table = '';
        if (/INTO\s+`?users`?/i.test(cleanSql)) {
            table = 'users';
            const id = store.users.length ? Math.max(...store.users.map(u => u.id || 0)) + 1 : 1;
            let email = '', username = '', password_hash = '', role = 'member', status = 'active';
            if (params[0] && typeof params[0] === 'string' && params[0].includes('@')) {
                email = params[0].toLowerCase();
                username = params[1] || email.split('@')[0];
                password_hash = params[2];
                role = params[3] || 'member';
                status = params[4] || 'active';
            } else {
                username = params[0];
                email = (params[1] || '').toLowerCase();
                password_hash = params[2];
                role = params[3] || 'member';
                status = params[4] || 'active';
            }
            const newUser = {
                id,
                email,
                username,
                password_hash,
                role,
                status,
                last_login: new Date().toISOString(),
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString()
            };
            store.users.push(newUser);
            saveFallbackStore();
            return { insertId: id, affectedRows: 1 };
        }

        if (/INTO\s+`?user_profiles`?/i.test(cleanSql)) {
            table = 'user_profiles';
            const ident = params[0];
            const u = store.users.find(usr => usr.email === ident || usr.id === ident);
            const user_id = u ? u.id : (typeof ident === 'number' ? ident : 1);
            const user_email = u ? u.email : (typeof ident === 'string' ? ident : '');

            let existing = store.user_profiles.find(p => (user_email && p.user_email === user_email) || (user_id && p.user_id === user_id));
            if (existing) {
                existing.first_name = params[1] !== undefined ? params[1] : existing.first_name;
                existing.last_name = params[2] !== undefined ? params[2] : existing.last_name;
                existing.display_name = params[3] !== undefined ? params[3] : existing.display_name;
                existing.gender = params[4] || existing.gender;
                existing.preferred_genre = params[5] || existing.preferred_genre;
                existing.avatar = params[6] || existing.avatar;
                existing.phone = params[7] || existing.phone;
                existing.bio = params[8] || existing.bio;
                existing.premium = params[9] !== undefined ? params[9] : existing.premium;
                existing.updated_at = new Date().toISOString();
                saveFallbackStore();
                return { insertId: existing.id || 1, affectedRows: 1 };
            }
            const id = store.user_profiles.length ? Math.max(...store.user_profiles.map(p => p.id || 0)) + 1 : 1;
            const newProfile = {
                id,
                user_id,
                user_email,
                first_name: params[1] || '',
                last_name: params[2] || '',
                display_name: params[3] || '',
                gender: params[4] || 'Other',
                preferred_genre: params[5] || 'Sci-Fi & Fantasy',
                avatar: params[6] || '1',
                phone: params[7] || '',
                bio: params[8] || '',
                premium: params[9] || 0,
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString()
            };
            store.user_profiles.push(newProfile);
            saveFallbackStore();
            return { insertId: id, affectedRows: 1 };
        }

        if (/INTO\s+`?activity_logs`?/i.test(cleanSql)) {
            const id = store.activity_logs.length ? Math.max(...store.activity_logs.map(a => a.id || 0)) + 1 : 1;
            const ident = params[0];
            const u = store.users.find(usr => usr.email === ident || usr.id === ident);
            store.activity_logs.push({
                id,
                user_id: u ? u.id : (typeof ident === 'number' ? ident : null),
                user_email: u ? u.email : (typeof ident === 'string' ? ident : null),
                action: params[1],
                description: params[2],
                ip_address: params[3] || '',
                user_agent: params[4] || '',
                created_at: new Date().toISOString()
            });
            saveFallbackStore();
            return { insertId: id, affectedRows: 1 };
        }

        if (/INTO\s+`?sessions`?/i.test(cleanSql)) {
            const id = store.sessions.length ? Math.max(...store.sessions.map(s => s.id || 0)) + 1 : 1;
            const ident = params[0];
            const u = store.users.find(usr => usr.email === ident || usr.id === ident);
            store.sessions.push({
                id,
                user_id: u ? u.id : (typeof ident === 'number' ? ident : null),
                user_email: u ? u.email : (typeof ident === 'string' ? ident : null),
                token: params[1],
                ip_address: params[2] || '',
                user_agent: params[3] || '',
                expires_at: params[4],
                created_at: new Date().toISOString()
            });
            saveFallbackStore();
            return { insertId: id, affectedRows: 1 };
        }

        if (/INTO\s+`?books`?/i.test(cleanSql)) {
            const id = store.books.length ? Math.max(...store.books.map(b => b.id || 0)) + 1 : 1;
            const newBook = {
                id,
                title: params[0],
                author: params[1],
                genre: params[2],
                description: params[3] || '',
                rating: parseFloat(params[4]) || 4.5,
                available: params[5] === undefined ? 1 : (params[5] ? 1 : 0),
                bg_gradient: params[6] || 'linear-gradient(135deg, #0f172a, #06b6d4)',
                header_color: params[7] || '#f3f4f6',
                isbn: params[8] || '',
                pages: parseInt(params[9], 10) || 300,
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString()
            };
            store.books.push(newBook);
            saveFallbackStore();
            return { insertId: id, affectedRows: 1 };
        }

        if (/INTO\s+`?loans`?/i.test(cleanSql)) {
            const id = store.loans.length ? Math.max(...store.loans.map(l => l.id || 0)) + 1 : 1001;
            const ident = params[0];
            const u = store.users.find(usr => usr.email === ident || usr.id === ident);
            const newLoan = {
                id,
                user_id: u ? u.id : (typeof ident === 'number' ? ident : null),
                user_email: u ? u.email : (typeof ident === 'string' ? ident : null),
                book_id: params[1],
                borrow_date: params[2],
                due_date: params[3],
                return_date: null,
                status: 'active-borrow',
                created_at: new Date().toISOString()
            };
            store.loans.push(newLoan);
            saveFallbackStore();
            return { insertId: id, affectedRows: 1 };
        }

        if (/INTO\s+`?reviews`?/i.test(cleanSql)) {
            const id = store.reviews.length ? Math.max(...store.reviews.map(r => r.id || 0)) + 1 : 1;
            const ident = params[0];
            const u = store.users.find(usr => usr.email === ident || usr.id === ident);
            const newReview = {
                id,
                user_id: u ? u.id : (typeof ident === 'number' ? ident : null),
                user_email: u ? u.email : (typeof ident === 'string' ? ident : null),
                book_id: params[1],
                rating: parseInt(params[2], 10),
                review_text: params[3],
                created_at: new Date().toISOString()
            };
            store.reviews.push(newReview);
            saveFallbackStore();
            return { insertId: id, affectedRows: 1 };
        }

        if (/INTO\s+`?wishlists`?/i.test(cleanSql)) {
            const id = store.wishlists.length ? Math.max(...store.wishlists.map(w => w.id || 0)) + 1 : 1;
            const ident = params[0];
            const u = store.users.find(usr => usr.email === ident || usr.id === ident);
            const userId = u ? u.id : ident;
            const userEmail = u ? u.email : ident;
            const existing = store.wishlists.find(w => (w.user_email === userEmail || w.user_id === userId) && w.book_id === params[1]);
            if (!existing) {
                store.wishlists.push({
                    id,
                    user_id: userId,
                    user_email: userEmail,
                    book_id: params[1],
                    created_at: new Date().toISOString()
                });
                saveFallbackStore();
            }
            return { insertId: id, affectedRows: 1 };
        }

        return { insertId: 1, affectedRows: 1 };
    }

    // 3. UPDATE queries
    if (/^UPDATE/i.test(cleanSql)) {
        let affected = 0;

        // Update user last_login
        if (/UPDATE\s+`?users`?\s+SET\s+last_login\s*=\s*NOW\(\)/i.test(cleanSql)) {
            const target = params[0];
            const user = store.users.find(u => u.email === target || u.id === target);
            if (user) {
                user.last_login = new Date().toISOString();
                user.updated_at = new Date().toISOString();
                affected = 1;
            }
        }

        // Update user status
        else if (/UPDATE\s+`?users`?\s+SET\s+status\s*=\s*\?/i.test(cleanSql)) {
            const status = params[0];
            const target = params[1];
            const user = store.users.find(u => u.id === target || u.id === parseInt(target, 10) || u.email === target);
            if (user) {
                user.status = status;
                user.updated_at = new Date().toISOString();
                affected = 1;
                // If disabling, remove active sessions
                if (status === 'disabled') {
                    store.sessions = store.sessions.filter(s => s.user_id !== user.id && s.user_email !== user.email);
                }
            }
        }

        // Update password
        else if (/UPDATE\s+`?users`?\s+SET\s+password_hash\s*=\s*\?/i.test(cleanSql)) {
            const pass = params[0];
            const target = params[1];
            const user = store.users.find(u => u.id === target || u.id === parseInt(target, 10) || u.email === target);
            if (user) {
                user.password_hash = pass;
                user.updated_at = new Date().toISOString();
                affected = 1;
            }
        }

        // Update profile
        else if (/UPDATE\s+`?user_profiles`?/i.test(cleanSql)) {
            const target = params[params.length - 1];
            let profile = store.user_profiles.find(p => p.user_id === target || p.user_id === parseInt(target, 10) || p.user_email === target);
            if (profile) {
                if (params.length >= 7) {
                    profile.first_name = params[0];
                    profile.last_name = params[1];
                    profile.display_name = params[2];
                    profile.gender = params[3];
                    profile.preferred_genre = params[4];
                    profile.avatar = params[5];
                    profile.phone = params[6] || profile.phone;
                    profile.bio = params[7] !== undefined ? params[7] : profile.bio;
                }
                profile.updated_at = new Date().toISOString();
                affected = 1;
            }
        }

        // Update book availability
        else if (/UPDATE\s+`?books`?\s+SET\s+available\s*=\s*\?/i.test(cleanSql)) {
            const avail = params[0] ? 1 : 0;
            const id = parseInt(params[1], 10);
            const book = store.books.find(b => b.id === id);
            if (book) {
                book.available = avail;
                book.updated_at = new Date().toISOString();
                affected = 1;
            }
        }

        // Update entire book
        else if (/UPDATE\s+`?books`?\s+SET/i.test(cleanSql)) {
            const id = parseInt(params[params.length - 1], 10);
            const book = store.books.find(b => b.id === id);
            if (book) {
                book.title = params[0];
                book.author = params[1];
                book.genre = params[2];
                book.description = params[3];
                book.rating = parseFloat(params[4]) || book.rating;
                book.available = params[5] ? 1 : 0;
                book.updated_at = new Date().toISOString();
                affected = 1;
            }
        }

        // Return loan
        else if (/UPDATE\s+`?loans`?\s+SET\s+status\s*=\s*'returned'/i.test(cleanSql)) {
            const loanId = parseInt(params[0], 10);
            const loan = store.loans.find(l => l.id === loanId);
            if (loan) {
                loan.status = 'returned';
                loan.return_date = new Date().toISOString();
                affected = 1;
            }
        }

        saveFallbackStore();
        return { affectedRows: affected };
    }

    // 4. DELETE queries
    if (/^DELETE FROM/i.test(cleanSql)) {
        if (/FROM\s+`?users`?\s+WHERE\s+(?:id|email)\s*=\s*\?/i.test(cleanSql)) {
            const target = params[0];
            const user = store.users.find(u => u.id === target || u.id === parseInt(target, 10) || u.email === target);
            if (user) {
                store.users = store.users.filter(u => u.id !== user.id && u.email !== user.email);
                store.user_profiles = store.user_profiles.filter(p => p.user_id !== user.id && p.user_email !== user.email);
                store.loans = store.loans.filter(l => l.user_id !== user.id && l.user_email !== user.email);
                store.reviews = store.reviews.filter(r => r.user_id !== user.id && r.user_email !== user.email);
                store.sessions = store.sessions.filter(s => s.user_id !== user.id && s.user_email !== user.email);
                saveFallbackStore();
                return { affectedRows: 1 };
            }
        }

        if (/FROM\s+`?books`?\s+WHERE\s+id\s*=\s*\?/i.test(cleanSql)) {
            const id = parseInt(params[0], 10);
            store.books = store.books.filter(b => b.id !== id);
            store.loans = store.loans.filter(l => l.book_id !== id);
            store.reviews = store.reviews.filter(r => r.book_id !== id);
            saveFallbackStore();
            return { affectedRows: 1 };
        }

        if (/FROM\s+`?reviews`?\s+WHERE\s+id\s*=\s*\?/i.test(cleanSql)) {
            const id = parseInt(params[0], 10);
            store.reviews = store.reviews.filter(r => r.id !== id);
            saveFallbackStore();
            return { affectedRows: 1 };
        }

        if (/FROM\s+`?sessions`?\s+WHERE\s+token\s*=\s*\?/i.test(cleanSql)) {
            store.sessions = store.sessions.filter(s => s.token !== params[0]);
            saveFallbackStore();
            return { affectedRows: 1 };
        }

        if (/FROM\s+`?wishlists`?\s+WHERE\s+(?:user_id|user_email)\s*=\s*\?\s+AND\s+book_id\s*=\s*\?/i.test(cleanSql)) {
            store.wishlists = store.wishlists.filter(w => !((w.user_id === params[0] || w.user_email === params[0]) && w.book_id === params[1]));
            saveFallbackStore();
            return { affectedRows: 1 };
        }

        saveFallbackStore();
        return { affectedRows: 1 };
    }

    return [];
}

module.exports = {
    initDatabase,
    query,
    getPool: () => pool,
    isMySQLConnected: () => isConnectedToMySQL,
    getDatabaseStatus: () => ({
        mode: isConnectedToMySQL ? 'mysql' : 'fallback-sql',
        database: isConnectedToMySQL ? config.db.database : 'aetheria_database.json',
        connected: true,
        host: isConnectedToMySQL ? config.db.host : 'local'
    })
};
