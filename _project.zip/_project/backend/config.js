/* ==========================================================================
   Aetheria Library — Backend Configuration
   Loads environment variables with robust defaults
   ========================================================================== */

require('dotenv').config();

module.exports = {
    port: parseInt(process.env.PORT, 10) || 3000,
    nodeEnv: process.env.NODE_ENV || 'development',
    jwtSecret: process.env.JWT_SECRET || 'aetheria_fallback_secure_key_2026',
    jwtExpiresIn: process.env.JWT_EXPIRES_IN || '7d',
    db: {
        host: process.env.DB_HOST || '127.0.0.1',
        port: parseInt(process.env.DB_PORT, 10) || 3306,
        user: process.env.DB_USER || 'root',
        password: process.env.DB_PASSWORD || '',
        database: process.env.DB_NAME || 'aetheria_library'
    }
};
