/* ==========================================================================
   Aetheria Library — Authentication & Authorization Middleware
   Verifies JWT session tokens and enforces role-based access control.
   ========================================================================== */

const jwt = require('jsonwebtoken');
const config = require('../config');
const db = require('../db');

/**
 * Require valid authenticated user session.
 * Queries MySQL to verify user is active and not disabled.
 */
async function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.startsWith('Bearer ') 
        ? authHeader.slice(7).trim() 
        : (req.query.token || req.cookies?.aetheria_token);

    if (!token) {
        return res.status(401).json({
            success: false,
            message: 'Authentication token required. Please sign in.'
        });
    }

    try {
        const decoded = jwt.verify(token, config.jwtSecret);
        
        // Verify user against MySQL database
        const users = await db.query(
            'SELECT id, username, email, role, status FROM users WHERE id = ?',
            [decoded.userId || decoded.id]
        );

        if (!users || users.length === 0) {
            return res.status(401).json({
                success: false,
                message: 'Account not found or session expired.'
            });
        }

        const user = users[0];

        // Enforce account status check
        if (user.status === 'disabled') {
            return res.status(403).json({
                success: false,
                message: 'Your account has been disabled by an administrator. Access restricted.'
            });
        }

        req.user = user;
        req.token = token;
        next();
    } catch (err) {
        return res.status(401).json({
            success: false,
            message: 'Invalid or expired session token. Please sign in again.'
        });
    }
}

/**
 * Require administrator privileges
 */
function requireAdmin(req, res, next) {
    if (!req.user || req.user.role !== 'admin') {
        return res.status(403).json({
            success: false,
            message: 'Access restricted: Administrator privileges required.'
        });
    }
    next();
}

/**
 * Optional authentication: attaches user if valid token present, continues otherwise
 */
async function optionalAuth(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.startsWith('Bearer ') 
        ? authHeader.slice(7).trim() 
        : null;

    if (!token) {
        req.user = null;
        return next();
    }

    try {
        const decoded = jwt.verify(token, config.jwtSecret);
        const users = await db.query(
            'SELECT id, username, email, role, status FROM users WHERE id = ?',
            [decoded.userId || decoded.id]
        );
        if (users && users.length > 0 && users[0].status === 'active') {
            req.user = users[0];
            req.token = token;
        } else {
            req.user = null;
        }
    } catch (e) {
        req.user = null;
    }
    next();
}

module.exports = {
    authenticateToken,
    requireAdmin,
    optionalAuth
};
