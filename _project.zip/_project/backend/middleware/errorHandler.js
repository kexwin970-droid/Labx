/* ==========================================================================
   Aetheria Library — Centralized Error Handling Middleware
   Formats error responses consistently without exposing internal secrets.
   ========================================================================== */

function errorHandler(err, req, res, next) {
    console.error(`[API Error] ${req.method} ${req.url}:`, err);

    const statusCode = err.statusCode || err.status || 500;
    const message = err.message || 'Internal server error occurred.';

    res.status(statusCode).json({
        success: false,
        message: message
    });
}

module.exports = errorHandler;
