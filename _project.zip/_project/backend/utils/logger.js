/* ==========================================================================
   Aetheria Library — Centralized Activity & Audit Logger
   Records important application and administrator actions in MySQL.
   ========================================================================== */

const db = require('../db');

/**
 * Log user or system activity into MySQL activity_logs table
 * @param {number|null} userId - ID of user/admin performing action
 * @param {string} action - Event identifier (e.g. USER_LOGIN, PROFILE_UPDATE)
 * @param {string} description - Human-readable summary of the action
 * @param {object} req - Express request object for IP and User-Agent capture
 */
async function logActivity(userId, action, description, req = null) {
    let ip = '';
    let userAgent = '';

    if (req) {
        ip = req.headers['x-forwarded-for'] || req.socket?.remoteAddress || req.ip || '';
        userAgent = (req.headers['user-agent'] || '').slice(0, 255);
    }

    try {
        await db.query(
            'INSERT INTO activity_logs (user_email, action, description, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)',
            [userId ? String(userId) : null, action, description, ip, userAgent]
        );
    } catch (err) {
        console.warn(`[ActivityLogger] Failed to write log (${action}):`, err.message);
    }
}

module.exports = {
    logActivity
};
