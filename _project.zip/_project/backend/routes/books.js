/* ==========================================================================
   Aetheria Library — Books Catalog API Routes
   CRUD catalog operations persisted in MySQL books table.
   ========================================================================== */

const express = require('express');
const router = express.Router();
const db = require('../db');
const { authenticateToken, requireAdmin, optionalAuth } = require('../middleware/auth');
const { logActivity } = require('../utils/logger');

/**
 * GET /api/books
 * Retrieves all books from MySQL with optional genre and search filters
 */
router.get('/', optionalAuth, async (req, res, next) => {
    try {
        const { search = '', genre = 'all', available = 'all' } = req.query;

        let sql = 'SELECT * FROM books WHERE 1=1';
        const params = [];

        if (genre !== 'all') {
            sql += ' AND genre = ?';
            params.push(genre);
        }

        if (available === 'true' || available === '1') {
            sql += ' AND available = 1';
        } else if (available === 'false' || available === '0') {
            sql += ' AND available = 0';
        }

        if (search.trim()) {
            sql += ' AND (title LIKE ? OR author LIKE ? OR description LIKE ?)';
            const term = `%${search.trim()}%`;
            params.push(term, term, term);
        }

        sql += ' ORDER BY id ASC';

        const books = await db.query(sql, params);
        const formattedBooks = (books || []).map(b => ({
            ...b,
            available: Boolean(b.available),
            rating: parseFloat(b.rating) || 4.5,
            bgGradient: b.bg_gradient || b.bgGradient || 'linear-gradient(135deg, #0f172a, #06b6d4)',
            headerColor: b.header_color || b.headerColor || '#f3f4f6'
        }));

        res.json({
            success: true,
            data: formattedBooks,
            total: formattedBooks.length
        });
    } catch (err) {
        next(err);
    }
});

/**
 * GET /api/books/:id
 * Retrieves single book details with reviews from MySQL
 */
router.get('/:id', optionalAuth, async (req, res, next) => {
    try {
        const bookId = parseInt(req.params.id, 10);
        const books = await db.query('SELECT * FROM books WHERE id = ?', [bookId]);

        if (!books || books.length === 0) {
            return res.status(404).json({ success: false, message: 'Book not found in library catalog.' });
        }

        const raw = books[0];
        const book = {
            ...raw,
            available: Boolean(raw.available),
            rating: parseFloat(raw.rating) || 4.5,
            bgGradient: raw.bg_gradient || raw.bgGradient || 'linear-gradient(135deg, #0f172a, #06b6d4)',
            headerColor: raw.header_color || raw.headerColor || '#f3f4f6'
        };
        const reviews = await db.query(
            `SELECT r.*, u.username, p.display_name as user_name
             FROM reviews r
             LEFT JOIN users u ON r.user_id = u.id
             LEFT JOIN user_profiles p ON u.id = p.user_id
             WHERE r.book_id = ?
             ORDER BY r.created_at DESC`,
            [bookId]
        );

        res.json({
            success: true,
            data: {
                ...book,
                reviews
            }
        });
    } catch (err) {
        next(err);
    }
});

/**
 * POST /api/books
 * Administrator adds a new book to MySQL catalog
 */
router.post('/', authenticateToken, requireAdmin, async (req, res, next) => {
    try {
        const { title, author, genre, description, rating, available, bgGradient, gradient, headerColor, isbn, pages } = req.body;

        if (!title || !author) {
            return res.status(400).json({ success: false, message: 'Book title and author are required.' });
        }

        const grad = bgGradient || gradient || 'linear-gradient(135deg, #0f172a, #06b6d4)';
        const headColor = headerColor || '#f3f4f6';
        const isAvail = (available === undefined || available === true || available === 1) ? 1 : 0;
        const bookRating = parseFloat(rating) || 4.5;

        const result = await db.query(
            `INSERT INTO books (title, author, genre, description, rating, available, bg_gradient, header_color, isbn, pages)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [title.trim(), author.trim(), genre || 'Fiction', description || '', bookRating, isAvail, grad, headColor, isbn || '', parseInt(pages, 10) || 300]
        );

        const newId = result.insertId;

        await logActivity(req.user.id, 'BOOK_CREATED', `Admin added book to catalog: "${title}" by ${author}`, req);

        res.status(201).json({
            success: true,
            message: `Book "${title}" added to library catalog.`,
            data: { id: newId, title, author, genre }
        });
    } catch (err) {
        next(err);
    }
});

/**
 * PUT /api/books/:id
 * Administrator updates book details in MySQL
 */
router.put('/:id', authenticateToken, requireAdmin, async (req, res, next) => {
    try {
        const bookId = parseInt(req.params.id, 10);
        const { title, author, genre, description, rating, available, bgGradient, gradient } = req.body;

        const existing = await db.query('SELECT * FROM books WHERE id = ?', [bookId]);
        if (!existing || existing.length === 0) {
            return res.status(404).json({ success: false, message: 'Book not found in database.' });
        }

        const b = existing[0];
        const newTitle = title !== undefined ? title.trim() : b.title;
        const newAuthor = author !== undefined ? author.trim() : b.author;
        const newGenre = genre !== undefined ? genre : b.genre;
        const newDesc = description !== undefined ? description : b.description;
        const newRating = rating !== undefined ? parseFloat(rating) : b.rating;
        const newAvail = available !== undefined ? (available ? 1 : 0) : b.available;
        const newGrad = bgGradient || gradient || b.bg_gradient;

        await db.query(
            `UPDATE books 
             SET title = ?, author = ?, genre = ?, description = ?, rating = ?, available = ?, bg_gradient = ?, updated_at = NOW()
             WHERE id = ?`,
            [newTitle, newAuthor, newGenre, newDesc, newRating, newAvail, newGrad, bookId]
        );

        await logActivity(req.user.id, 'BOOK_UPDATED', `Admin updated book #${bookId}: "${newTitle}"`, req);

        res.json({
            success: true,
            message: `Book "${newTitle}" updated successfully.`,
            data: { id: bookId, title: newTitle, author: newAuthor, available: Boolean(newAvail) }
        });
    } catch (err) {
        next(err);
    }
});

/**
 * DELETE /api/books/:id
 * Administrator deletes book from MySQL catalog
 */
router.delete('/:id', authenticateToken, requireAdmin, async (req, res, next) => {
    try {
        const bookId = parseInt(req.params.id, 10);
        const existing = await db.query('SELECT title FROM books WHERE id = ?', [bookId]);

        if (!existing || existing.length === 0) {
            return res.status(404).json({ success: false, message: 'Book not found.' });
        }

        const title = existing[0].title;
        await db.query('DELETE FROM books WHERE id = ?', [bookId]);

        await logActivity(req.user.id, 'BOOK_DELETED', `Admin deleted book #${bookId} ("${title}") from catalog`, req);

        res.json({
            success: true,
            message: `Book "${title}" was removed from the MySQL catalog.`
        });
    } catch (err) {
        next(err);
    }
});

module.exports = router;
