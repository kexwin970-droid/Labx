/* ==========================================================================
   Aetheria Library — Wishlist API Routes
   Personal user reading wishlist persisted in MySQL wishlists table.
   ========================================================================== */

const express = require('express');
const router = express.Router();
const db = require('../db');
const { authenticateToken } = require('../middleware/auth');

router.use(authenticateToken);

/**
 * GET /api/wishlist
 * Returns list of book IDs or book items in the user's wishlist
 */
router.get('/', async (req, res, next) => {
    try {
        const rows = await db.query(
            `SELECT w.book_id, b.title, b.author, b.genre, b.rating, b.available, b.bg_gradient, b.description
             FROM wishlists w
             JOIN books b ON w.book_id = b.id
             WHERE w.user_email = ? OR w.user_id = ?
             ORDER BY w.created_at DESC`,
            [req.user.email, req.user.id]
        );

        const bookIds = rows.map(r => r.book_id);

        res.json({
            success: true,
            data: rows,
            bookIds: bookIds
        });
    } catch (err) {
        next(err);
    }
});

/**
 * POST /api/wishlist/toggle
 * Adds or removes a book from the user's wishlist in MySQL
 */
router.post('/toggle', async (req, res, next) => {
    try {
        const { bookId } = req.body;
        const bid = parseInt(bookId, 10);

        if (!bid) {
            return res.status(400).json({ success: false, message: 'Valid book ID required.' });
        }

        const existing = await db.query(
            'SELECT id FROM wishlists WHERE (user_email = ? OR user_id = ?) AND book_id = ?',
            [req.user.email, req.user.id, bid]
        );

        let inWishlist = false;
        if (existing.length > 0) {
            await db.query('DELETE FROM wishlists WHERE (user_email = ? OR user_id = ?) AND book_id = ?', [req.user.email, req.user.id, bid]);
            inWishlist = false;
        } else {
            await db.query('INSERT INTO wishlists (user_email, book_id) VALUES (?, ?)', [req.user.email, bid]);
            inWishlist = true;
        }

        res.json({
            success: true,
            inWishlist,
            message: inWishlist ? 'Saved to your wishlist.' : 'Removed from your wishlist.'
        });
    } catch (err) {
        next(err);
    }
});

module.exports = router;
