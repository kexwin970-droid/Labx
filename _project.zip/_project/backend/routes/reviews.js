/* ==========================================================================
   Aetheria Library — Book Reviews & Ratings API Routes
   Stores member ratings and literary feedback in MySQL reviews table.
   ========================================================================== */

const express = require('express');
const router = express.Router();
const db = require('../db');
const { authenticateToken, optionalAuth } = require('../middleware/auth');
const { logActivity } = require('../utils/logger');

/**
 * GET /api/reviews
 * Retrieves reviews, optionally filtered by bookId
 */
router.get('/', optionalAuth, async (req, res, next) => {
    try {
        const { bookId } = req.query;

        let sql = `
            SELECT r.*, u.username, u.email as user_email, p.display_name as user_name, b.title as book_title
            FROM reviews r
            JOIN books b ON r.book_id = b.id
            JOIN users u ON (r.user_email = u.email OR r.user_id = u.id)
            LEFT JOIN user_profiles p ON (u.email = p.user_email OR u.id = p.user_id)
            WHERE 1=1
        `;
        const params = [];

        if (bookId) {
            sql += ' AND r.book_id = ?';
            params.push(parseInt(bookId, 10));
        }

        sql += ' ORDER BY r.created_at DESC';

        const reviews = await db.query(sql, params);

        res.json({
            success: true,
            data: reviews,
            total: reviews.length
        });
    } catch (err) {
        next(err);
    }
});

/**
 * POST /api/reviews
 * Submits a new book review into MySQL
 */
router.post('/', authenticateToken, async (req, res, next) => {
    try {
        const { bookId, rating, text, reviewText } = req.body;
        const bid = parseInt(bookId, 10);
        const rate = parseInt(rating, 10);
        const content = (text || reviewText || '').trim();

        if (!bid || !rate) {
            return res.status(400).json({ success: false, message: 'Book ID and star rating are required.' });
        }
        if (rate < 1 || rate > 5) {
            return res.status(400).json({ success: false, message: 'Rating must be between 1 and 5 stars.' });
        }

        const result = await db.query(
            'INSERT INTO reviews (user_email, book_id, rating, review_text) VALUES (?, ?, ?, ?)',
            [req.user.email, bid, rate, content]
        );

        await logActivity(req.user.email, 'REVIEW_SUBMITTED', `User submitted ${rate}-star review for book #${bid}`, req);

        res.status(201).json({
            success: true,
            message: 'Your review has been posted.',
            data: { id: result.insertId, bookId: bid, rating: rate, text: content }
        });
    } catch (err) {
        next(err);
    }
});

/**
 * DELETE /api/reviews/:id
 * Deletes review from MySQL (allowed by review author or admin)
 */
router.delete('/:id', authenticateToken, async (req, res, next) => {
    try {
        const revId = parseInt(req.params.id, 10);
        const reviews = await db.query('SELECT * FROM reviews WHERE id = ?', [revId]);

        if (!reviews.length) {
            return res.status(404).json({ success: false, message: 'Review not found.' });
        }

        const rev = reviews[0];
        if (req.user.role !== 'admin' && rev.user_id !== req.user.id) {
            return res.status(403).json({ success: false, message: 'Unauthorized to delete this review.' });
        }

        await db.query('DELETE FROM reviews WHERE id = ?', [revId]);
        await logActivity(req.user.id, 'REVIEW_DELETED', `Deleted review #${revId}`, req);

        res.json({
            success: true,
            message: 'Review removed successfully.'
        });
    } catch (err) {
        next(err);
    }
});

module.exports = router;
