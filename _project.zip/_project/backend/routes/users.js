/* ==========================================================================
   Aetheria Library — User Management API Routes (Admin)
   Enables administrators to view, search, edit, enable/disable, reset password,
   and delete users directly in MySQL.
   ========================================================================== */

const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../db');
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const { logActivity } = require('../utils/logger');

// All routes here require Administrator authorization
router.use(authenticateToken);
router.use(requireAdmin);

/**
 * GET /api/users
 * Returns list of registered users with profile details from MySQL
 */
router.get('/', async (req, res, next) => {
    try {
        const { search = '', role = 'all', status = 'all' } = req.query;

        let sql = `
            SELECT u.id, u.username, u.email, u.role, u.status, u.created_at,
                   p.first_name, p.last_name, p.display_name, p.gender, p.preferred_genre, p.avatar, p.phone, p.bio
            FROM users u
            LEFT JOIN user_profiles p ON (u.email = p.user_email OR u.id = p.user_id)
            WHERE 1=1
        `;
        const params = [];

        if (role !== 'all') {
            sql += ' AND u.role = ?';
            params.push(role);
        }

        if (status !== 'all') {
            sql += ' AND u.status = ?';
            params.push(status);
        }

        if (search.trim()) {
            sql += ` AND (u.username LIKE ? OR u.email LIKE ? OR p.display_name LIKE ? OR p.first_name LIKE ? OR p.last_name LIKE ?)`;
            const term = `%${search.trim()}%`;
            params.push(term, term, term, term, term);
        }

        sql += ' ORDER BY u.created_at DESC';

        const users = await db.query(sql, params);

        const mapped = users.map(u => ({
            id: u.id,
            username: u.username,
            email: u.email,
            name: u.display_name || `${u.first_name || ''} ${u.last_name || ''}`.trim() || u.username,
            firstName: u.first_name || '',
            lastName: u.last_name || '',
            gender: u.gender || 'Other',
            role: u.role,
            status: u.status,
            genre: u.preferred_genre || 'Fiction',
            avatar: u.avatar || '1',
            phone: u.phone || '',
            bio: u.bio || '',
            createdAt: u.created_at
        }));

        res.json({
            success: true,
            data: mapped,
            total: mapped.length
        });
    } catch (err) {
        next(err);
    }
});

/**
 * GET /api/users/:id
 * Get single user details with loan history from MySQL
 */
router.get('/:id', async (req, res, next) => {
    try {
        const userId = parseInt(req.params.id, 10);
        const users = await db.query(
            `SELECT u.id, u.username, u.email, u.role, u.status, u.created_at,
                    p.first_name, p.last_name, p.display_name, p.gender, p.preferred_genre, p.avatar, p.phone, p.bio
             FROM users u
             LEFT JOIN user_profiles p ON (u.email = p.user_email OR u.id = p.user_id)
             WHERE u.id = ? OR u.email = ?`,
            [isNaN(userId) ? 0 : userId, req.params.id]
        );

        if (!users || users.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found in database.' });
        }

        const u = users[0];
        const loans = await db.query('SELECT * FROM loans WHERE user_id = ? ORDER BY borrow_date DESC', [userId]);

        res.json({
            success: true,
            data: {
                id: u.id,
                username: u.username,
                email: u.email,
                name: u.display_name || `${u.first_name || ''} ${u.last_name || ''}`.trim() || u.username,
                firstName: u.first_name || '',
                lastName: u.last_name || '',
                gender: u.gender || 'Other',
                role: u.role,
                status: u.status,
                genre: u.preferred_genre || 'Fiction',
                avatar: u.avatar || '1',
                phone: u.phone || '',
                bio: u.bio || '',
                createdAt: u.created_at,
                loans
            }
        });
    } catch (err) {
        next(err);
    }
});

/**
 * POST /api/users
 * Administrator creates new member account in MySQL
 */
router.post('/', async (req, res, next) => {
    try {
        const { username, email, password, firstName, lastName, gender, role, genre } = req.body;
        const cleanEmail = (email || '').trim().toLowerCase();
        const cleanUsername = (username || cleanEmail.split('@')[0] || '').trim().toLowerCase();

        if (!cleanEmail || !password) {
            return res.status(400).json({ success: false, message: 'Email and password are required.' });
        }

        const existing = await db.query('SELECT id FROM users WHERE email = ? OR username = ?', [cleanEmail, cleanUsername]);
        if (existing.length > 0) {
            return res.status(409).json({ success: false, message: 'An account with this email or username already exists.' });
        }

        const passwordHash = await bcrypt.hash(password, 10);
        const userRole = role === 'admin' ? 'admin' : 'member';
        const displayName = `${firstName || ''} ${lastName || ''}`.trim() || cleanUsername;

        const insertResult = await db.query(
            'INSERT INTO users (email, username, password_hash, role, status, last_login) VALUES (?, ?, ?, ?, ?, NOW())',
            [cleanEmail, cleanUsername, passwordHash, userRole, 'active']
        );
        const userId = insertResult.insertId || 1;

        await db.query(
            `INSERT INTO user_profiles (user_email, first_name, last_name, display_name, gender, preferred_genre, avatar)
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [cleanEmail, firstName || '', lastName || '', displayName, gender || 'Other', genre || 'Fiction', '1']
        );

        await logActivity(req.user.id, 'USER_CREATED_BY_ADMIN', `Admin created account: ${cleanUsername} (${cleanEmail}) as ${userRole}`, req);

        res.status(201).json({
            success: true,
            message: `Account created for ${displayName}.`,
            data: { id: userId, username: cleanUsername, email: cleanEmail, role: userRole }
        });
    } catch (err) {
        next(err);
    }
});

/**
 * PUT /api/users/:id/status
 * Enables or disables user account in MySQL (Revokes sessions immediately if disabled)
 */
router.put('/:id/status', async (req, res, next) => {
    try {
        const userId = parseInt(req.params.id, 10);
        const { status } = req.body;

        if (status !== 'active' && status !== 'disabled') {
            return res.status(400).json({ success: false, message: 'Status must be "active" or "disabled".' });
        }

        const target = req.params.id;
        const users = await db.query('SELECT id, username, email FROM users WHERE id = ? OR email = ?', [isNaN(parseInt(target, 10)) ? 0 : parseInt(target, 10), target]);
        if (users.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found in database.' });
        }

        const targetUser = users[0];
        if (req.user.email === targetUser.email || req.user.id === targetUser.id) {
            return res.status(400).json({ success: false, message: 'You cannot disable your own administrator account.' });
        }

        await db.query('UPDATE users SET status = ?, updated_at = NOW() WHERE email = ?', [status, targetUser.email]);

        // If disabling account, delete all active sessions immediately
        if (status === 'disabled') {
            await db.query('DELETE FROM sessions WHERE user_email = ?', [targetUser.email]);
        }

        await logActivity(
            req.user.id,
            'USER_STATUS_CHANGE',
            `Admin ${status === 'active' ? 'enabled' : 'disabled'} account: ${users[0].username} (${users[0].email})`,
            req
        );

        res.json({
            success: true,
            message: `Account ${users[0].username} is now ${status}.`,
            data: { id: userId, status }
        });
    } catch (err) {
        next(err);
    }
});

/**
 * POST /api/users/:id/password
 * Administrator resets user password in MySQL
 */
router.post('/:id/password', async (req, res, next) => {
    try {
        const userId = parseInt(req.params.id, 10);
        const { newPassword } = req.body;

        if (!newPassword || newPassword.length < 6) {
            return res.status(400).json({ success: false, message: 'Password must be at least 6 characters long.' });
        }

        const target = req.params.id;
        const users = await db.query('SELECT id, username, email FROM users WHERE id = ? OR email = ?', [isNaN(parseInt(target, 10)) ? 0 : parseInt(target, 10), target]);
        if (users.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found.' });
        }

        const targetUser = users[0];
        const passwordHash = await bcrypt.hash(newPassword, 10);
        await db.query('UPDATE users SET password_hash = ?, updated_at = NOW() WHERE email = ?', [passwordHash, targetUser.email]);

        // Invalidate active sessions to require re-login with new password
        await db.query('DELETE FROM sessions WHERE user_email = ?', [targetUser.email]);

        await logActivity(
            req.user.id,
            'ADMIN_PASSWORD_RESET',
            `Admin reset password for user: ${users[0].username} (${users[0].email})`,
            req
        );

        res.json({
            success: true,
            message: `Password has been reset for ${users[0].username}.`
        });
    } catch (err) {
        next(err);
    }
});

/**
 * DELETE /api/users/:id
 * Deletes user account and cascaded data from MySQL
 */
router.delete('/:id', async (req, res, next) => {
    try {
        const userId = parseInt(req.params.id, 10);

        const target = req.params.id;
        const users = await db.query('SELECT id, username, email FROM users WHERE id = ? OR email = ?', [isNaN(parseInt(target, 10)) ? 0 : parseInt(target, 10), target]);
        if (users.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found in database.' });
        }

        const targetUser = users[0];
        // Prevent self-deletion
        if (req.user.email === targetUser.email || req.user.id === targetUser.id) {
            return res.status(400).json({ success: false, message: 'You cannot delete your own administrator account.' });
        }

        // Delete from MySQL (Foreign keys handle cascade)
        await db.query('DELETE FROM users WHERE email = ?', [targetUser.email]);

        await logActivity(
            req.user.id,
            'USER_DELETED',
            `Admin deleted user account: ${targetUser.username} (${targetUser.email})`,
            req
        );

        res.json({
            success: true,
            message: `User ${targetUser.username} (${targetUser.email}) deleted.`
        });
    } catch (err) {
        next(err);
    }
});

module.exports = router;
