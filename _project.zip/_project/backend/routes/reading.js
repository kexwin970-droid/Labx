/* ==========================================================================
   Aetheria Library — Reader Logs API Routes
   Tracks book interactions and reading sessions in MySQL reading_records table.
   ========================================================================== */

const express = require('express');
const router = express.Router();
const db = require('../db');
const { authenticateToken } = require('../middleware/auth');

router.use(authenticateToken);

/**
 * GET /api/reading
 * Returns user reading records
 */
router.get('/', async (req, res, next) => {
    try {
        const records = await db.query(
            `SELECT r.*, b.title as book_title, b.author, b.genre
             FROM reading_records r
             JOIN books b ON r.book_id = b.id
             WHERE r.user_email = ? OR r.user_id = ?
             ORDER BY r.last_accessed DESC`,
            [req.user.email, req.user.id]
        );

        res.json({
            success: true,
            data: records
        });
    } catch (err) {
        next(err);
    }
});

/**
 * POST /api/reading/record
 * Logs reading session or opens of a book
 */
router.post('/record', async (req, res, next) => {
    try {
        const { bookId } = req.body;
        const bid = parseInt(bookId, 10);

        if (!bid) {
            return res.status(400).json({ success: false, message: 'Book ID required.' });
        }

        const now = new Date();
        const existing = await db.query(
            'SELECT id, opens FROM reading_records WHERE (user_email = ? OR user_id = ?) AND book_id = ?',
            [req.user.email, req.user.id, bid]
        );

        if (existing.length > 0) {
            const currentOpens = (existing[0].opens || 1) + 1;
            await db.query(
                'UPDATE reading_records SET opens = ?, last_accessed = ? WHERE id = ?',
                [currentOpens, now, existing[0].id]
            );
        } else {
            await db.query(
                `INSERT INTO reading_records (user_email, book_id, first_accessed, last_accessed, opens)
                 VALUES (?, ?, ?, ?, 1)`,
                [req.user.email, bid, now, now]
            );
        }

        res.json({
            success: true,
            message: 'Reading session recorded.'
        });
    } catch (err) {
        next(err);
    }
});

module.exports = router;
