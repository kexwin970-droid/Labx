/* ==========================================================================
   Aetheria Library — Admin Dashboard & Audit Logs API Routes
   Aggregates live metrics, system statistics, and audit logs from MySQL.
   ========================================================================== */

const express = require('express');
const router = express.Router();
const db = require('../db');
const { authenticateToken, requireAdmin } = require('../middleware/auth');

router.use(authenticateToken);
router.use(requireAdmin);

/**
 * GET /api/admin/dashboard
 * Aggregates live system statistics calculated directly from MySQL database
 */
router.get('/dashboard', async (req, res, next) => {
    try {
        // Run SQL queries in parallel for high efficiency
        const [
            totalUsersRes,
            activeUsersRes,
            disabledUsersRes,
            totalMembersRes,
            totalAdminsRes,
            totalBooksRes,
            availableBooksRes,
            activeLoansRes,
            returnedLoansRes,
            overdueLoansRes,
            totalReviewsRes,
            recentUsersRes,
            recentActivityRes
        ] = await Promise.all([
            db.query('SELECT COUNT(*) as count FROM users'),
            db.query("SELECT COUNT(*) as count FROM users WHERE status = 'active'"),
            db.query("SELECT COUNT(*) as count FROM users WHERE status = 'disabled'"),
            db.query("SELECT COUNT(*) as count FROM users WHERE role = 'member'"),
            db.query("SELECT COUNT(*) as count FROM users WHERE role = 'admin'"),
            db.query('SELECT COUNT(*) as count FROM books'),
            db.query('SELECT COUNT(*) as count FROM books WHERE available = 1'),
            db.query("SELECT COUNT(*) as count FROM loans WHERE status = 'active-borrow'"),
            db.query("SELECT COUNT(*) as count FROM loans WHERE status = 'returned'"),
            db.query("SELECT COUNT(*) as count FROM loans WHERE status = 'active-borrow' AND due_date < NOW()"),
            db.query('SELECT COUNT(*) as count FROM reviews'),
            db.query(`
                SELECT u.id, u.username, u.email, u.role, u.status, u.created_at,
                       p.first_name, p.last_name, p.display_name, p.avatar
                FROM users u
                LEFT JOIN user_profiles p ON (u.email = p.user_email OR u.id = p.user_id)
                ORDER BY u.created_at DESC
                LIMIT 5
            `),
            db.query(`
                SELECT a.*, u.username, u.email, u.role
                FROM activity_logs a
                LEFT JOIN users u ON (a.user_email = u.email OR a.user_id = u.id)
                ORDER BY a.created_at DESC
                LIMIT 10
            `)
        ]);

        const getCount = (r) => (r && r[0] ? (parseInt(r[0].count, 10) || parseInt(r[0]['COUNT(*)'], 10) || 0) : 0);

        const stats = {
            totalUsers: getCount(totalUsersRes),
            activeUsers: getCount(activeUsersRes),
            disabledUsers: getCount(disabledUsersRes),
            totalMembers: getCount(totalMembersRes),
            totalAdmins: getCount(totalAdminsRes),
            totalBooks: getCount(totalBooksRes),
            availableBooks: getCount(availableBooksRes),
            activeLoans: getCount(activeLoansRes),
            returnedLoans: getCount(returnedLoansRes),
            overdueLoans: getCount(overdueLoansRes),
            totalReviews: getCount(totalReviewsRes),
            recentUsers: recentUsersRes || [],
            recentActivity: recentActivityRes || [],
            databaseStatus: db.getDatabaseStatus()
        };

        res.json({
            success: true,
            data: stats,
            stats: stats
        });
    } catch (err) {
        next(err);
    }
});

/**
 * GET /api/admin/activity-logs
 * Retrieves audit logs from MySQL activity_logs table
 */
router.get('/activity-logs', async (req, res, next) => {
    try {
        const { search = '', action = 'all', limit = 50, offset = 0 } = req.query;

        let sql = `
            SELECT a.*, u.username, u.email, u.role
            FROM activity_logs a
            LEFT JOIN users u ON (a.user_email = u.email OR a.user_id = u.id)
            WHERE 1=1
        `;
        const params = [];

        if (action !== 'all') {
            sql += ' AND a.action = ?';
            params.push(action);
        }

        if (search.trim()) {
            sql += ' AND (a.description LIKE ? OR a.action LIKE ? OR u.username LIKE ? OR u.email LIKE ?)';
            const term = `%${search.trim()}%`;
            params.push(term, term, term, term);
        }

        sql += ' ORDER BY a.created_at DESC';

        const lim = Math.min(parseInt(limit, 10) || 50, 100);
        const off = parseInt(offset, 10) || 0;
        sql += ` LIMIT ${lim} OFFSET ${off}`;

        const logs = await db.query(sql, params);

        res.json({
            success: true,
            data: logs,
            total: logs.length
        });
    } catch (err) {
        next(err);
    }
});

/**
 * GET /api/admin/health
 * Returns database connectivity health check
 */
router.get('/health', (req, res) => {
    res.json({
        success: true,
        data: db.getDatabaseStatus()
    });
});

module.exports = router;
