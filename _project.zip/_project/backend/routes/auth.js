/* ==========================================================================
   Aetheria Library — Authentication & Profile API Routes
   Connected directly to MySQL database with bcrypt hashing & JWT sessions.
   ========================================================================== */

const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../db');
const config = require('../config');
const { authenticateToken } = require('../middleware/auth');
const { logActivity } = require('../utils/logger');

/**
 * POST /api/auth/register
 * Registers a new user into MySQL with hashed password and user_profile.
 */
router.post('/register', async (req, res, next) => {
    try {
        const { username, email, password, name, firstName, lastName, gender } = req.body;

        const cleanEmail = (email || '').trim().toLowerCase();
        const cleanUsername = (username || cleanEmail.split('@')[0] || '').trim().toLowerCase();
        let cleanFirst = (firstName || '').trim();
        let cleanLast = (lastName || '').trim();
        if (!cleanFirst && name) {
            const parts = name.trim().split(' ');
            cleanFirst = parts[0] || '';
            cleanLast = parts.slice(1).join(' ') || '';
        }
        if (!cleanFirst) cleanFirst = cleanUsername;
        const cleanGender = gender || 'Other';

        // 1. Validations
        if (!cleanEmail || !cleanEmail.includes('@')) {
            return res.status(400).json({ success: false, message: 'A valid email address is required.' });
        }
        if (!cleanUsername || cleanUsername.length < 3) {
            return res.status(400).json({ success: false, message: 'Username must be at least 3 characters.' });
        }
        if (!password || password.length < 6) {
            return res.status(400).json({ success: false, message: 'Password must be at least 6 characters long.' });
        }

        // 2. Check for duplicate email or username in MySQL
        const existingUsers = await db.query(
            'SELECT id, username, email FROM users WHERE email = ? OR username = ?',
            [cleanEmail, cleanUsername]
        );

        if (existingUsers && existingUsers.length > 0) {
            const conflict = existingUsers[0];
            if (conflict.email.toLowerCase() === cleanEmail) {
                return res.status(409).json({ success: false, message: 'An account with this email address is already registered.' });
            }
            if (conflict.username.toLowerCase() === cleanUsername) {
                return res.status(409).json({ success: false, message: 'This username is already taken. Please choose another.' });
            }
        }

        // 3. Hash password securely using bcrypt
        const passwordHash = await bcrypt.hash(password, 10);
        const displayName = `${cleanFirst} ${cleanLast}`.trim();

        // 4. Insert into MySQL `users` table (email is PRIMARY KEY)
        const insertUserResult = await db.query(
            'INSERT INTO users (email, username, password_hash, role, status, last_login) VALUES (?, ?, ?, ?, ?, NOW())',
            [cleanEmail, cleanUsername, passwordHash, 'member', 'active']
        );
        const userId = insertUserResult.insertId || 1;

        // 5. Insert into MySQL `user_profiles` table (user_email is PRIMARY KEY)
        await db.query(
            `INSERT INTO user_profiles (user_email, first_name, last_name, display_name, gender, preferred_genre, avatar)
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [cleanEmail, cleanFirst, cleanLast, displayName, cleanGender, 'Sci-Fi & Fantasy', '1']
        );

        // 6. Log registration in MySQL activity_logs
        await logActivity(cleanEmail, 'USER_REGISTER', `New user registered: ${cleanUsername} (${cleanEmail})`, req);

        // 7. Generate JWT token
        const token = jwt.sign(
            { userId, username: cleanUsername, email: cleanEmail, role: 'member' },
            config.jwtSecret,
            { expiresIn: config.jwtExpiresIn }
        );

        const userData = {
            id: userId,
            username: cleanUsername,
            email: cleanEmail,
            name: displayName,
            firstName: cleanFirst,
            lastName: cleanLast,
            gender: cleanGender,
            role: 'member',
            status: 'active',
            genre: 'Sci-Fi & Fantasy',
            avatar: '1'
        };

        return res.status(201).json({
            success: true,
            message: 'Account created successfully! Welcome to Aetheria Library.',
            data: {
                token,
                user: userData
            }
        });
    } catch (err) {
        next(err);
    }
});

/**
 * POST /api/auth/login
 * Validates credentials against MySQL and creates an authenticated session.
 */
router.post('/login', async (req, res, next) => {
    try {
        const { identifier, email, username, password } = req.body;
        const lookup = (identifier || email || username || '').trim().toLowerCase();

        if (!lookup || !password) {
            return res.status(400).json({
                success: false,
                message: 'Please provide both username/email and password.'
            });
        }

        // 1. Query user from MySQL by username OR email
        const users = await db.query(
            `SELECT u.id, u.username, u.email, u.password_hash, u.role, u.status, u.last_login,
                    p.first_name, p.last_name, p.display_name, p.gender, p.preferred_genre, p.avatar, p.phone, p.bio, p.premium
             FROM users u
             LEFT JOIN user_profiles p ON (u.email = p.user_email OR u.id = p.user_id)
             WHERE u.username = ? OR u.email = ?`,
            [lookup, lookup]
        );

        if (!users || users.length === 0) {
            await logActivity(null, 'LOGIN_FAILED', `Failed login attempt for nonexistent user: ${lookup}`, req);
            return res.status(401).json({
                success: false,
                message: 'No registered account found with these credentials.'
            });
        }

        const user = users[0];

        // 2. Check if account is disabled by admin
        if (user.status === 'disabled') {
            await logActivity(user.email, 'LOGIN_BLOCKED_DISABLED', `Blocked login attempt for disabled account: ${user.email}`, req);
            return res.status(403).json({
                success: false,
                message: 'Your account has been disabled by an administrator. Please contact support.'
            });
        }

        // 3. Verify bcrypt password hash
        const passwordMatches = await bcrypt.compare(password, user.password_hash);
        if (!passwordMatches) {
            await logActivity(user.email, 'LOGIN_FAILED', `Incorrect password attempt for user: ${user.email}`, req);
            return res.status(401).json({
                success: false,
                message: 'Incorrect password credentials. Please verify and retry.'
            });
        }

        // 4. Update last_login timestamp in MySQL users table
        await db.query('UPDATE users SET last_login = NOW() WHERE email = ?', [user.email]);

        // 5. Generate JWT session token
        const token = jwt.sign(
            { userId: user.id, username: user.username, email: user.email, role: user.role },
            config.jwtSecret,
            { expiresIn: config.jwtExpiresIn }
        );

        // 6. Store session in MySQL sessions table (user_email)
        const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
        await db.query(
            'INSERT INTO sessions (user_email, token, ip_address, user_agent, expires_at) VALUES (?, ?, ?, ?, ?)',
            [user.email, token, req.ip || '', (req.headers['user-agent'] || '').slice(0, 255), expiresAt]
        );

        // 7. Record login in MySQL activity_logs (user_email)
        await logActivity(user.email, user.role === 'admin' ? 'ADMIN_LOGIN' : 'USER_LOGIN', `${user.role === 'admin' ? 'Admin' : 'User'} signed in: ${user.username}`, req);

        const displayName = user.display_name || `${user.first_name || ''} ${user.last_name || ''}`.trim() || user.username;

        const userData = {
            id: user.id,
            username: user.username,
            email: user.email,
            name: displayName,
            firstName: user.first_name || '',
            lastName: user.last_name || '',
            gender: user.gender || 'Other',
            role: user.role,
            status: user.status,
            genre: user.preferred_genre || 'Fiction',
            avatar: user.avatar || '1',
            phone: user.phone || '',
            bio: user.bio || '',
            premium: user.premium || 0
        };

        return res.json({
            success: true,
            message: `Welcome back, ${displayName}!`,
            data: {
                token,
                user: userData
            }
        });
    } catch (err) {
        next(err);
    }
});

/**
 * POST /api/auth/logout
 * Invalidates user session in MySQL
 */
router.post('/logout', authenticateToken, async (req, res, next) => {
    try {
        if (req.token) {
            await db.query('DELETE FROM sessions WHERE token = ?', [req.token]);
        }
        await logActivity(req.user.id, 'USER_LOGOUT', `User signed out: ${req.user.username}`, req);

        res.json({
            success: true,
            message: 'Signed out successfully.'
        });
    } catch (err) {
        next(err);
    }
});

/**
 * GET /api/auth/me
 * Retrieves current active user profile directly from MySQL
 */
router.get('/me', authenticateToken, async (req, res, next) => {
    try {
        const users = await db.query(
            `SELECT u.id, u.username, u.email, u.role, u.status, u.created_at,
                    p.first_name, p.last_name, p.display_name, p.gender, p.preferred_genre, p.avatar, p.phone, p.bio, p.premium
             FROM users u
             LEFT JOIN user_profiles p ON u.id = p.user_id
             WHERE u.id = ?`,
            [req.user.id]
        );

        if (!users || users.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found.' });
        }

        const user = users[0];
        const displayName = user.display_name || `${user.first_name || ''} ${user.last_name || ''}`.trim() || user.username;

        res.json({
            success: true,
            data: {
                id: user.id,
                username: user.username,
                email: user.email,
                name: displayName,
                firstName: user.first_name || '',
                lastName: user.last_name || '',
                gender: user.gender || 'Other',
                role: user.role,
                status: user.status,
                genre: user.preferred_genre || 'Fiction',
                avatar: user.avatar || '1',
                phone: user.phone || '',
                bio: user.bio || '',
                premium: user.premium || 0,
                createdAt: user.created_at
            }
        });
    } catch (err) {
        next(err);
    }
});

/**
 * PUT /api/auth/profile
 * Updates user profile in MySQL
 */
router.put('/profile', authenticateToken, async (req, res, next) => {
    try {
        const { name, firstName, lastName, gender, genre, avatar, phone, bio } = req.body;
        let cleanFirst = (firstName || '').trim();
        let cleanLast = (lastName || '').trim();
        let displayName = (name || '').trim();

        if (!displayName && (cleanFirst || cleanLast)) {
            displayName = `${cleanFirst} ${cleanLast}`.trim();
        } else if (displayName && !cleanFirst) {
            const parts = displayName.split(' ');
            cleanFirst = parts[0] || '';
            cleanLast = parts.slice(1).join(' ') || '';
        }
        if (!displayName) displayName = req.user.username;

        // Check if profile exists, if not create
        const existing = await db.query('SELECT id FROM user_profiles WHERE user_id = ?', [req.user.id]);
        if (existing.length === 0) {
            await db.query(
                `INSERT INTO user_profiles (user_id, first_name, last_name, display_name, gender, preferred_genre, avatar, phone, bio)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [req.user.id, cleanFirst, cleanLast, displayName, gender || 'Other', genre || 'Fiction', avatar || '1', phone || '', bio || '']
            );
        } else {
            await db.query(
                `UPDATE user_profiles
                 SET first_name = ?, last_name = ?, display_name = ?, gender = ?, preferred_genre = ?, avatar = ?, phone = ?, bio = ?, updated_at = NOW()
                 WHERE user_id = ?`,
                [cleanFirst, cleanLast, displayName, gender || 'Other', genre || 'Fiction', avatar || '1', phone || '', bio || '', req.user.id]
            );
        }

        await logActivity(req.user.id, 'PROFILE_UPDATE', `Updated user profile for: ${req.user.username}`, req);

        res.json({
            success: true,
            message: 'Profile details updated successfully.',
            data: {
                name: displayName,
                firstName: cleanFirst,
                lastName: cleanLast,
                gender: gender || 'Other',
                genre: genre || 'Fiction',
                avatar: avatar || '1',
                phone: phone || '',
                bio: bio || ''
            }
        });
    } catch (err) {
        next(err);
    }
});

/**
 * PUT /api/auth/change-password
 * Updates user password in MySQL with current password verification
 */
router.put('/change-password', authenticateToken, async (req, res, next) => {
    try {
        const { currentPassword, newPassword } = req.body;

        if (!currentPassword || !newPassword) {
            return res.status(400).json({ success: false, message: 'Current password and new password are required.' });
        }
        if (newPassword.length < 6) {
            return res.status(400).json({ success: false, message: 'New password must be at least 6 characters long.' });
        }

        const users = await db.query('SELECT password_hash FROM users WHERE id = ?', [req.user.id]);
        if (!users || users.length === 0) {
            return res.status(404).json({ success: false, message: 'User account not found.' });
        }

        const matches = await bcrypt.compare(currentPassword, users[0].password_hash);
        if (!matches) {
            return res.status(401).json({ success: false, message: 'Current password is incorrect.' });
        }

        const newHash = await bcrypt.hash(newPassword, 10);
        await db.query('UPDATE users SET password_hash = ?, updated_at = NOW() WHERE id = ?', [newHash, req.user.id]);

        await logActivity(req.user.id, 'PASSWORD_CHANGE', `User changed password: ${req.user.username}`, req);

        res.json({
            success: true,
            message: 'Password successfully updated.'
        });
    } catch (err) {
        next(err);
    }
});

/**
 * POST /api/auth/reset-password
 * Resets user password by email in MySQL
 */
router.post('/reset-password', async (req, res, next) => {
    try {
        const { email, password, newPassword } = req.body;
        const cleanEmail = (email || '').trim().toLowerCase();
        const targetPass = newPassword || password;

        if (!cleanEmail) {
            return res.status(400).json({ success: false, message: 'Email address is required.' });
        }
        if (!targetPass || targetPass.length < 6) {
            return res.status(400).json({ success: false, message: 'New password must be at least 6 characters long.' });
        }

        const users = await db.query('SELECT id, username FROM users WHERE email = ?', [cleanEmail]);
        if (!users || users.length === 0) {
            return res.status(404).json({ success: false, message: 'No registered account found with this email address.' });
        }

        const user = users[0];
        const newHash = await bcrypt.hash(targetPass, 10);
        await db.query('UPDATE users SET password_hash = ?, updated_at = NOW() WHERE id = ?', [newHash, user.id]);

        await logActivity(user.id, 'PASSWORD_RESET', `Password reset performed for email: ${cleanEmail}`, req);

        res.json({
            success: true,
            message: 'Password has been successfully updated.'
        });
    } catch (err) {
        next(err);
    }
});

module.exports = router;
