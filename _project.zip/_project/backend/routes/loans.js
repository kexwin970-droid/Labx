/* ==========================================================================
   Aetheria Library — Circulation & Loans API Routes
   Manages borrowing, returns, extensions directly in MySQL.
   ========================================================================== */

const express = require('express');
const router = express.Router();
const db = require('../db');
const { authenticateToken } = require('../middleware/auth');
const { logActivity } = require('../utils/logger');

router.use(authenticateToken);

/**
 * GET /api/loans
 * If member: returns member's borrowed items
 * If admin: returns all circulation loans across the library
 */
router.get('/', async (req, res, next) => {
    try {
        const isAdmin = req.user.role === 'admin';
        const { status = 'all', search = '' } = req.query;

        let sql = `
            SELECT l.*, b.title as book_title, b.author as book_author, b.genre as book_genre, b.bg_gradient,
                   u.username, u.email as user_email, p.display_name as user_name
            FROM loans l
            JOIN books b ON l.book_id = b.id
            JOIN users u ON (l.user_email = u.email OR l.user_id = u.id)
            LEFT JOIN user_profiles p ON (u.email = p.user_email OR u.id = p.user_id)
            WHERE 1=1
        `;
        const params = [];

        // Regular users can only view their own loans
        if (!isAdmin) {
            sql += ' AND (l.user_email = ? OR l.user_id = ?)';
            params.push(req.user.email, req.user.id);
        }

        if (status !== 'all') {
            sql += ' AND l.status = ?';
            params.push(status);
        }

        if (search.trim()) {
            sql += ' AND (b.title LIKE ? OR u.username LIKE ? OR u.email LIKE ? OR p.display_name LIKE ?)';
            const term = `%${search.trim()}%`;
            params.push(term, term, term, term);
        }

        sql += ' ORDER BY l.borrow_date DESC';

        const loans = await db.query(sql, params);

        res.json({
            success: true,
            data: loans,
            total: loans.length
        });
    } catch (err) {
        next(err);
    }
});

/**
 * POST /api/loans/borrow
 * Checks out one or multiple books for the authenticated user
 */
router.post('/borrow', async (req, res, next) => {
    try {
        const { bookIds, durationDays = 14 } = req.body;
        const ids = Array.isArray(bookIds) ? bookIds : [bookIds];

        if (!ids.length) {
            return res.status(400).json({ success: false, message: 'No book IDs provided for borrowing.' });
        }

        const borrowDate = new Date();
        const dueDate = new Date(Date.now() + durationDays * 86400000);
        const createdLoans = [];

        for (const rawId of ids) {
            const bookId = parseInt(rawId, 10);
            if (!bookId) continue;

            // Check if book exists and is available
            const books = await db.query('SELECT title, available FROM books WHERE id = ?', [bookId]);
            if (!books.length) continue;

            const book = books[0];

            // Insert into loans table in MySQL
            const loanResult = await db.query(
                `INSERT INTO loans (user_email, book_id, borrow_date, due_date, status)
                 VALUES (?, ?, ?, ?, 'active-borrow')`,
                [req.user.email, bookId, borrowDate, dueDate]
            );

            // Mark book as unavailable in MySQL books table
            await db.query('UPDATE books SET available = 0, updated_at = NOW() WHERE id = ?', [bookId]);

            createdLoans.push({
                loanId: loanResult.insertId,
                bookId,
                title: book.title,
                dueDate: dueDate.toISOString()
            });

            await logActivity(req.user.email, 'BOOK_BORROWED', `User checked out "${book.title}" (due ${dueDate.toLocaleDateString()})`, req);
        }

        res.status(201).json({
            success: true,
            message: `Successfully checked out ${createdLoans.length} title(s).`,
            data: createdLoans
        });
    } catch (err) {
        next(err);
    }
});

/**
 * POST /api/loans/return
 * Returns a borrowed book, updates loan record, and marks book available in MySQL
 */
router.post('/return', async (req, res, next) => {
    try {
        const { loanId, bookId } = req.body;
        const targetLoanId = parseInt(loanId, 10);
        const targetBookId = parseInt(bookId, 10);

        if (!targetLoanId && !targetBookId) {
            return res.status(400).json({ success: false, message: 'Loan ID or Book ID required.' });
        }

        let loanSql = 'SELECT * FROM loans WHERE 1=1';
        const params = [];

        if (targetLoanId) {
            loanSql += ' AND id = ?';
            params.push(targetLoanId);
        } else if (targetBookId) {
            loanSql += ' AND book_id = ? AND status = "active-borrow"';
            params.push(targetBookId);
        }

        if (req.user.role !== 'admin') {
            loanSql += ' AND (user_email = ? OR user_id = ?)';
            params.push(req.user.email, req.user.id);
        }

        const loans = await db.query(loanSql, params);
        if (!loans.length) {
            return res.status(404).json({ success: false, message: 'Active loan record not found.' });
        }

        const loan = loans[0];
        const returnDate = new Date();

        // Update loan record in MySQL
        await db.query(
            'UPDATE loans SET status = "returned", return_date = ? WHERE id = ?',
            [returnDate, loan.id]
        );

        // Mark book available in MySQL
        await db.query('UPDATE books SET available = 1, updated_at = NOW() WHERE id = ?', [loan.book_id]);

        await logActivity(req.user.id, 'BOOK_RETURNED', `Returned loan #${loan.id} (book #${loan.book_id})`, req);

        res.json({
            success: true,
            message: 'Book returned successfully. MySQL catalog updated.',
            data: { loanId: loan.id, bookId: loan.book_id, status: 'returned' }
        });
    } catch (err) {
        next(err);
    }
});

/**
 * POST /api/loans/extend
 * Extends loan due date by 7 days in MySQL
 */
router.post('/extend', async (req, res, next) => {
    try {
        const { loanId } = req.body;
        const id = parseInt(loanId, 10);

        const loans = await db.query('SELECT * FROM loans WHERE id = ?', [id]);
        if (!loans.length) {
            return res.status(404).json({ success: false, message: 'Loan record not found.' });
        }

        const loan = loans[0];
        if (req.user.role !== 'admin' && loan.user_id !== req.user.id) {
            return res.status(403).json({ success: false, message: 'Unauthorized to extend this loan.' });
        }

        const currentDue = new Date(loan.due_date);
        const newDue = new Date(currentDue.getTime() + 7 * 86400000);

        await db.query('UPDATE loans SET due_date = ?, status = "active-borrow" WHERE id = ?', [newDue, id]);

        await logActivity(req.user.id, 'LOAN_EXTENDED', `Extended due date for loan #${id} to ${newDue.toLocaleDateString()}`, req);

        res.json({
            success: true,
            message: `Loan extended by 7 days. New due date: ${newDue.toLocaleDateString()}.`,
            data: { loanId: id, newDueDate: newDue.toISOString() }
        });
    } catch (err) {
        next(err);
    }
});

module.exports = router;
